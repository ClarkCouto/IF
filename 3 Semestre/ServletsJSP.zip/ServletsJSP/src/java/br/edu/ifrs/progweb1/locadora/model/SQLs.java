package br.edu.ifrs.progweb1.locadora.model;

public enum SQLs {
    //USUÁRIO
    USR_VALIDA("SELECT * FROM Usuario WHERE nome=? AND senha=?"),
    USR_INSERT("INSERT INTO Usuario(senha, nome, nomeCompleto, email) Values(?,?,?,?)"), 
    USR_UPDATE("UPDATE Usuario SET senha=?, nome=?, nomeCompleto=?, email=? WHERE idUsuario = ?"),
    USR_DELETE("DELETE FROM Usuario WHERE idUsuario = ?"),
    USR_LISTALL("SELECT * FROM Usuario ORDER BY nome"),
    USR_FIND_BY_ID("SELECT * FROM Usuario WHERE idUsuario = ?"),
    
    //SÓCIO
    SOCIO_VALIDA("SELECT * FROM Socio WHERE nome=? AND senha=?"),
    SOCIO_INSERT("INSERT INTO Socio(nome, telefone, endereco, dataNascimento) Values(?,?,?,?)"), 
    SOCIO_UPDATE("UPDATE Socio SET nome=?, endereco=?, telefone=?, dataNascimento=? WHERE idSocio = ?"),
    SOCIO_DELETE("DELETE FROM Socio WHERE idSocio = ?"),
    SOCIO_LISTALL("SELECT * FROM Socio ORDER BY nome"),
    SOCIO_FIND_BY_ID("SELECT * FROM Socio WHERE idSocio = ?");
    
    private final String sql;
    SQLs(String sql){
        this.sql = sql; 
    
    }

    public String getSql() {
        return sql;
    }    
}

