/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifrs.progweb1.locadora.pojo;

import java.time.LocalDate;
import java.util.Date;

/**
 *
 * @author 0729159
 */
public class Socio {
    private String nome;
    private String endereco;
    private String telefone;
    private String dataNascimento;
    private int idSocio;

    public Socio() {
    }

    public Socio(String nome, String endereco, String telefone, String dataNascimento) {
        this(-1, nome, endereco, telefone, dataNascimento);
    }

    public Socio(int idSocio, String nome, String endereco, String telefone, String dataNascimento) {
        this.idSocio = idSocio;
        this.nome = nome;
        this.endereco = endereco;
        this.telefone = telefone;
        this.dataNascimento = dataNascimento;
    }

    public int getIdSocio() {
        return idSocio;
    }

    public void setIdSocio(int idSocio) {
        this.idSocio = idSocio;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(String dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    @Override
    public String toString() {
        return "Nome: " + nome + "\nEndereço: " + endereco + "\nTelefone: " + telefone + "\nData Nascimento: " + dataNascimento;
    }
    
    
}
