package br.edu.ifrs.progweb1.locadora.controller;

import br.edu.ifrs.progweb1.locadora.model.SocioDAO;
import br.edu.ifrs.progweb1.locadora.model.UsuarioDAO;
import br.edu.ifrs.progweb1.locadora.pojo.Socio;
import br.edu.ifrs.progweb1.locadora.pojo.Usuario;
import java.io.IOException;
import java.util.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ControllerSocio {
    @SuppressWarnings("static-access")
    /*
        public static String login(HttpServletRequest request) {    
        System.out.println("ControllerSocio Login");    
        
        String erro="";        
        String jsp="/erro.jsp";      
           
        Usuario usr = new Usuario();
        System.out.println(request.getParameter("nome"));
        System.out.println(request.getParameter("senha"));
        usr.setNome(request.getParameter("nome"));
        usr.setSenha(request.getParameter("senha"));
        try {
            usr = new UsuarioDAO().validate(usr);
            if(usr == null){
                erro="Usuário não encontrado!";
                request.setAttribute("erro", erro);
            }               
            else{
                request.getSession().setAttribute("idusuario", usr.getIdUsuario());                
                jsp = "/menu.jsp";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return jsp;        
     }
    */
    public static void validarSessao(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
        System.out.println("ControllerSocio ValidarSessao");
        Integer idUsuario = (Integer) request.getSession().getAttribute("idusuario");
        String jsp="";
        if(idUsuario == null ){
            jsp = "/index.jsp";
             //Redirecionando pagina
            RequestDispatcher rd = request.getRequestDispatcher(jsp);
            rd.forward(request, response);
        }        
    }
    
    public static String listar(HttpServletRequest request) {
        System.out.println("ControllerSocio Listar");
        String jsp = "";
        try {
            List<Socio> listSocio = new SocioDAO().getAll();
            if(listSocio != null){
                request.setAttribute("listSocio", listSocio);
                jsp = "/listarsocio.jsp";
            }else{
                String erro = "Nao existe registro!";
                request.setAttribute("erro", erro);
                jsp = "/erro.jsp";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return jsp;
    }
    public static String alterar(HttpServletRequest request) {
        System.out.println("ControllerSocio Alterar");
        String jsp = "";
        try {
            String idSocio = request.getParameter("idsocio");
            System.out.println("id1 = " + idSocio);
            Socio socio = new SocioDAO().findByID(Integer.parseInt(idSocio));
            if(socio != null){
                request.setAttribute("socio",socio);
                jsp = "/alterarsocio.jsp";
            }else{
                String erro = "Ocorreu erro ao Alterar Sócio!";
                request.setAttribute("erro", erro);
                jsp = "/erro.jsp";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return jsp;
    }
    
    public static String excluir(HttpServletRequest request) {
        System.out.println("ControllerSocio Excluir");
        String jsp = "";
        try {
            String cod = request.getParameter("idsocio");
            Socio socio = new SocioDAO().findByID(Integer.parseInt(cod));
            int delete = new SocioDAO().delete(socio);
            if(delete != 0){
                jsp = ControllerSocio.listar(request);
            }else{
                String erro = "Ocorreu erro ao Excluir Sócio!";
                request.setAttribute("erro", erro);
                jsp = "/erro.jsp";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return jsp;
    }
    public static String gravarAlteracao(HttpServletRequest request) {
        System.out.println("ControllerSocio GravarAlteracao");
        String jsp = "";
        try {
            
            String idSocio = request.getParameter("idsocio");
            System.out.println("id = " + idSocio);
            String nome = request.getParameter("nome");
            String telefone = request.getParameter("telefone");
            String endereco = request.getParameter("endereco");
            String dataNascimento = request.getParameter("dataNascimento");
            Socio socio = new Socio();
            socio.setIdSocio(Integer.parseInt(idSocio));
            socio.setNome(nome);
            socio.setTelefone(telefone);
            socio.setEndereco(endereco);
            socio.setDataNascimento(dataNascimento);
            
            int delete = new SocioDAO().update(socio);
            if(delete!=0)
                jsp = ControllerSocio.listar(request);
            else{
                String erro = "Nao foi possivel gravar a alteração desse registro";
                request.setAttribute("erro", erro);
                jsp = "/erro.jsp";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return jsp;
    }
    public static String gravarInsercao(HttpServletRequest request) {
        System.out.println("ControllerSocio GravarInsercao");
        String jsp = "";
        try {
            String nome = request.getParameter("nome");
            String telefone = request.getParameter("telefone");
            String endereco = request.getParameter("endereco");
            String dataNascimento = request.getParameter("dataNascimento");
            
            Socio socio = new Socio();
            socio.setNome(nome);
            socio.setTelefone(telefone);
            socio.setEndereco(endereco);
            socio.setDataNascimento(dataNascimento);
            
            int insert = new SocioDAO().insert(socio);
            if(insert != 0){
                System.out.println("ControllerSocio gravarInsercao insert != 0"); 
                jsp = ControllerSocio.listar(request);    
            }else{
                String erro = "Nao foi possivel gravar esse registro!";
                request.setAttribute("erro", erro);
                jsp = "/erro.jsp";
                System.out.println("ControllerSocio gravarInsercao erro" + erro); 
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return jsp;
    }
    
    public static String inserir(HttpServletRequest request) {
        System.out.println("ControllerSocio Inserir");
        String jsp = "";
        try {
            List<Socio> listSocio = new SocioDAO().getAll();
            if(listSocio != null){                
                request.setAttribute("listSocio", listSocio);
                jsp = "/inserirsocio.jsp";
                System.out.println("ControllerSocio inserir /inserirsocio"); 
             }else{
                String erro = "Nao existem registros!";
                System.out.println("ControllerSocio inserir erro " + erro);
                request.setAttribute("erro", erro);
                jsp = "/erro.jsp";    
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("ControllerSocio inserir jsp" + jsp);
        return jsp;
    }
    
     public static String sair(HttpServletRequest request)throws ServletException, IOException {
        request.getSession().invalidate();
        return "/index.jsp";
     }

}
