package br.edu.ifrs.progweb1.locadora.model;

import java.sql.*;
import br.edu.ifrs.progweb1.locadora.pojo.Socio;
import java.util.ArrayList;
import java.util.List;

public class SocioDAO implements GenericDAO<Socio> {

    private static PreparedStatement pstmt = null;
    private static ResultSet rs = null;

    @Override
    public int insert(Socio socio) {
        System.out.println("SocioDAO insert");
        int retorno = 0;
        try {
            pstmt = ConnectionFactory.getConnection().prepareStatement(SQLs.SOCIO_INSERT.getSql());
            pstmt.setString(1, socio.getNome());
            pstmt.setString(2, socio.getTelefone());
            pstmt.setString(3, socio.getEndereco());
            pstmt.setString(4, socio.getDataNascimento());
            retorno = pstmt.executeUpdate();
            pstmt.close();
        } catch (SQLException e) {
            System.out.println("SQLException: " + e);
            e.printStackTrace();
        }
        return retorno;
    }

    @Override
    public int update(Socio socio) {
        int retorno = 0;
        try {
            pstmt = ConnectionFactory.getConnection().prepareStatement(SQLs.SOCIO_UPDATE.getSql());
            pstmt.setString(1, socio.getNome());
            pstmt.setString(2, socio.getTelefone());
            pstmt.setString(3, socio.getEndereco());
            pstmt.setString(4, socio.getDataNascimento());
            pstmt.setInt(5, socio.getIdSocio());
            retorno = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return retorno;
    }

    public int delete(Socio socio) {
        int retorno = 0;
        try {
            pstmt = ConnectionFactory.getConnection().prepareStatement(SQLs.SOCIO_DELETE.getSql());
            pstmt.setInt(1, socio.getIdSocio());
            retorno = pstmt.executeUpdate();
            pstmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return retorno;
    }

    @Override
    public List<Socio> getAll() {
        try {
            List<Socio> lista = new ArrayList<>();
            pstmt = ConnectionFactory.getConnection().prepareStatement(SQLs.SOCIO_LISTALL.getSql());
            rs = pstmt.executeQuery();
            while (rs.next()) {
                Socio socio = new Socio();
                socio.setIdSocio(rs.getInt("idSocio"));
                socio.setNome(rs.getString("nome"));
                socio.setTelefone(rs.getString("telefone"));
                socio.setEndereco(rs.getString("endereco"));
                socio.setDataNascimento(rs.getString("dataNascimento"));
                lista.add(socio);
            }
            rs.close();
            pstmt.close();
            return lista;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public Socio findByID(int Id) {
        Socio socio = null;
        try {
            pstmt = ConnectionFactory.getConnection().prepareStatement(SQLs.SOCIO_FIND_BY_ID.getSql());
            pstmt.setInt(1, Id);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                socio = new Socio();
                socio.setIdSocio(rs.getInt("idSocio"));
                socio.setNome(rs.getString("nome"));
                socio.setTelefone(rs.getString("telefone"));
                socio.setEndereco(rs.getString("endereco"));
                socio.setDataNascimento(rs.getString("dataNascimento"));
            }
            rs.close();
            pstmt.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return socio;
    }
}
