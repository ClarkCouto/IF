 
 function validarCamposLogin(){    
    var frm = document.frmLogin;
     var nome = frm.nome.value;
     var senha = frm.senha.value;
     
     if(nome == ""){
        alert("Preencha o campo usuario!");
        frm.nome.focus();
        return false;
     }else if(senha == ""){
        alert("Preencha o campo senha!");
        frm.senha.focus();
        return false;
     }else{
        caminhourl = "/ServletsJSP/servletweb?acao=Logar";  
        document.forms[0].action = caminhourl;  
        window.document.forms[0].submit();
        return true;
     }      
 }
 
/*---------------------------------------------------------------------
 * Fun��es de manipula��o para tabelas
 *---------------------------------------------------------------------*/
 function Excluir(chave, frm) {
      var table = frm.table.value;
      
      if(table == "Usuario"){
        if (confirm('Deseja excluir o Usuario do C�digo: ' + chave + '?')) {            
            if(frm.acao.value == "alterar"){
                frm.acao.value = "/ServletsJSP/servletweb?acao=ExcluirUsuario&idusuario="+chave;
                frm.action = frm.acao.value;
            }else
                frm.acao.value = 'ExcluirUsuario';
                
            frm.idusuario.value = chave;
            frm.submit();
        }
      }            
}

function GravarAlterarTabela(frm){
    var table = frm.table.value;
    System.out.println("GravarAlterarTabela table: " + table);
    if(table == "Usuario"){
        if(ValidarUsuario(frm)){
            if(frm.acao.value == "alterar")
                caminhourl = "/ServletsJSP/servletweb?acao=GravarAlteracaoUsuario&idUsuario="+ frm.idusuario.value;
            else if(frm.acao.value == "gravar")
                caminhourl = "/ServletsJSP/servletweb?acao=GravarInsercaoUsuario";  
        }
    }
    else if(table == "Socio"){
        System.out.println("Entrou GravarAlterarTabela Socio");
        if(ValidarUsuario(frm)){
            if(frm.acao.value == "alterar"){
                caminhourl = "/ServletsJSP/servletweb?acao=GravarAlteracaoSocio&idSocio="+ frm.idsocio.value;
                System.out.println("Entrou GravarAlterarTabela Alterar Socio"); 
            }
            else if(frm.acao.value == "gravar"){
                caminhourl = "/ServletsJSP/servletweb?acao=GravarInsercaoSocio";  
                System.out.println("Entrou GravarAlterarTabela Gravar Socio"); 
            }
        }
    }
    System.out.println("Entrou GravarAlterarTabela Action: " + caminhourl);
    frm.action = caminhourl;  
    frm.submit();
}

function ValidarUsuario(frm){
    if(frm.nome.value==""){
        alert("Informe o nome!");
        frm.nome.focus();
        return false;
    }else if(frm.nomecompleto.value==""){
        alert("Informe o nome completo!");
        frm.nomecompleto.focus();
        return false;
    }else if(frm.senha.value==""){
        alert("Informe a senha!");
        frm.senha.focus();
        return false;
    }else if(frm.email.value==""){
        alert("Informe o email!");
        frm.email.focus();
        return false;
    }else{
        return true;
    }
}