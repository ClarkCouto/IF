package classes;

import dao.UsuarioDAO;
import java.util.LinkedList;

/**
 *
 * @author Cristiano Couto
 */
public class Usuario{  
    private String email;  
    private String senha;
    private long idUsuario;

    public Usuario(){}
    
    public Usuario(String email, String senha) {
        this(-1, email, senha);
    }
    public Usuario(long idUsuario, String email, String senha) {
        this.idUsuario = idUsuario;
        this.email = email;
        this.senha = senha;
    }
      
    public String getEmail() {  
        return email;  
    }  
    
    public void setEmail(String email) {  
        this.email = email;  
    }  
    
    public String getSenha() {  
        return senha;  
    }  
    
    public void setSenha(String senha) {  
        this.senha = senha;  
    }    

    public Long getId() {
        return idUsuario;
    }

    public void setId(Long id) {
        this.idUsuario = id;
    }    
    
    public int insert() {
        return new UsuarioDAO().insert(this);
    }  
    
    public int editar() {
        return new UsuarioDAO().update(this);
    }  
    
    public int excluir() {
        return new UsuarioDAO().delete(this);
    }
    
    public LinkedList<Usuario> listAll(){
        return new UsuarioDAO().listAll();
    }
    
    public boolean autenticar(){
        return new UsuarioDAO().autenticar(this);
    }
    
   
}
