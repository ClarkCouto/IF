package classes;

import java.util.LinkedList;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

/**
 *
 * @author Cristiano Couto
 */
@SessionScoped
@ManagedBean
public class FuncionarioBean {
    private Funcionario funcionario = new Funcionario();
    private LinkedList<String> estados;
    private LinkedList<String> estadosCivis;
    private LinkedList<String> situacoes;
    private LinkedList<Funcionario> lista;
    private boolean casado;

    public Funcionario getFuncionario() {
        return funcionario;
    }

    public void setAluno(Funcionario funcionario) {
        this.funcionario = funcionario;
    }

    public LinkedList<String> getEstados() {
        if(estados == null)
           return funcionario.getEstados();
        return estados; 
    }

    public LinkedList<String> getEstadosCivis() {
        if(estadosCivis == null)
           return funcionario.getEstadosCivis();
        return estadosCivis; 
    }

    public LinkedList<String> getSituacoes() {
        if(situacoes == null)
           return funcionario.getSituacoes();
        return situacoes; 
    }
    
    public boolean getCasado(){
        return casado;
    }
    
    public LinkedList<Funcionario> getLista() {
        this.lista = funcionario.listar();
        return lista;
    }
    
    public String inserir(){
        if(funcionario.insert() > 0){
            limpar();
            return "ListarFuncionarios";
        }
        FacesContext.getCurrentInstance().addMessage("mensagem", new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                                "Ocorreu um erro no sistema. Por favor, tente novamente.", null));
        return "CadastrarFuncionarios";
    }
    
    public String editar(Funcionario func){
        if(func.editar() > 0){
            FacesContext.getCurrentInstance().addMessage(
                                "mensagem-editar",
                                new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                                "Funcionário editado com sucesso.", null));
            return "ListarFuncionarios";
        }
        FacesContext.getCurrentInstance().addMessage(
                                "mensagem-editar",
                                new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                                "Ocorreu um erro no sistema. Por favor, tente novamente.", null)); 
        return "EditarFuncionarios";
    }
    
    public String excluir(Funcionario func){
        if(func.excluir() > 0){
            FacesContext.getCurrentInstance().addMessage(
                                "mensagem-excluir",
                                new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                                "Funcionário excluído com sucesso.", null));
            return "ListarUsuarios";
        }
        FacesContext.getCurrentInstance().addMessage(
                                "mensagem-excluir",
                                new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                                "Ocorreu um erro no sistema. Por favor, tente novamente.", null));
        return "EditarUsuarios";
    }
    
    public void limpar(){
        funcionario.setNome(null);
        funcionario.setUF(null);
        funcionario.setSalario(0);
        funcionario.setEstadoCivil(null);
        funcionario.setNomeConjuge(null);
        funcionario.setSituacao(null);
        funcionario.setObservacoes(null);
    }
    
    public String index(){
        return "index?faces-redirect=true";
    }
    
    public String listarFuncionarios(){
        return "ListarFuncionarios?faces-redirect=true";
    }
    
    public String listarUsuarios(){
        return "ListarUsuarios?faces-redirect=true";
    }
    
    public String cadastrarFuncionarios(){
        return "CadastrarFuncionarios?faces-redirect=true";
    }
    
    public String cadastrarUsuarios(){
        return "CadastrarUsuarios?faces-redirect=true";
    }
    
    public String editarFuncionarios(Funcionario func){
        this.funcionario = func;
        return "EditarFuncionarios?faces-redirect=true";
    }
}

