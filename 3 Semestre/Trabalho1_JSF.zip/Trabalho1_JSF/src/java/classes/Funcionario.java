package classes;

import dao.FuncionarioDAO;
import java.util.*;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Cristiano Couto
 */
public class Funcionario{
    private String nome;
    private double salario;
    @NotNull(message = "UF é obrigatório!")
    private String UF;
    @NotNull(message = "Estado Civil é obrigatório!")
    private String estadoCivil;
    private String nomeConjuge;
    @NotNull(message = "Situação é obrigatória!")
    private String situacao;
    private String observacoes;
    private long idFuncionario;

    public Funcionario() {
    }

    public Funcionario(String nome, double salario, String UF, String estadoCivil, String nomeConjuge, String situacao, String observacoes) {
        this(-1, nome, salario, UF, estadoCivil, nomeConjuge, situacao, observacoes);
    }

    public Funcionario(long idFuncionario, String nome, double salario, String UF, String estadoCivil, String nomeConjuge, String situacao, String observacoes) {
        this.idFuncionario = idFuncionario;
        this.nome = nome;
        this.salario = salario;
        this.UF = UF;
        this.estadoCivil = estadoCivil;
        this.nomeConjuge = nomeConjuge;
        this.situacao = situacao;
        this.observacoes = observacoes;
    }

    public long getIdFuncionario() {
        return idFuncionario;
    }

    public void setIdFuncionario(long idFuncionario) {
        this.idFuncionario = idFuncionario;
    }
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public String getUF() {
        return UF;
    }

    public void setUF(String UF) {
        this.UF = UF;
    }

    public String getEstadoCivil() {
        return estadoCivil;
    }

    public void setEstadoCivil(String estadoCivil) {
        this.estadoCivil = estadoCivil;
    }

    public String getNomeConjuge() {
        return nomeConjuge;
    }

    public void setNomeConjuge(String nomeConjuge) {
        this.nomeConjuge = nomeConjuge;
    }

    public String getSituacao() {
        return situacao;
    }

    public void setSituacao(String situacao) {
        this.situacao = situacao;
    }

    public String getObservacoes() {
        return observacoes;
    }

    public void setObservacoes(String observacoes) {
        this.observacoes = observacoes;
    }
    
    public LinkedList<String> getEstados(){
        LinkedList<String> estados = new LinkedList<>();
        estados.add("PR");
        estados.add("RS");
        estados.add("SC");
        return estados;
    }
    
    public LinkedList<String> getEstadosCivis(){
        LinkedList<String> estados = new LinkedList<>();
        estados.add("Solteiro");
        estados.add("Casado");
        return estados;
    }
    
    public LinkedList<String> getSituacoes(){
        LinkedList<String> situacoes = new LinkedList<>();
        situacoes.add("Ativo");
        situacoes.add("Afastado");
        situacoes.add("Aposentado");
        situacoes.add("Licença");
        return situacoes;
    }
    
    public LinkedList<Funcionario> listar(){
        LinkedList<Funcionario> lista;
        try{
            lista = listAll();
        }
        catch(Exception e){
            lista = new LinkedList();
            lista.add(new Funcionario("André", 2000.0, "RS", "Casado", "Bruna", "Ativo", "Teste"));
        }
        return lista;
    }
    
    public void imprime(){
        System.out.println("Nome: " + nome);
        System.out.println("Salário: " + salario);
        System.out.println("UF: " + UF);
        System.out.println("Estado Civil: " + estadoCivil);
        if(estadoCivil.equals("Casado"))
            System.out.println("Nome Conjugê: " + nomeConjuge);
        System.out.println("Situação: " + situacao);
        System.out.println("Observações: " + observacoes);
    }

    @Override
    public String toString() {
        return "Nome: " + nome + " Salário: " + salario;
    }  
    
    public int insert() {
        return new FuncionarioDAO().insert(this);
    }
    
    public int editar() {
        return new FuncionarioDAO().update(this);
    }  
    
    public int excluir() {
        return new FuncionarioDAO().delete(this);
    }
    
    public LinkedList<Funcionario> listAll(){
        return new FuncionarioDAO().listAll();
    }
    
}
