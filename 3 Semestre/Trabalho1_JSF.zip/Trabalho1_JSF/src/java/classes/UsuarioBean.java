package classes;

import java.util.LinkedList;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;

/**
 *
 * @author Cristiano Couto
 */
@ManagedBean
public class UsuarioBean {
    private Usuario usuario = new Usuario();
    private Usuario usuarioLogado = new Usuario();
    private LinkedList<Usuario> lista;
    private String confirmarSenha;

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Usuario getUsuarioLogado() {
        return usuarioLogado;
    }

    public void setUsuarioLogado(Usuario usuarioLogado) {
        this.usuarioLogado = usuarioLogado;
    }
    
    public String getConfirmarSenha(){
        return confirmarSenha;
    }

    public void setConfirmarSenha(String senha){
        this.confirmarSenha = senha;
    }
    
    public LinkedList<Usuario> getLista() {
        lista = usuario.listAll();
        return lista; 
    }
    
    public boolean inserir(){
        if(usuario.getSenha().equals(this.getConfirmarSenha())){
            if(usuario.insert() > 0){
                return true;
            }
            FacesContext.getCurrentInstance().addMessage(
                                    "mensagem",
                                    new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                                    "Ocorreu um erro no sistema. Por favor, tente novamente.", null));
        }
        else{
            FacesContext.getCurrentInstance().addMessage(
					"mensagem",
					new FacesMessage(FacesMessage.SEVERITY_ERROR,
							"Senha e Confirmação de Senha devem ser iguais! Confira os dados e tente novamente.", null));    
        }
        return false;
    }
    
    public boolean editar(Usuario user){
        if(user.editar() > 0){
            FacesContext.getCurrentInstance().addMessage(
                                "mensagem",
                                new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                                "Usuário editado com sucesso.", null));
            return true;
        }
        FacesContext.getCurrentInstance().addMessage(
                                "mensagem",
                                new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                                "Ocorreu um erro no sistema. Por favor, tente novamente.", null));
        return false;
    }
    
    public boolean excluir(Usuario user){
        if(user.excluir() > 0){
            FacesContext.getCurrentInstance().addMessage(
                                "mensagem",
                                new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                                "Usuário excluído com sucesso.", null));
            return true;
        }
        FacesContext.getCurrentInstance().addMessage(
                                "mensagem",
                                new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                                "Ocorreu um erro no sistema. Por favor, tente novamente.", null));
        return false;
    }
    
    public boolean validar(){
        if(usuario.autenticar()){
            this.usuarioLogado = usuario;    
            usuario = new Usuario();
            return true;
        }
        else{
            FacesContext.getCurrentInstance().addMessage(
                                    "mensagem",
                                    new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                                    "Informações inválidas. Confira os dados e tente novamente.", null));
        }
        return false;
    }
    
    public void limpar(){
        usuario.setEmail(null);
        usuario.setSenha(null);
    }
    
    public String index(){
        return "index";
    }
    
    public String listarFuncionarios(){
        return "ListarFuncionarios?faces-redirect=true";
    }
    
    public String listarUsuarios(){
        return "ListarUsuarios?faces-redirect=true";
    }
    
    public String cadastrarFuncionarios(){
        return "CadastrarFuncionarios?faces-redirect=true";
    }
    
    public String cadastrarUsuarios(){
        return "CadastrarUsuarios?faces-redirect=true";
    }
    /*
    public String editarUsuarios(){
        return "EditarUsuarios?faces-redirect=true";
    }
    */
    public String editarUsuarios(Usuario user){
        this.usuario = user;
        return "EditarUsuarios?faces-redirect=true";
    }
}

