package dao;

import classes.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;

/**
 *
 * @author Cristiano Couto
 */
public class UsuarioDAO implements GenericDAO<Usuario>{
    @Override
    public  LinkedList<Usuario> listAll() {
        LinkedList<Usuario> lista = new LinkedList<>();
        
        try(Connection connection = new ConnectionFactory().getConnection();
            PreparedStatement stmt = connection.prepareStatement(SQLs.USUARIO_LISTALL.getSql())){
            
            System.out.println("Conexão aberta!");
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                System.out.println("Executou sql!");
                long idUsuario = Long.parseLong(rs.getString("idUsuario"));
                String email = rs.getString("email");
                String senha = rs.getString("senha");
                lista.add(new Usuario(idUsuario, email, senha));
                System.out.println("ID = " + idUsuario);
            }
            return lista;
        }
        catch(SQLException e){
            System.out.println("Exceção com recursos: " + e.getMessage());
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada: " + ex.getMessage());
        }
        catch(Exception e){
            System.out.println("Exceção no código!");
            e.printStackTrace();
        }
        return null;
    }
    
    public boolean autenticar(Usuario usuario){
        boolean retorno = false;
         try(Connection connection = new ConnectionFactory().getConnection();
            PreparedStatement stmt = 
                    connection.prepareStatement(SQLs.USUARIO_AUTENTICA.getSql())){
            
            stmt.setString(1, usuario.getEmail());
            stmt.setString(2, usuario.getSenha());
            ResultSet rs = stmt.executeQuery();
            System.out.println("Dados Recuperados!");
            rs.last();
            if(rs.getRow() >= 1) 
                return true;
        }
        catch(SQLException e){
            System.out.println("Exceção com recursos: " + e.getMessage());
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada: " + ex.getMessage());
        }
        catch(Exception e){
            System.out.println("Exceção no código!");
            e.printStackTrace();
        }
        return retorno;
    }
    
    @Override
    public int insert(Usuario usuario) {
        int chavePrimaria = -1;
        try(Connection connection = new ConnectionFactory().getConnection();
            PreparedStatement stmt = connection.prepareStatement(SQLs.USUARIO_INSERT.getSql(),
                              Statement.RETURN_GENERATED_KEYS)){
            System.out.println("Conexão aberta!");
            stmt.setString(1, usuario.getEmail());
            stmt.setString(2, usuario.getSenha());
            stmt.execute();
            System.out.println("Dados Gravados!");
            ResultSet chaves = stmt.getGeneratedKeys();
            if (chaves.next())  
                chavePrimaria= chaves.getInt(1);
        }
        catch(SQLException e){
            System.out.println("Exceção com recursos: " + e.getMessage());
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada: " + ex.getMessage());
        }
        catch(Exception e){
            System.out.println("Exceção no código!");
            e.printStackTrace();
        }
        return chavePrimaria;
    }
    
    @Override
    public int update(Usuario usuario) {
        try(Connection connection = new ConnectionFactory().getConnection();
            PreparedStatement stmt = connection.prepareStatement(SQLs.USUARIO_UPDATE.getSql(),
                              Statement.RETURN_GENERATED_KEYS)){
            System.out.println("Conexão aberta!");
            stmt.setString(1, usuario.getEmail());
            stmt.setString(2, usuario.getSenha());
            stmt.setLong(3, usuario.getId());
            System.out.println("Usuario Deletado!");
            return stmt.executeUpdate();
        }
        catch(SQLException e){
            System.out.println("Exceção com recursos: " + e.getMessage());
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada: " + ex.getMessage());
        }
        catch(Exception e){
            System.out.println("Exceção no código!");
            e.printStackTrace();
        }
        return 0;
    }
    
    @Override
    public int delete(Usuario usuario) {
        try(Connection connection = new ConnectionFactory().getConnection();
            PreparedStatement stmt = connection.prepareStatement(SQLs.USUARIO_DELETE.getSql(),
                              Statement.RETURN_GENERATED_KEYS)){
            System.out.println("Conexão aberta!");
            stmt.setLong(1, usuario.getId());
            System.out.println("Usuario Deletado!");
            return stmt.executeUpdate();
        }
        catch(SQLException e){
            System.out.println("Exceção com recursos: " + e.getMessage());
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada: " + ex.getMessage());
        }
        catch(Exception e){
            System.out.println("Exceção no código!");
            e.printStackTrace();
        }
        return 0;
    }
}
