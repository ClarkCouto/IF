package dao;

import java.sql.*;

/**
 *
 * @author Cristiano Couto
 */
public class ConnectionFactory {
    public Connection getConnection() throws ClassNotFoundException, SQLException{
           Class.forName("com.mysql.jdbc.Driver");
           String urlBD="jdbc:mysql://localhost:3306/trabalho1jsf";
           return DriverManager.getConnection(urlBD, "root", "");
    }
}
