/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import classes.Funcionario;
import java.sql.*;
import java.util.LinkedList;

/**
 *
 * @author Cristiano Couto
 */
public class FuncionarioDAO implements GenericDAO<Funcionario>{
    @Override
    public int insert(Funcionario funcionario) {
        int chavePrimaria = -1;
        try(Connection connection = new ConnectionFactory().getConnection();
            PreparedStatement stmt = connection.prepareStatement(SQLs.FUNCIONARIO_INSERT.getSql(),
                              Statement.RETURN_GENERATED_KEYS)){
            System.out.println("Conexão aberta!");
            
            /*
            System.out.println("Nome: " + funcionario.getNome());
            System.out.println("Salário: " + funcionario.getSalario());
            System.out.println("UF: " + funcionario.getUF());
            System.out.println("Estado Civil: " + funcionario.getEstadoCivil());
            System.out.println("Nome Conjugê: " + funcionario.getNomeConjuge());
            System.out.println("Nome Conjugê: " +  (funcionario.getNomeConjuge() == null ? " " : funcionario.getNomeConjuge()));
            System.out.println("Situação: " + funcionario.getSituacao());
            System.out.println("Observações: " + funcionario.getObservacoes());
            */
            stmt.setString(1, funcionario.getNome());
            stmt.setDouble(2, funcionario.getSalario());
            stmt.setString(3, funcionario.getUF());
            stmt.setString(4, funcionario.getEstadoCivil());
            stmt.setString(5, (funcionario.getNomeConjuge() == null ? " " : funcionario.getNomeConjuge()));
            stmt.setString(6, funcionario.getSituacao());
            stmt.setString(7, funcionario.getObservacoes());
            stmt.execute();
            System.out.println("Dados Gravados!");
            ResultSet chaves = stmt.getGeneratedKeys();
            if (chaves.next())  
                chavePrimaria= chaves.getInt(1);
        }
        catch(SQLException e){
            System.out.println("Exceção com recursos: " + e.getMessage());
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada: " + ex.getMessage());
        }
        catch(Exception e){
            System.out.println("Exceção no código!");
            e.printStackTrace();
        }
        return chavePrimaria;  
    }
    
    @Override
    public  LinkedList<Funcionario> listAll() {
        LinkedList<Funcionario> lista = new LinkedList<>();
        
        try(Connection connection = new ConnectionFactory().getConnection();
            PreparedStatement stmt = connection.prepareStatement(SQLs.FUNCIONARIO_LISTALL.getSql())){
            
            System.out.println("Conexão aberta!");
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                System.out.println("Executou sql!");
                long idFuncionario = Long.parseLong(rs.getString("idFuncionario"));
                String nome = rs.getString("nome");
                double salario = Double.parseDouble(rs.getString("salario"));
                String uf = rs.getString("uf");
                String estadoCivil = rs.getString("estadoCivil");
                String nomeConjuge = rs.getString("nomeConjuge");
                String situacao = rs.getString("situacao");
                String observacoes = rs.getString("observacoes");
                lista.add(new Funcionario(idFuncionario, nome, salario, uf, estadoCivil, 
                        nomeConjuge, situacao, observacoes));
                
                System.out.println("ID = " + idFuncionario);
            }
            return lista;
        }
        catch(SQLException e){
            System.out.println("Exceção com recursos: " + e.getMessage());
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada: " + ex.getMessage());
        }
        catch(Exception e){
            System.out.println("Exceção no código!");
            e.printStackTrace();
        }
        return null;
    }
    
    @Override
    public int update(Funcionario funcionario) {
        try(Connection connection = new ConnectionFactory().getConnection();
            PreparedStatement stmt = connection.prepareStatement(SQLs.FUNCIONARIO_UPDATE.getSql(),
                              Statement.RETURN_GENERATED_KEYS)){
            stmt.setString(1, funcionario.getNome());
            stmt.setDouble(2, funcionario.getSalario());
            stmt.setString(3, funcionario.getUF());
            stmt.setString(4, funcionario.getEstadoCivil());
            stmt.setString(5, (funcionario.getNomeConjuge() == null ? " " : funcionario.getNomeConjuge()));
            stmt.setString(6, funcionario.getSituacao());
            stmt.setString(7, funcionario.getObservacoes());
            stmt.setLong(8, funcionario.getIdFuncionario());
            
            
            System.out.println("Nome: " + funcionario.getNome());
            System.out.println("Salário: " + funcionario.getSalario());
            System.out.println("UF: " + funcionario.getUF());
            System.out.println("Estado Civil: " + funcionario.getEstadoCivil());
            System.out.println("Nome Conjugê: " + funcionario.getNomeConjuge());
            System.out.println("Nome Conjugê: " +  (funcionario.getNomeConjuge() == null ? " " : funcionario.getNomeConjuge()));
            System.out.println("Situação: " + funcionario.getSituacao());
            System.out.println("Observações: " + funcionario.getObservacoes());
            System.out.println("ID = " + funcionario.getIdFuncionario());
            System.out.println("Usuario Atualizado com sucesso!");
            return stmt.executeUpdate();
        }
        catch(SQLException e){
            System.out.println("Exceção com recursos: " + e.getMessage());
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada: " + ex.getMessage());
        }
        catch(Exception e){
            System.out.println("Exceção no código!");
            e.printStackTrace();
        }
        return 0;
    }
    
    @Override
    public int delete(Funcionario funcionario) {
        try(Connection connection = new ConnectionFactory().getConnection();
            PreparedStatement stmt = connection.prepareStatement(SQLs.FUNCIONARIO_DELETE.getSql(),
                              Statement.RETURN_GENERATED_KEYS)){
            System.out.println("Conexão aberta!");
            System.out.println("ID = " + funcionario.getIdFuncionario());
            stmt.setLong(1, funcionario.getIdFuncionario());
            System.out.println("Funcionário Deletado!");
            return stmt.executeUpdate();
        }
        catch(SQLException e){
            System.out.println("Exceção com recursos: " + e.getMessage());
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada: " + ex.getMessage());
        }
        catch(Exception e){
            System.out.println("Exceção no código!");
            e.printStackTrace();
        }
        return 0;
    }
}
