/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

/**
 *
 * @author Cristiano Couto
 */
public enum SQLs {
    FUNCIONARIO_INSERT("insert into funcionario(nome, salario, uf, estadoCivil, nomeConjuge, situacao, observacoes) values (?, ?, ?, ?, ?, ?, ?)"),
    FUNCIONARIO_UPDATE("update funcionario set nome = ?, salario = ?, uf = ?, estadoCivil = ?, nomeConjuge = ?, situacao = ?, observacoes = ? where idFuncionario = ?"), 
    FUNCIONARIO_DELETE("delete from funcionario where idFuncionario = ?"), 
    FUNCIONARIO_LISTALL("select * from funcionario"),
    
    USUARIO_AUTENTICA("select * from usuario WHERE email = ? and senha = ?"),
    USUARIO_INSERT("insert into usuario(email, senha) values (?, ?)"), 
    USUARIO_UPDATE("update usuario set email = ?, senha = ?"), 
    USUARIO_DELETE("delete from usuario where idusuario = ?"), 
    USUARIO_LISTALL("select * from usuario");
    
    private final String sql;
    SQLs(String sql){
        this.sql = sql; 
    }

    public String getSql() {
        return sql;
    }    
}

