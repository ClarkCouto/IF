/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package provapartedois;

import java.util.List;
import provapartedois.DAO.VooDAO;

/**
 *
 * @author CristianoCouto
 */
public class Voo {
    public long numero;
    public String ciaAerea;
    public String horarioSaida;
    public String horarioChegada;
    public Rota rota;
    public Data data;
    public int idVoo;

    public Voo() {
    }
    
    public Voo(long numero, String ciaAerea, String horarioSaida, String horarioChegada, Rota rota, Data data) {
        this(-1, numero, ciaAerea, horarioSaida, horarioChegada, rota, data);
    }

    public Voo(int idVoo, long numero, String ciaAerea, String horarioSaida, String horarioChegada, Rota rota, Data data) {
        this.idVoo = idVoo;
        this.numero = numero;
        this.ciaAerea = ciaAerea;
        this.horarioSaida = horarioSaida;
        this.horarioChegada = horarioChegada;
        this.rota = rota;
        this.data = data;
    }

    public long getNumero() {
        return numero;
    }

    public String getCiaAerea() {
        return ciaAerea;
    }

    public String getHorarioSaida() {
        return horarioSaida;
    }

    public String getHorarioChegada() {
        return horarioChegada;
    }

    public Rota getRota() {
        return rota;
    }

    public Data getData() {
        return data;
    }

    public int getIdVoo() {
        return idVoo;
    }

    public void setNumero(long numero) {
        this.numero = numero;
    }

    public void setCiaAerea(String ciaAerea) {
        this.ciaAerea = ciaAerea;
    }

    public void setHorarioSaida(String horarioSaida) {
        this.horarioSaida = horarioSaida;
    }

    public void setHorarioChegada(String horarioChegada) {
        this.horarioChegada = horarioChegada;
    }

    public void setRota(Rota rota) {
        this.rota = rota;
    }

    public void setData(Data data) {
        this.data = data;
    }

    public void setIdVoo(int idVoo) {
        this.idVoo = idVoo;
    }

    @Override
    public String toString() {
        return "Voo Número: " + numero + "\nCia Aerea: " + ciaAerea + "\nHorário Saída: " + horarioSaida + "\nHorário Chegada: " + horarioChegada + "\nData: " + (data != null ? data : "Data não informada!") + "\nRota: " + (rota != null ? rota : "Rota não informada!") + "\n\n";
    }
    
    public int insert() {
        return new VooDAO().insert(this);
    }
    public List<Voo> listAll(){
        return new VooDAO().listAll();
    }
    public int delete() {
        return new VooDAO().delete(this);
    }
    public int update() {
        return new VooDAO().update(this);
    }
    public Voo findById(int idVoo) {
        return new VooDAO().findByID(idVoo);
    }

}
