/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package provapartedois;

import java.util.Comparator;

/**
 *
 * @author CristianoCouto
 */
public class ComparatorData implements Comparator<Data> {
    public int compare(Data d1, Data d2) {
        return d1.compareTo(d2); 
    }
}
