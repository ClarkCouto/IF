/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package provapartedois;

import java.util.LinkedList;
import java.util.NoSuchElementException;

/**
 *
 * @author CristianoCouto
 */
public class MinhaFila<E> implements OperacoesFila<E>{
    private LinkedList<E> lista = new LinkedList<>();
    @Override
    public boolean adicionar(E elemento) {
        //return lista.add(elemento);
        try{
            return lista.add(elemento);
        }
        catch(NullPointerException e){
            System.out.println("Tentou adicinoar em uma posição nula!");
        }
        return false;
    }

    @Override
    public E remover() {
        //return lista.removeFirst();
        throw new NoSuchElementException();
    }

    @Override
    public E getPrimeiro() throws NoSuchElementException, NullPointerException{
        return lista.getFirst();
    }

    @Override
    public E getUltimo() throws NoSuchElementException, NullPointerException{
        return lista.getLast();
    }

    @Override
    public boolean contem(E elemento) {
        return lista.contains(elemento);
    }

    @Override
    public String toString() {
        return (lista != null ? lista : "Lista Vazia!")+ "\n";
    }
    
    
}
