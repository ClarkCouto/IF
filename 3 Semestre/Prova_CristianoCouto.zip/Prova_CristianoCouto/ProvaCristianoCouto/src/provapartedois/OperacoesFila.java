/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package provapartedois;

/**
 *
 * @author CristianoCouto
 */
public interface OperacoesFila <E> {
    public boolean adicionar(E elemento);
    public E remover();
    public E getPrimeiro();
    public E getUltimo();
    public boolean contem(E elemento);
    public String toString();
}
