package provapartedois.DAO;

import java.sql.*;

/**
 *
 * @author CristianoCouto
 */
public class ConnectionFactory {
    public Connection getConnection() throws ClassNotFoundException, SQLException{
           Class.forName("com.mysql.jdbc.Driver");
           String urlBD="jdbc:mysql://localhost:3306/prova";
           return DriverManager.getConnection(urlBD, "root", "");
    }
}
