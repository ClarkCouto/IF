/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package provapartedois.DAO;

/**
 *
 * @author CristianoCouto
 */
public enum DataSQLs {
    INSERT("insert into data(dia, mes, ano) values (?, ?, ?)"), 
    UPDATE("update data set dia = ?, mes = ?, ano = ? where idData = ?"), 
    FINDBYID("select * from data where idData = ?"), 
    DELETE("delete from data where idData = ?"), 
    LISTALL("select * from data");
    
    private final String sql;
    DataSQLs(String sql){
        this.sql = sql; 
    }

    public String getSql() {
        return sql;
    }    
}
