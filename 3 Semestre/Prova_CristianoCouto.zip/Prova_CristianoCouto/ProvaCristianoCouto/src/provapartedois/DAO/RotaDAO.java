/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package provapartedois.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;
//import javax.swing.JOptionPane;
import provapartedois.Rota;

/**
 *
 * @author CristianoCouto
 */
public class RotaDAO implements GenericDAO<Rota>{

    @Override
    public int insert(Rota rota) {
        int chavePrimaria = -1;
        
        try (Connection connection = new ConnectionFactory().getConnection();
                PreparedStatement stmt = connection.prepareStatement(RotaSQLs.INSERT.getSql(),
                        Statement.RETURN_GENERATED_KEYS)) {
            System.out.println("Conexão Insert Rota aberta!");
            stmt.setString(1, rota.getNome());
            stmt.setString(2, rota.getDescricao());
            stmt.execute();
            
            System.out.println("Dados da Rota gravados com Sucesso!");
            ResultSet chaves = stmt.getGeneratedKeys();
            if (chaves.next()) {
                chavePrimaria = chaves.getInt(1);
            }
        } 
        catch (SQLException e) {
            System.out.println("Exceção com recursos em Insert Rota! " + e.getSQLState());
        } 
        catch (ClassNotFoundException e) {
            System.out.println("Classe não encontrada Insert Rota!");
        }
        return chavePrimaria;
    }

@Override
    public List<Rota> listAll() {
        List<Rota> lista = new LinkedList<>();

        try (Connection connection = new ConnectionFactory().getConnection();
            PreparedStatement stmt = connection.prepareStatement(RotaSQLs.LISTALL.getSql())) {

            //JOptionPane.showMessageDialog(null,"connected with "+connection.toString());
            System.out.println("Conexão listAll Rota aberta!");
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int idRota = rs.getInt("idRota");
                String nome = rs.getString("nome");
                String descricao = rs.getString("descricao");
                lista.add(new Rota(idRota, nome, descricao));
            }
            return lista;
        } 
        catch (SQLException e) {
            System.out.println("Exceção SQL em listAll Rota! " + e.getSQLState());
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada listAll Rota!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código em listAll Rota!");
        }
        return null;
    }

    @Override
    public int delete(Rota rota) {
        try (Connection connection = new ConnectionFactory().getConnection();
                PreparedStatement stmt = connection.prepareStatement(RotaSQLs.DELETE.getSql())) {
            System.out.println("Conexão Delete Rota aberta!");
            stmt.setInt(1, rota.getIdRota());
            return stmt.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println("Exceção SQL em Delete Rota! " + e.getSQLState());
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada em Delete Rota!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código em Delete Rota!");
        }
        return 0;
    }

    @Override
    public int update(Rota rota) {
        try (Connection connection = new ConnectionFactory().getConnection();
                PreparedStatement stmt = connection.prepareStatement(RotaSQLs.UPDATE.getSql())) {
            System.out.println("\nConexão Update Rota aberta!");
            stmt.setString(1, rota.getNome());
            stmt.setString(2, rota.getDescricao());
            stmt.setInt(3, rota.getIdRota());
            return stmt.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println("Exceção SQL em Update Rota! " + e.getMessage());
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada em Update Rota!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código em Update Rota!");
        }
        return 0;
    }

    @Override
    public Rota findByID(int id) {
        try (Connection connection = new ConnectionFactory().getConnection();
            PreparedStatement stmt = connection.prepareStatement(RotaSQLs.FINDBYID.getSql())) {

            System.out.println("Conexão FindById Rota aberta!");
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int idRota = rs.getInt("idRota");
                String nome = rs.getString("nome");
                String descricao = rs.getString("descricao");
                return new Rota(idRota, nome, descricao);
            }
        } 
        catch (SQLException e) {
            System.out.println("Exceção SQL em FindById Rota! " + e.getSQLState());
        }
        catch (ClassNotFoundException e) {
            System.out.println("Classe/Tabela não encontrada em FindById Rota!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código em FindById Rota!");
        }
        return null;
    }
}

