/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package provapartedois.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;
//import javax.swing.JOptionPane;
import provapartedois.Data;

/**
 *
 * @author CristianoCouto
 */
public class DataDAO implements GenericDAO<Data>{

    @Override
    public int insert(Data data) {
        int chavePrimaria = -1;
        
        try (Connection connection = new ConnectionFactory().getConnection();
                PreparedStatement stmt = connection.prepareStatement(DataSQLs.INSERT.getSql(),
                        Statement.RETURN_GENERATED_KEYS)) {
            System.out.println("Conexão Insert Data aberta!");
            stmt.setInt(1, data.getDia());
            stmt.setInt(2, data.getMes());
            stmt.setInt(3, data.getAno());
            stmt.execute();
            
            System.out.println("Dados da Data gravados com Sucesso!");
            ResultSet chaves = stmt.getGeneratedKeys();
            if (chaves.next()) {
                chavePrimaria = chaves.getInt(1);
            }
        } 
        catch (SQLException e) {
            System.out.println("Exceção com recursos em Insert Data! " + e.getSQLState());
        } 
        catch (ClassNotFoundException e) {
            System.out.println("Classe não encontrada Insert Data!");
        }
        return chavePrimaria;
    }

@Override
    public List<Data> listAll() {
        List<Data> lista = new LinkedList<>();

        try (Connection connection = new ConnectionFactory().getConnection();
            PreparedStatement stmt = connection.prepareStatement(DataSQLs.LISTALL.getSql())) {

            //JOptionPane.showMessageDialog(null,"connected with "+connection.toString());
            System.out.println("Conexão listAll Data aberta!");
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int idData = rs.getInt("idData");
                int dia = rs.getInt("dia");
                int mes = rs.getInt("mes");
                int ano = rs.getInt("ano");
                lista.add(new Data(idData, dia, mes, ano));
            }
            return lista;
        } 
        catch (SQLException e) {
            System.out.println("Exceção SQL em listAll Data! " + e.getSQLState());
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada listAll Data!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código em listAll Data!");
        }
        return null;
    }

    @Override
    public int delete(Data data) {
        try (Connection connection = new ConnectionFactory().getConnection();
                PreparedStatement stmt = connection.prepareStatement(DataSQLs.DELETE.getSql())) {
            System.out.println("Conexão Delete Data aberta!");
            stmt.setInt(1, data.getIdData());
            return stmt.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println("Exceção SQL em Delete Data! " + e.getSQLState());
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada em Delete Data!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código em Delete Data!");
        }
        return 0;
    }

    @Override
    public int update(Data data) {
        try (Connection connection = new ConnectionFactory().getConnection();
                PreparedStatement stmt = connection.prepareStatement(DataSQLs.UPDATE.getSql())) {
            System.out.println("\nConexão Update Data aberta!"); 
            stmt.setInt(1, data.getDia());
            stmt.setInt(2, data.getMes());
            stmt.setInt(3, data.getAno());
            stmt.setInt(4, data.getIdData());
            return stmt.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println("Exceção SQL em Update Data! " + e.getMessage());
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada em Update Data!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código em Update Data!");
        }
        return 0;
    }

    @Override
    public Data findByID(int id) {
        try (Connection connection = new ConnectionFactory().getConnection();
            PreparedStatement stmt = connection.prepareStatement(DataSQLs.FINDBYID.getSql())) {

            System.out.println("Conexão FindById Data aberta!");
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int idData = rs.getInt("idData");
                int dia = rs.getInt("idData");
                int mes = rs.getInt("idData");
                int ano = rs.getInt("idData");
                return new Data(idData, dia, mes, ano);
            }
        } 
        catch (SQLException e) {
            System.out.println("Exceção SQL em FindById Data! " + e.getSQLState());
        }
        catch (ClassNotFoundException e) {
            System.out.println("Classe/Tabela não encontrada em FindById Data!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código em FindById Data!");
        }
        return null;
    }
}

