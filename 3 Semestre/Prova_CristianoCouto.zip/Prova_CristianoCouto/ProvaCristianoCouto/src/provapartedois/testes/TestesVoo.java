/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package provapartedois.testes;

import java.util.List;
import provapartedois.Data;
import provapartedois.Rota;
import provapartedois.Voo;

/**
 *
 * @author 0729159
 */
public class TestesVoo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Voo voo = new Voo(1, "Delta", "10:00", "12:00", new Rota("POA-MCO", "Rota Porto Alegre - Orlando"), new Data(1, 11, 2017));
        voo.insert();
        voo = new Voo(2, "Delta", "11:00", "21:00", new Rota("GIG-MIA", "Rota Galeão - Miami"), new Data(5, 12, 2016));
        voo.insert();
        voo = new Voo(3, "Azul", "09:00", "12:00", new Rota("GIG-BSB", "Rota Galeão-Brasília"), new Data(1, 7, 2015));
        voo.insert();
        voo = new Voo(4, "Ethiad", "05:00", "07:00", new Rota("POA-GIG", "Rota Porto Alegre - Galeão"), new Data(1, 8, 2012));
        voo.insert();
        
        List<Voo> lista = voo.listAll();
        if(lista.isEmpty())
            System.out.println("Lista está vazia!");
        else{
            for(Voo v : lista)
                 System.out.println(v.toString());
        }
    }
    
}
