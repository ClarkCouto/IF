/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banco;

import classes.Aluno;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author CristianoSilva
 */
public class AlunoDAO implements GenericDAO<Aluno>{

    @Override
    public List<Aluno> listAll() {
        List<Aluno> lista = new LinkedList<>();

        try (Connection connection = new ConnectionFactory().getConnection();
            PreparedStatement stmt = connection.prepareStatement(AlunoSQLs.LISTALL.getSql())) {

            System.out.println("Conexão listAll Endereco aberta!");
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String nome = rs.getString("nome");
                int matricula = rs.getInt("matricula");
                String endereco = rs.getString("endereco");
                lista.add(new Aluno(id, nome, matricula, endereco));
            }
            return lista;
        } 
        catch (SQLException e) {
            System.out.println("Exceção SQL em listAll Aluno");
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada listAll Aluno!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código em listAll Aluno!");
        }
        return null;
    }
}

