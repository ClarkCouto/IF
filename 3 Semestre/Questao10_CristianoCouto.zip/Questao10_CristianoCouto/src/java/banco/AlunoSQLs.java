/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banco;

/**
 *
 * @author CristianoSilva
 */
public enum AlunoSQLs {
    //INSERT("insert into aluno(logradouro, complemento) values (?, ?)"), 
    //UPDATE("update endereco set logradouro = ?, complemento = ? where idEndereco = ?"), 
    //FINDBYID("select * from endereco where idEndereco = ?"), 
    //DELETE("delete from endereco where idEndereco = ?"), 
    LISTALL("select * from aluno");
    
    private final String sql;
    AlunoSQLs(String sql){
        this.sql = sql; 
    }

    public String getSql() {
        return sql;
    }    
}
