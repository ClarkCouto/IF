
package br.edu.ifrs.poa.lpoo1.formas;

public class Teste3 {
	
	public Teste3() {
		super();
	}
	
}
