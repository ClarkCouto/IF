package br.edu.ifrs.poa.lpoo1.treslados;

import br.edu.ifrs.poa.lpoo1.formas.Figura;

public class TrianguloEquilatero extends Figura {

	private double lado;
	
	public TrianguloEquilatero() {
		super();
	}
	
	public TrianguloEquilatero(double lado) {
		super();
		this.lado = lado;
	}


	public double getLado() {
		return lado;
	}

	public void setLado(double lado) {
		this.lado = lado;
	}
	

	@Override
	public double calculaArea() {
		
		double height = Math.sqrt(Math.pow(lado, 2) - Math.pow((lado / 2), 2));
		
		return (lado * height) / 2;
	}
	
	@Override
	public String toString() {
		return "TrianguloEquilatero [lado=" + lado + "]";
	}

}
