package br.edu.ifrs.poa.lpoo1.semlados;

public class Teste2 {

	public Teste2() {
		super();
	}
	
}
