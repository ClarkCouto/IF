package br.edu.ifrs.poa.lpoo1.semlados;

import br.edu.ifrs.poa.lpoo1.formas.Figura;

public class Circulo extends Figura {
	public static final double PI = 3.1415;
	
	private double raio;
	
	public Circulo() {
		super();
	}
	
	public Circulo(double raio) {
		super();
		this.raio = raio;
	}

	public double getRaio() {
		return raio;
	}

	public void setRaio(double raio) {
		this.raio = raio;
	}
	
	public double calculaArea() {
		return Circulo.PI * Math.pow(raio, 2); 
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}
	
}
