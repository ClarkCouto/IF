package br.edu.ifrs.poa.lpoo1.formas;

import br.edu.ifrs.poa.lpoo1.util.Cor;

public abstract class Figura {
	static int contador;
	protected Cor cor;
	
	public abstract double calculaArea();
	
	public static int getContador() {
		return contador;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}
		
}
