package br.edu.ifrs.poa.lpoo1.doislados;

import br.edu.ifrs.poa.lpoo1.formas.Figura;

public class Quadrado extends Figura {
	
	private double lado;

	public Quadrado(){
		super();
	}
	
	public Quadrado(double lado) {
		super();
		this.lado = lado;
	}
		
	
	public double getLado() {
		return lado;
	}

	public void setLado(double lado) {
		this.lado = lado;
	}
	
	@Override
	public String toString() {
		return "Quadrado [lado=" + lado + "]";
	}

	public double calculaArea() {
		return Math.pow(lado, 2);
	}
	
	
}
