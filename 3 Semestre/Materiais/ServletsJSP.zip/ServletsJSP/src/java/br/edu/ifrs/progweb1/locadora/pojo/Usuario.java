package br.edu.ifrs.progweb1.locadora.pojo;

import br.edu.ifrs.progweb1.locadora.model.UsuarioDAO;

public class Usuario {
    private Integer idUsuario;
    private String senha;
    private String nome;
    private String nomeCompleto;
    private String email;

    public Integer getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(Integer codUsuario) {
        this.idUsuario = codUsuario;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getNomeCompleto() {
        return nomeCompleto;
    }

    public void setNomeCompleto(String nomeCompleto) {
        this.nomeCompleto = nomeCompleto;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
