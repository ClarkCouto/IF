package br.edu.ifrs.progweb1.locadora.controller;

import br.edu.ifrs.progweb1.locadora.model.UsuarioDAO;
import br.edu.ifrs.progweb1.locadora.pojo.Usuario;
import java.io.IOException;
import java.util.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ControllerUsuario {
    @SuppressWarnings("static-access")
    public static String login(HttpServletRequest request) {        
        
        String erro="";        
        String jsp="";        
           
        Usuario usr = new Usuario();
        System.out.println(request.getParameter("nome"));
        System.out.println(request.getParameter("senha"));
        usr.setNome(request.getParameter("nome"));
        usr.setSenha(request.getParameter("senha"));
        try {
            usr = new UsuarioDAO().validate(usr);
            if(usr == null){
                erro="Usuário não encontrado!";
                request.setAttribute("erro", erro);
                jsp = "/erro.jsp";
            }               
            else{
                request.getSession().setAttribute("idusuario", usr.getIdUsuario());                
                jsp = "/menu.jsp";
            }
        } catch (Exception e) {
            e.printStackTrace();
            jsp = "";
        }
        return jsp;        
     }
    
    public static void validarSessao(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
        Integer idUsuario = (Integer) request.getSession().getAttribute("idusuario");
        String jsp="";
        if(idUsuario == null ){
            jsp = "/index.jsp";
             //Redirecionando pagina
            RequestDispatcher rd = request.getRequestDispatcher(jsp);
            rd.forward(request, response);
        }        
    }
    public static String listar(HttpServletRequest request) {
        String jsp = "";
        try {
            List<Usuario> listUsuario = new UsuarioDAO().getAll();
            if(listUsuario != null){
                request.setAttribute("listUsuario", listUsuario);
                jsp = "/listarusuario.jsp";
            }else{
                String erro = "Nao existe registro!";
                request.setAttribute("erro", erro);
                jsp = "/erro.jsp";
            }
        } catch (Exception e) {
            e.printStackTrace();
            jsp = "";
        }
        return jsp;
    }
    public static String alterar(HttpServletRequest request) {
        String jsp = "";
        try {
            String idUsuario = request.getParameter("idusuario");
            System.out.println("id1 = "+idUsuario);
            Usuario usuario = new UsuarioDAO().findByID(Integer.parseInt(idUsuario));
            if(usuario != null){
                request.setAttribute("usuario",usuario);
                jsp = "/alterarusuario.jsp";
            }else{
                String erro = "Ocorreu erro ao Alterar Usuário!";
                request.setAttribute("erro", erro);
                jsp = "/erro.jsp";
            }
        } catch (Exception e) {
            e.printStackTrace();
            jsp = "";
        }
        return jsp;
    }
    
    public static String excluir(HttpServletRequest request) {
        String jsp = "";
        try {
            String cod = request.getParameter("idusuario");
            Usuario usuario = new UsuarioDAO().findByID(Integer.parseInt(cod));
            int delete = new UsuarioDAO().delete(usuario);
            if(delete != 0){
                jsp = ControllerUsuario.listar(request);
            }else{
                String erro = "Ocorreu erro ao Excluir Usuário!";
                request.setAttribute("erro", erro);
                jsp = "/erro.jsp";
            }
        } catch (Exception e) {
            e.printStackTrace();
            jsp = "";
        }
        return jsp;
    }
    public static String gravarAlteracao(HttpServletRequest request) {
        String jsp = "";
        try {
            
            String idUsuario = request.getParameter("idusuario");
            System.out.println("id = "+idUsuario);
            String nome = request.getParameter("nome");
            String nomeCompleto = request.getParameter("nomecompleto");
            String email = request.getParameter("email");
            String senha = request.getParameter("senha");
            Usuario usuario = new Usuario();
            usuario.setIdUsuario(Integer.parseInt(idUsuario));
            usuario.setNome(nome);
            usuario.setNomeCompleto(nomeCompleto);
            usuario.setEmail(email);
            usuario.setSenha(senha);
            
            int delete = new UsuarioDAO().update(usuario);
            if(delete!=0)
                jsp = ControllerUsuario.listar(request);
            else{
                String erro = "Nao foi possivel gravar a alteração desse registro";
                request.setAttribute("erro", erro);
                jsp = "/erro.jsp";
            }
        } catch (Exception e) {
            e.printStackTrace();
            jsp = "";
        }
        return jsp;
    }
    public static String gravarInsercao(HttpServletRequest request) {
        String jsp = "";
        try {
            String nome = request.getParameter("nome");
            String nomeCompleto = request.getParameter("nomecompleto");
            String email = request.getParameter("email");
            String senha = request.getParameter("senha");
            Usuario usuario = new Usuario();
            usuario.setNome(nome);
            usuario.setNomeCompleto(nomeCompleto);
            usuario.setEmail(email);
            usuario.setSenha(senha);
            
            int insert = new UsuarioDAO().insert(usuario);
            if(insert != 0){
                jsp = ControllerUsuario.listar(request);    
            }else{
                String erro = "Nao foi possivel gravar esse registro!";
                request.setAttribute("erro", erro);
                jsp = "/erro.jsp";
            }
        } catch (Exception e) {
            e.printStackTrace();
            jsp = "";
        }
        return jsp;
    }
    
    public static String inserir(HttpServletRequest request) {
        String jsp = "";
        try {
            List<Usuario> listUsuario = new UsuarioDAO().getAll();
            if(listUsuario != null){                
                request.setAttribute("listUsuario", listUsuario);
                jsp = "/inserirusuario.jsp";
             }else{
                String erro = "Nao existem registros!";
                request.setAttribute("erro", erro);
                jsp = "/erro.jsp";    
            }
        } catch (Exception e) {
            e.printStackTrace();
            jsp = "";
        }
        return jsp;
    }
    
     public static String sair(HttpServletRequest request)throws ServletException, IOException {
        request.getSession().invalidate();
        return "/index.jsp";
     }

}
