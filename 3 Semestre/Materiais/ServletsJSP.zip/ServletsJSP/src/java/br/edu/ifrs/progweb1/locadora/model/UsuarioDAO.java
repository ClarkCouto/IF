package br.edu.ifrs.progweb1.locadora.model;

import java.sql.*;
import br.edu.ifrs.progweb1.locadora.pojo.Usuario;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO implements GenericDAO<Usuario> {

    private static PreparedStatement pstmt = null;
    private static ResultSet rs = null;

    @Override
    public int insert(Usuario usuario) {
        int retorno = 0;
        try {
            pstmt = ConnectionFactory.getConnection().prepareStatement(SQLs.USR_INSERT.getSql());
            pstmt.setString(1, usuario.getSenha());
            pstmt.setString(2, usuario.getNome());
            pstmt.setString(3, usuario.getNomeCompleto());
            pstmt.setString(4, usuario.getEmail());
            retorno = pstmt.executeUpdate();
            pstmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return retorno;
    }

    @Override
    public int update(Usuario usuario) {
        int retorno = 0;
        try {
            pstmt = ConnectionFactory.getConnection().prepareStatement(SQLs.USR_UPDATE.getSql());
            pstmt.setString(1, usuario.getSenha());
            pstmt.setString(2, usuario.getNome());
            pstmt.setString(3, usuario.getNomeCompleto());
            pstmt.setString(4, usuario.getEmail());
            pstmt.setInt(5, usuario.getIdUsuario());
            retorno = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return retorno;
    }

    public int delete(Usuario usuario) {
        int retorno = 0;
        try {
            pstmt = ConnectionFactory.getConnection().prepareStatement(SQLs.USR_DELETE.getSql());
            pstmt.setInt(1, usuario.getIdUsuario());
            retorno = pstmt.executeUpdate();
            pstmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return retorno;
    }

    @Override
    public List<Usuario> getAll() {
        try {
            List<Usuario> lista = new ArrayList<>();
            pstmt = ConnectionFactory.getConnection().prepareStatement(SQLs.USR_LISTALL.getSql());
            rs = pstmt.executeQuery();
            while (rs.next()) {
                Usuario usuario = new Usuario();
                usuario.setIdUsuario(rs.getInt("idUsuario"));
                usuario.setSenha(rs.getString("senha"));
                usuario.setNome(rs.getString("nome"));
                usuario.setNomeCompleto(rs.getString("nomeCompleto"));
                usuario.setEmail(rs.getString("email"));
                lista.add(usuario);
            }
            rs.close();
            pstmt.close();
            return lista;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public Usuario findByID(int Id) {
        Usuario usuario = null;
        try {
            pstmt = ConnectionFactory.getConnection().prepareStatement(SQLs.USR_FIND_BY_ID.getSql());
            pstmt.setInt(1, Id);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                usuario = new Usuario();
                usuario.setIdUsuario(rs.getInt("idUsuario"));
                usuario.setSenha(rs.getString("senha"));
                usuario.setNome(rs.getString("nome"));
                usuario.setNomeCompleto(rs.getString("nomeCompleto"));
                usuario.setEmail(rs.getString("email"));
            }
            rs.close();
            pstmt.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return usuario;
    }

    public Usuario validate(Usuario user) {
        try {
            pstmt = ConnectionFactory.getConnection().prepareStatement(SQLs.USR_VALIDA.getSql());
            pstmt.setString(1, user.getNome());
            pstmt.setString(2, user.getSenha());
            rs = pstmt.executeQuery();
            if (rs.next()) {
                user = new Usuario();
                user.setIdUsuario(rs.getInt("idUsuario"));
                user.setSenha(rs.getString("senha"));
                user.setNome(rs.getString("nome"));
                user.setNomeCompleto(rs.getString("nomeCompleto"));
                user.setEmail(rs.getString("email"));
            }
            return user;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
}
