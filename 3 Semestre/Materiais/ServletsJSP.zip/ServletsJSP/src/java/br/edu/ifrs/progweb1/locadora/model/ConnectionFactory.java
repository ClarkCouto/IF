package br.edu.ifrs.progweb1.locadora.model;
import java.sql.*;

public class ConnectionFactory {
    private static Connection con = null;
    public static Connection conect(String usuario, String senha) {
        try{
           Class.forName("com.mysql.jdbc.Driver");
           String urlBD="jdbc:mysql://localhost:3306/progweb1";
           con = DriverManager.getConnection(urlBD, usuario, senha);
           return con;
        }catch(ClassNotFoundException e){
            System.out.println("Classe do driver não encontrada");
        }catch(SQLException e){
            System.out.println("Exceção no SQL - getConnection()");
        }
        return null;
    }
    public static Connection getConnection() {
        return con;
    }
    
    public static void destroy() {
        try {
            con = null;
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }


}
