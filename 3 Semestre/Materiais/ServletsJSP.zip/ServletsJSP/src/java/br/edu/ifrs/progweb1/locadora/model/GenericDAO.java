package br.edu.ifrs.progweb1.locadora.model;

public interface GenericDAO <T> {
    public int insert(T obj);
    public int update(T obj);
    public int delete(T obj);
    public java.util.List<T> getAll();
    public T findByID(int id);
}

