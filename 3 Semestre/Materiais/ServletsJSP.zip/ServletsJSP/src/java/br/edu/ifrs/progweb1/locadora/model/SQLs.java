package br.edu.ifrs.progweb1.locadora.model;

public enum SQLs {
    //USUÁRIO
    USR_VALIDA("SELECT * FROM Usuario WHERE nome=? AND senha=?"),
    USR_INSERT("INSERT INTO Usuario(senha, nome, nomeCompleto, email) Values(?,?,?,?)"), 
    USR_UPDATE("UPDATE Usuario SET senha=?, nome=?, nomeCompleto=?, email=? WHERE idUsuario = ?"),
    USR_DELETE("DELETE FROM Usuario WHERE idUsuario = ?"),
    USR_LISTALL("SELECT * FROM Usuario ORDER BY nome"),
    USR_FIND_BY_ID("SELECT * FROM Usuario WHERE idUsuario = ?");
    
    private final String sql;
    SQLs(String sql){
        this.sql = sql; 
    
    }

    public String getSql() {
        return sql;
    }    
}

