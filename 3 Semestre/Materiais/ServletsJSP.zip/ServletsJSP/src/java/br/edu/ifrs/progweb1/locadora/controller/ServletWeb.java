package br.edu.ifrs.progweb1.locadora.controller;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import br.edu.ifrs.progweb1.locadora.model.ConnectionFactory;

public class ServletWeb extends HttpServlet {

    private ServletContext sc;
    private String jsp = "";

    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        sc = config.getServletContext();
        ConnectionFactory.conect(sc.getInitParameter("usuario"),
                sc.getInitParameter("senha"));
    }

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String acao = request.getParameter("acao");
        switch (acao) {
            case "Logar":
                jsp = ControllerUsuario.login(request);
                break;
            case "ListarUsuario":
                jsp = ControllerUsuario.listar(request);
                break;
            case "InserirUsuario":
                jsp = ControllerUsuario.inserir(request);
                break;
            case "AlterarUsuario":
                jsp = ControllerUsuario.alterar(request);
                break;
            case "GravarAlteracaoUsuario":
                jsp = ControllerUsuario.gravarAlteracao(request);
                break;
            case "GravarInsercaoUsuario":
                jsp = ControllerUsuario.gravarInsercao(request);
                break;
            case "ExcluirUsuario":
                jsp = ControllerUsuario.excluir(request);
                break;
            case "Sair":
                jsp = ControllerUsuario.sair(request);
                break;                
            default:
                break;
        }
        //Redirecionando pagina
        RequestDispatcher rd = request.getRequestDispatcher(jsp);
        rd.forward(request, response);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
    @Override
    public void destroy() {
        ConnectionFactory.destroy();
    }

}
