/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.util.LinkedList;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

/**
 *
 * @author mathe
 */
@ManagedBean
public class FuncionarioBean {
    private Funcionario funcionario = new Funcionario();
    private LinkedList<Funcionario> lista = new LinkedList<>();    
    
    // Getters && Setters

    public Funcionario getFuncionario() {        
        return funcionario;
    }

    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }

    public LinkedList<Funcionario> getLista() {
        if (lista.isEmpty()) {
            return funcionario.listar();
        }
        return lista;
    }    

    public String salvar(){
        System.out.println("Nome Conjuge = " + funcionario.getNomeConjuge());
        lista.add(funcionario);
        return "ListarFuncionarios";
    }

    public void imprimir(){
        System.out.println(funcionario);
    }
}
