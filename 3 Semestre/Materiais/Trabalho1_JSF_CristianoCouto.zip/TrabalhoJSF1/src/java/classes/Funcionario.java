/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.util.LinkedList;
import javax.faces.bean.ManagedBean;

/**
 *
 * @author mathe
 */

public class Funcionario {
    private String nome;
    private double salario;
    private String UF;
    private String estadoCivil;
    private String nomeConjuge;
    private String situacao;
    private String observacoes;
    
    // Construtores

    public Funcionario() {
    }

    public Funcionario(String nome, double salario, String UF, String estadoCivil, String nomeConjuge, String situacao, String observacoes) {
        this.nome = nome;
        this.salario = salario;
        this.UF = UF;
        this.estadoCivil = estadoCivil;
        this.nomeConjuge = nomeConjuge;
        this.situacao = situacao;
        this.observacoes = observacoes;
    }

    // Getters && Setters

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public String getUF() {
        return UF;
    }

    public void setUF(String UF) {
        this.UF = UF;
    }

    public String getEstadoCivil() {
        return estadoCivil;
    }

    public void setEstadoCivil(String estadoCivil) {
        this.estadoCivil = estadoCivil;
    }

    public String getNomeConjuge() {
        return nomeConjuge;
    }

    public void setNomeConjuge(String nomeConjuge) {
        this.nomeConjuge = nomeConjuge;
    }

    public String getSituacao() {
        return situacao;
    }

    public void setSituacao(String situacao) {
        this.situacao = situacao;
    }

    public String getObservacoes() {
        return observacoes;
    }

    public void setObservacoes(String observacoes) {
        this.observacoes = observacoes;
    }       
    
    // Outros métodos

    @Override
    public String toString() {
        return "Funcionario{" + "nome=" + nome + ", salario=" + salario + ", UF=" + UF + ", estadoCivil=" + estadoCivil + ", nomeConjuge=" + nomeConjuge + ", situacao=" + situacao + ", observacoes=" + observacoes + '}';
    }
    
    public LinkedList<Funcionario> listar() {
        LinkedList<Funcionario> lista = new LinkedList<>();
        lista.add(new Funcionario("Matheus", 400, "RS", "solteiro", "", "ativo", ""));
        lista.add(new Funcionario("Luiza", 700, "PR", "casado", "Júlia", "em licensa", "Lorem Ipsum"));
        return lista;
    }
    
}
