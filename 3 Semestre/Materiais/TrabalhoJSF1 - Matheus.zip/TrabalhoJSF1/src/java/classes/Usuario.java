/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.util.LinkedList;

/**
 *
 * @author mathe
 */
public class Usuario {
    private String usuario;
    private String senha;
    
    // Construtores

    public Usuario() {
    }

    public Usuario(String usuario, String senha) {
        this.usuario = usuario;
        this.senha = senha;
    }
    
    // Getters && Setters

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
    
    // Outros métodos

    @Override
    public String toString() {
        return "Usuario{" + "usuario=" + usuario + ", senha=" + senha + '}';
    }
    
    public LinkedList<Usuario> listar() {
        LinkedList<Usuario> lista = new LinkedList<>();      
        lista.add(new Usuario("matheus", "1234"));
        lista.add(new Usuario("diego", "1212"));
        return lista;
    }
    
}
