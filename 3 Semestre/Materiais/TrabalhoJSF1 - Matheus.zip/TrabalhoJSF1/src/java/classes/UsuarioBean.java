/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.util.LinkedList;
import javax.faces.bean.ManagedBean;

/**
 *
 * @author mathe
 */
@ManagedBean
public class UsuarioBean {
   private Usuario usuario = new Usuario();
   private LinkedList<Usuario> usuarios = new LinkedList<>();
   
   // Getters && Setters

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public LinkedList<Usuario> getUsuarios() {
        return usuarios;
    }
    
    public String salvar(){
        usuarios.add(usuario);
        return "ListaUsuarios";
    }
    
    // Outros métodos
    
    public String entrar() {
        System.out.println(usuario);
        System.out.println(usuario.listar().getFirst());
        for(Usuario u : usuario.listar()){
            if (u.getUsuario().equals(usuario.getUsuario())
                && u.getSenha().equals(usuario.getSenha())) {
                return "ListarFuncionarios";
            }
        }
       
        return null;
    }

}
