package exercicio13_Mapa_Clientes;


import java.util.Map;
import java.util.TreeMap;

public class MapaClientes {

	public static void main(String[] args) {
		TreeMap<Long, ClientePF> mapaClientes =  new TreeMap<Long, ClientePF>();
		mapaClientes.put(1598825089L, new ClientePF("Clark", new Endereco ("Adao Baino, 701", "Apto 409"), new Telefone(51, 985436313)));
		
		for (Map.Entry<Long,ClientePF> entry : mapaClientes.entrySet()) {
	        Long key = entry.getKey();
			ClientePF value = entry.getValue();
			System.out.println("Cliente: " + key.toString() + "\n" + value.toString());
	   }
	}

}
