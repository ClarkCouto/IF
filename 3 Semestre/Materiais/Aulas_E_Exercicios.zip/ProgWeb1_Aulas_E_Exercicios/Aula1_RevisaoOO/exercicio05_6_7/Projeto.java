package exercicio05_6_7;

public class Projeto {
	String titulo;
	Data dataInicio;
	Data dataFim;
	
	public Projeto(){};
	public Projeto(String titulo, Data dataInicio, Data dataFim) {
		this.titulo = titulo;
		this.dataInicio = dataInicio;
		this.dataFim = dataFim;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public Data getDataInicio() {
		return dataInicio;
	}
	public void setDataInicio(Data dataInicio) {
		this.dataInicio = dataInicio;
	}
	public Data getDataFim() {
		return dataFim;
	}
	public void setDataFim(Data dataFim) {
		this.dataFim = dataFim;
	}
	@Override
	public String toString() {
		return "Projeto: " + titulo + " Data Início: " + (dataInicio != null ? dataInicio : "Não informada") + " Data Fim: " + (dataFim != null ? dataFim : "Não informada") + "\n";
	}
	
	
}
