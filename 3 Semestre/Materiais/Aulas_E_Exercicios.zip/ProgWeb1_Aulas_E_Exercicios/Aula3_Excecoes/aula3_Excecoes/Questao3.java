package aula3_Excecoes;
 public class Questao3{
    public static void main(String args[]) {
    	int i = 5571;
    	try{
    		i = i / 0;
    		System.out.println("O resultado " + i);
    	}
    	catch(ArithmeticException e){
    		System.out.println("N�o � poss�vel dividir por 0!");
    	}
    	catch(Exception e){
    		System.out.println("Ocorreu uma exce��o indeterminada!");
    		e.printStackTrace();
    	}
    }
}
