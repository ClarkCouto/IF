package Arquivos;
import java.io.IOException;
import java.nio.file.*;

public class Questao10 {
	public static void main(String[] args){
		FileSystem fs = FileSystems.getDefault();
		Path diretorio = null;
		try{
			diretorio = fs.getPath("C:", "Diretorio", "Teste");
		}
		catch(InvalidPathException ex){
			System.out.println("Caminho inv�lido! " + ex.getMessage());
		}

		Path arquivo = diretorio.resolve("Teste.txt");
		
		try {
			Files.createDirectories(diretorio);
		} 
		catch (UnsupportedOperationException ex) {
			System.out.println("Opera��o n�o permitida! " + ex.getMessage());
		}
		catch (FileAlreadyExistsException ex) {
			System.out.println("Diret�rio j� existe! " + ex.getMessage());
		}
		catch (IOException ex) {
			System.out.println("Exce��o de Leitura/Escrita!" + ex.getMessage());
		}
		catch (Exception ex) {
			System.out.println("Exce��o n�o tratada!" + ex.getMessage());
			ex.printStackTrace();
		}
		
		try{
			Files.createFile(arquivo);
		}
		catch (UnsupportedOperationException ex) {
			System.out.println("Opera��o n�o permitida! " + ex.getMessage());
			;
		}
		catch (FileAlreadyExistsException ex) {
			System.out.println("Arquivo j� existe! " + ex.getMessage());
		}
		catch (IOException ex) {
			System.out.println("Exce��o de Leitura/Escrita de arquivo!" + ex.getMessage());
		}
		catch (Exception ex) {
			System.out.println("Exce��o n�o tratada!" + ex.getMessage());
			ex.printStackTrace();
		}

	}
}
