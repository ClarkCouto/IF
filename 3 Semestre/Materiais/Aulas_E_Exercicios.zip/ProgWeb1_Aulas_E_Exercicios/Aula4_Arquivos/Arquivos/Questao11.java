package Arquivos;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;

public class Questao11 { 
	public static void main(String[] args) {
		FileSystem fs = FileSystems.getDefault();
		List<String> list = criarListaString(); 
		Path diretorio = fs.getPath("C:", "Diretorio", "Teste");
		Path arquivo = diretorio.resolve("teste.txt");
		Charset charset = Charset.forName("UTF-8");
		try {
			Files.write(arquivo, list, charset, StandardOpenOption.APPEND);
		} 
		catch (UnsupportedOperationException ex) {
			System.out.println("Opera��o n�o permitida! " + ex.getMessage());
		}
		catch (SecurityException ex) {
			System.out.println("Exce��o de seguran�a! " + ex.getMessage());
		}
		catch (IOException ex) {
			System.out.println("Exce��o I/O - Escrevendo no arquivo!" + ex.getMessage());
		}
		catch (Exception ex) {
			System.out.println("Exce��o n�o tratada!" + ex.getMessage());
			ex.printStackTrace();
		}
		lerArquivo(arquivo, charset);
	}
	private static List<String> criarListaString () {
		List<String> list = new ArrayList<String>();
		list.add("ABC"); 
		list.add("DEF"); 
		list.add("GHI"); 
		list.add("JKL");
		list.add("MNO");
		return list; 
	}

	private static void lerArquivo(Path arquivo, Charset charset){
		List<String> list = null;
		try {
			System.out.println("Lendo Arquivo...");
			list = Files.readAllLines(arquivo, charset);
		}
		catch (UnsupportedOperationException ex) {
			System.out.println("Opera��o n�o permitida! " + ex.getMessage());
		}
		catch (SecurityException ex) {
			System.out.println("Exce��o de seguran�a! " + ex.getMessage());
		}
		catch (IOException ex) {
			System.out.println("Exce��o I/O - lendo arquivo!" + ex.getMessage());
		}
		catch (Exception ex) {
			System.out.println("Exce��o n�o tratada!" + ex.getMessage());
			ex.printStackTrace();
		}
		for(String linha : list){
			System.out.println(linha);
		}
	}
}
