package Arquivos;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Questao2{
	public static void main(String[] args) {
		//gravando caracteres e Strings
		File arquivoEscrita = new File("Ex2.txt");
		
		try(FileWriter fw = new FileWriter(arquivoEscrita);){
			fw.write('2');
			fw.write("2");
		} 
		catch (IOException ex) {
			System.out.println("Exce��o de Leitura/Escrita de arquivo!" + ex.getMessage());
		}
		//gravando caracteres e Strings
		File arquivoLeitura = new File("Ex2.txt");
		try(FileReader fr = new FileReader(arquivoLeitura);){
			int  c =   fr.read();
			while( c != -1){
			     System.out.print( (char) c );
			     c =  fr.read();
			}
		} 
		catch (FileNotFoundException ex) {
			System.out.println("Arquivo n�o encontrado!" + ex.getMessage());
		}
		catch (IOException ex) {
			System.out.println("Exce��o de Leitura/Escrita de arquivo!" + ex.getMessage());
		}
	}
}
