package Aula2;

import java.util.ArrayList;
import java.util.Collections;
//import java.util.List;

public class Exercicio3 {
	public static void main(String[] args) {
		//Usando a classe Pessoa da aula anterior fazeros itens abaixo
		//Adicionar 4 pessoas em uma lista, usar os construtores sem e com par�metros
		//Imprimir o primeiro e o �ltimo objetos
		//Ordenar a lista usando o nome
		//imprimir a lista ordenada
		
		ArrayList<Pessoa> listaPessoas = new ArrayList<Pessoa>();
		
		Pessoa p1 = new Pessoa("Cristiano",  "99999999", "Cristo Redentor");
		Pessoa p2 = new Pessoa("Vanessa", "88888888", "Humaita");
		Pessoa p3 = new Pessoa();
		Pessoa p4 = new Pessoa("Matheus", "77777777", "Vila Ipiranga");
		
		listaPessoas.add(p1);
		listaPessoas.add(p2);
		listaPessoas.add(p3);
		listaPessoas.add(p4);

		System.out.println("Primeira pessoa = " + listaPessoas.get(0) + "\n");
		System.out.println("�ltima pessoa = " + listaPessoas.get(listaPessoas.size()-1) + "\n");
		
		Collections.sort(listaPessoas);

		System.out.println("Lista Ordenada de Pessoas = ");
		for(Pessoa p : listaPessoas)
			System.out.println(p);
			
		
	}
}
