package Aula2;
import java.util.*;

public class Exercicio4_HashMap {
	public static void main(String[] args) {
		HashMap<String, Integer> map = new HashMap<>();
		map.put("um", new Integer(1));
		map.put("dois", new Integer(2));
		map.put("tres", new Integer(3));
		Iterator<Integer> it = map.values().iterator();
		while (it.hasNext()) {
			System.out.println((Integer) it.next());
		}
	}
}
