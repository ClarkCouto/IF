package Aula2;
import java.util.Comparator;

public class ComparatorCpf implements Comparator<Cpf> {
	public int compare(Cpf cpf1, Cpf cpf2) {
        return cpf1.compareTo(cpf2); 
	}
}
