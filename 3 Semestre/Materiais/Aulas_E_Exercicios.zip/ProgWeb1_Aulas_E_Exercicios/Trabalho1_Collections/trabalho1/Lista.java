package trabalho1;
//	14) Crie a interface gen�rica Lista como descrito abaixo:
//		- A lista ir� conter elementos
//		- Defina os m�todos abaixo usando gen�ricos onde for poss�vel:
//		public void adicionar(int indice, Object obj)
//		public boolean remover(Object obj)
//		public String listar()
//		public int totalizar()
//		public Object getFirst()
//		public Object getLast() 

public abstract interface Lista <E>{
	
	public void adicionar(int indice, E e);
	public boolean remover(E e);
	public String listar();
	public int totalizar();
	public E getFirst();
	public E getLast();
}
