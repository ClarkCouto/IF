package data_Hora;
import java.time.*;
import java.time.format.*;

public class ClasseDateTimeFormatter {
	public static void main(String[] args) {
		LocalDateTime dataHora = LocalDateTime.now();
		System.out.println(dataHora);
		System.out.println(dataHora.format(DateTimeFormatter.ofPattern("dd/MM/yyyy hh:MM:ss")));

		// for�ar que uma data seja validada
		DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		formato = formato.withResolverStyle(ResolverStyle.STRICT);
		//LocalDate data = LocalDate.of(2017, 2, 31);
		//System.out.println(dataHora.format(formato));

		System.out.println(dataHora.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL)));
		System.out.println(dataHora.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG)));
		System.out.println(dataHora.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM)));
		System.out.println(dataHora.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT)));
	}
}
