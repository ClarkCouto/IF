package data_Hora;
import java.time.*;

public class ClasseLocalDate {
	public static void main(String[] args) {
		//data atual
		LocalDate dataAtual = LocalDate.now();
		System.out.println("Data: " + dataAtual);

		//data e hora atual
		LocalDateTime dataHoraAtual = LocalDateTime.now();
		System.out.println("Data e Hora: " + dataHoraAtual);
		
		//criar um LocalDate para uma data espec�fica
		//Data = 10/03/2017
		LocalDate dataEspecifica = LocalDate.of(2017, 3, 10);
		System.out.println("Data: " + dataEspecifica);

		System.out.println("Data - dia do m�s: " + dataEspecifica.getDayOfMonth());
		

	}
}
