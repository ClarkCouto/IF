package data_Hora;
import java.time.*;

public class ClassePeriodoDuracao {
	public static void main(String[] args) {

		// Para calcular o n�mero de dias entre duas datas � necess�rio usar
		// a classe utilizar Period, que j� trata anos bissextos e outros
		// detalhes
		// sa�da 8 anos, 1 m�s e 13 dias
		// Month � uma enumera��o para mapear os meses do ano
		LocalDate homemNoEspaco = LocalDate.of(1961, Month.APRIL, 12);
		LocalDate homemNaLua = LocalDate.of(1969, Month.MAY, 25);
		Period periodo = Period.between(homemNoEspaco, homemNaLua);
		System.out.printf("%s anos, %s m�s e %s dias\n", periodo.getYears(), periodo.getMonths(), periodo.getDays());

		LocalDateTime inicio = LocalDateTime.of(2016, 10, 20, 0, 0, 0);
		LocalDateTime fim = LocalDateTime.of(2017, 2, 16, 0, 0, 0);
		Duration dur = Duration.between(inicio, fim);
		System.out.printf("\n%s dias %s horas, %s minutos e %s segundos", dur.toDays(), dur.toHours(), dur.toMinutes(),
				dur.getSeconds());
	}
}
