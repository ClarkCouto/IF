package classes;

import java.util.LinkedList;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;


@ManagedBean
@SessionScoped
public class AlunoBean {
    private Aluno aluno = new Aluno();
    private LinkedList<String> cursos ;
    private LinkedList<Aluno> alunos = new LinkedList();

    public Aluno getAluno() {
        return aluno;
    }

    public void setAluno(Aluno aluno) {
        this.aluno = aluno;
    }

    public LinkedList<String> getCursos() {
        if(cursos == null)
           return aluno.getCursos();
        return cursos; 
    }
    public LinkedList<Aluno> getAlunos() {
       if(alunos==null)
              this.alunos = new LinkedList<>();
        return alunos;
    
    }
    public String salvar(){
        alunos.add(new Aluno(aluno.getNome(), aluno.getAnoIngresso(), aluno.getMensalidade()));
        return "Listar";
    }
}

