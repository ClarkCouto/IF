
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class Data{
	private int dia;
	private int mes;
	private int ano;
	private LocalDate data;
	
	public Data(){}

	public Data(int dia, int mes, int ano) {
		this.dia = dia;
		this.mes = mes;
		this.ano = ano;
		//22.1 Classe Data: - deve usar a classe LocalTime. VoceÌ‚ deve inicializar o objeto usando os valores informados no cons- trutor
		setData(LocalDate.of(ano, mes, dia));
	}

	public int getDia() {
		return dia;
	}

	public void setDia(int dia) {
		this.dia = dia;
	}

	public int getMes() {
		return mes;
	}

	public void setMes(int mes) {
		this.mes = mes;
	}

	public int getAno() {
		return ano;
	}

	public void setAno(int ano) {
		this.ano = ano;
	}

	public LocalDate getData() {
		return data;
	}

	public void setData(LocalDate data) {
		this.data = data;
	}
	
	@Override
	public String toString() {
		//22.1 Classe Data: - o meÌ�todo toString() deve retornar a data no formato: dd/mm/ano â€“ quarta-feira (agosto)
		return data.format(DateTimeFormatter.ofPattern("dd/MM/yyyy - EEEE (MMMM)",  new Locale("pt", "BR")));
	};
	
	
	
	
}
