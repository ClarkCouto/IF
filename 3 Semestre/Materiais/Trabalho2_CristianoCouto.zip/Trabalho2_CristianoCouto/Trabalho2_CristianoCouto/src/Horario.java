
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class Horario {
	private int hora;
	private int minutos;
	private int segundos;
	private LocalTime horario;
	
	public Horario(){};
	
	public Horario(int hora, int minutos, int segundos) {
		super();
		this.hora = hora;
		this.minutos = minutos;
		this.segundos = segundos;
		//22.2 Classe Hora�?rio - deve usar a classe LocalTime. Você deve inicializar o objeto usando os valores informados no construtor
		setHorario(LocalTime.of(hora, minutos, segundos));
	}

	public int getHora() {
		return hora;
	}

	public void setHora(int hora) {
		this.hora = hora;
	}

	public int getMinutos() {
		return minutos;
	}

	public void setMinutos(int minutos) {
		this.minutos = minutos;
	}

	public int getSegundos() {
		return segundos;
	}

	public void setSegundos(int segundos) {
		this.segundos = segundos;
	}

	public LocalTime getHorario() {
		return horario;
	}

	public void setHorario(LocalTime horario) {
		this.horario = horario;
	}

	@Override
	public String toString() {
		//22.2 Classe Hora�?rio - o me�?todo toString() deve retornar o hora�?rio no formato: hh/mm/ss
		return "Hora: " + horario.format(DateTimeFormatter.ofPattern("hh:mm:ss"));
	}
	
	
	
}
