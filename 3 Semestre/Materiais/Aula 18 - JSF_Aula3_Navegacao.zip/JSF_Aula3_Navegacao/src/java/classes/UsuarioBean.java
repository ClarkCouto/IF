package classes;
import java.io.Serializable;
import java.util.*;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean
@SessionScoped
public class UsuarioBean implements Serializable{
    private static final long serialVersionUID = 356240640918386194L;
    private Usuario usuario = new Usuario();
     private Usuario usuarioLogado = new Usuario();
    private List<Usuario> lista ;
    private boolean editando;

    public Usuario getUsuario() {
        return usuario;
    }
    public void setPessoa(Usuario usuario) {
        this.usuario = usuario;
    }

    public boolean isEditando() {
        return editando;
    }

    public void setEditando(boolean editando) {
        this.editando = editando;
    }
    

    public Usuario getUsuarioLogado() {
        return usuarioLogado;
    }

    public void setUsuarioLogado(Usuario usuarioLogado) {
        this.usuarioLogado = usuarioLogado;
    }

    @PostConstruct
    public void carregaLista() {
        lista = usuario.listar();
    }
    public List<Usuario> getLista() {
        if(lista == null)
           return usuario.listar();
        return lista;
    }
   
    public String atualizar(Usuario user){
        System.out.println("Entrou no atualizar!!");
        //usuario.atualizar();
        usuario.listar();
        return "listar";
    }
    public String cadastrar() {
        System.out.println("Entrou no cadastrar!!");
        System.out.println("LISTA = " + lista);
        if(!isEditando())
            lista.add(new Usuario(usuario.getNome(), usuario.getIdentificador(), usuario.getSenha()));
        this.usuario = new Usuario();
        setEditando(false);
        return "listar";
    }
    
    public String validar() {
        if(usuario.validar()){
           this.usuarioLogado = usuario;    
           usuario = new Usuario();
           return "menu";
        }
        return "invalido";
    }
    public void limpar() {
       this.usuario = new Usuario();
       setEditando(false);
    }
    
    public String excluir(Usuario user){
        System.out.println("Entrou no excluir!!");
        lista.remove(user);
        //lista = usuario.listar();
        setEditando(false);
        return "listar";
    }
     public String editar(Usuario user){
        this.usuario = user;
        setEditando(true);
        return "editar";
    }
}
