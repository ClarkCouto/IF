/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import banco.AlunoDAO;
import java.util.List;

/**
 *
 * @author 0729159
 */
public class Aluno {
    private int id;
    private String nome;
    private int matricula;
    private String endereco;

    public Aluno() {}

    public Aluno(String nome, int matricula, String endereco) {
        this(-1 , nome, matricula, endereco);
    }

    public Aluno(int id, String nome, int matricula, String endereco) {
        this.id = id;
        this.nome = nome;
        this.matricula = matricula;
        this.endereco = endereco;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    @Override
    public String toString() {
        return "Aluno " + id + "\n\nNome: " + nome + "\nMatrícula: " + matricula + "\nEndereço: " + endereco;
    }
    
    public List<Aluno> listAll(){
        return new AlunoDAO().listAll();
    }
}
