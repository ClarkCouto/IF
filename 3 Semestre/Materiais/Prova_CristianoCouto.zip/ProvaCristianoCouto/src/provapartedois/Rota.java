/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package provapartedois;

import java.util.List;
import provapartedois.DAO.RotaDAO;

/**
 *
 * @author CristianoCouto
 */
public class Rota {
    public String nome;
    public String descricao;
    public int idRota;

    public Rota() {
    }

    public Rota(String nome, String descricao) {
        this(-1, nome, descricao);
    }

    public Rota(int idRota, String nome, String descricao) {
        this.idRota = idRota;
        this.nome = nome;
        this.descricao = descricao;
    }

    public String getNome() {
        return nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public int getIdRota() {
        return idRota;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public void setIdRota(int idRota) {
        this.idRota = idRota;
    }

    @Override
    public String toString() {
        return nome + "\tDescrição: " + descricao;
    }
    
    public int insert() {
        return new RotaDAO().insert(this);
    }
    public List<Rota> listAll(){
        return new RotaDAO().listAll();
    }
    public int delete() {
        return new RotaDAO().delete(this);
    }
    public int update() {
        return new RotaDAO().update(this);
    }
    public Rota findById(int idRota) {
        return new RotaDAO().findByID(idRota);
    }
}
