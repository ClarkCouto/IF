/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package provapartedois.testes;

import java.util.NoSuchElementException;
import provapartedois.Data;
import provapartedois.MinhaFila;

/**
 *
 * @author 0729159
 */
public class TestesFilaGenerica {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Cria a fila
        MinhaFila<Data> fila = new MinhaFila<>();
        
        //Imprime a fila atual
        System.out.println("Fila Atual:\n" + fila.toString());
        
        //Adiciona as datas
        System.out.println("Adiciona datas..");
        fila.adicionar(new Data(1, 5, 2017));
        fila.adicionar(new Data(31, 12, 1999));
        fila.adicionar(new Data(12, 9, 1970));
        fila.adicionar(new Data(27, 9, 1989));
        fila.adicionar(new Data(9, 5, 2025));
        
        //Imprime a fila atual
        System.out.println("Fila Atual:\n" + fila.toString());
        
        //Retorno do método GetPrimeiro
        try{
            System.out.println("\n==================================================================="); 
            System.out.println("Primeiro Elemento:\n" + fila.getPrimeiro());
        }
        catch(NoSuchElementException e){
            System.out.println("Exceção elemento não encontrado ao tentar buscar o primeiro elemento!");
        }
        catch(NullPointerException e){
            System.out.println("Buscou uma posição nula ao tentar buscar o primeiro elemento!");
        }
        catch(Exception e){
            System.out.println("Ocorreu uma exceção ao tentar buscar o primeiro elemento!");
        }
        //Retorno do método GetUltimo
        try{
            System.out.println("\n==================================================================="); 
            System.out.println("Primeiro Elemento:\n" + fila.getUltimo());
        }
        catch(NoSuchElementException e){
            System.out.println("Exceção elemento não encontrado ao tentar buscar o último elemento!");
        }
        catch(NullPointerException e){
            System.out.println("Buscou uma posição nula ao tentar buscar o último elemento!");
        }
        catch(Exception e){
            System.out.println("Ocorreu uma exceção ao tentar buscar o último elemento!");
        }
        
        //Método Contém
        try{
            System.out.println("\n==================================================================="); 
            System.out.println("Pesquisando uma data utilizando o new Date.."); 
            System.out.println("\tA lista " + (fila.contem(new Data(9, 5, 2025)) ? "" : "não ") + "contém esta data");
            
            System.out.println("==================================================================="); 
            System.out.println("\nCriando uma nova data utilizando o new Date.."); 
            Data d = new Data(1, 1, 2000);
            System.out.println("Adicionando este objeto data à fila.."); 
            fila.adicionar(d);
            System.out.println("Pesquisando se o objeto criado está dentro da fila.."); 
            System.out.println("\tA lista " + (fila.contem(d) ? "" : "não ") + "contém esta data");
            System.out.println("Desta forma é possível verificar que o método contém só funciona se for utilizado o mesmo obejto na inclusão e na consulta. Não basta ter os mesmo dados\n\n\n"); 
        }
        catch(NoSuchElementException e){
            System.out.println("Exceção elemento não encontrado ao tentar verificar a fila!");
        }
        catch(NullPointerException e){
            System.out.println("Buscou uma posição nula ao tentar verificar a fila!");
        }
        catch(Exception e){
            System.out.println("Ocorreu uma exceção ao tentar verificar a fila!");
        }
        
        //Método Remover
        try{
            System.out.println("==================================================================="); 
            System.out.println("\tTentando remover elemento..");
            fila.remover();
        }
        catch(NoSuchElementException e){
            System.out.println("Exceção elemento não encontrado ao tentar remover o último elemento!");
        }
        catch(NullPointerException e){
            System.out.println("Buscou uma posição nula ao tentar buscar o último elemento!");
        }
        catch(Exception e){
            System.out.println("Ocorreu uma exceção ao tentar buscar o último elemento!");
        }
        
        
    }
    
}
