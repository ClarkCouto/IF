/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package provapartedois;

import java.util.List;
import provapartedois.DAO.DataDAO;

/**
 *
 * @author CristianoCouto
 */
public class Data implements Comparable<Data>{
    private int dia;
    private int mes;
    private int ano;
    private int idData;

    public Data() {
    }
    public Data(int dia, int mes, int ano) {
        this(-1, dia, mes, ano);
    }

    public Data(int idData, int dia, int mes, int ano) {
        this.idData = idData;
        this.dia = dia;
        this.mes = mes;
        this.ano = ano;
    }

    public int getIdData() {
        return idData;
    }

    public int getDia() {
        return dia;
    }

    public int getMes() {
        return mes;
    }

    public int getAno() {
        return ano;
    }

    public void setIdData(int idData) {
        this.idData = idData;
    }

    public void setDia(int dia) {
        this.dia = dia;
    }

    public void setMes(int mes) {
        this.mes = mes;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    @Override
    public String toString() {
        return (dia > 0 && mes > 0 && ano > 0 ? (dia + "/" + mes + "/" + ano) : "Data Inválida");
    }
    
    public int insert() {
        return new DataDAO().insert(this);
    }
    public List<Data> listAll(){
        return new DataDAO().listAll();
    }
    public int delete() {
        return new DataDAO().delete(this);
    }
    public int update() {
        return new DataDAO().update(this);
    }
    public Data findById(int idData) {
        return new DataDAO().findByID(idData);
    }

    @Override
    public int compareTo(Data o) {
        //Se o ano da data atual for menor
        if(this.getAno() < o.getAno())
            return -1;
        //Se o ano da data atual for maior
        if(this.getAno() > o.getAno())
            return 1;
        //Se o ano da data atual for igual e o mês menor
        if(this.getMes() < o.getMes())
            return -1;
        //Se o ano da data atual for igual e o mês maior
        if(this.getMes() > o.getMes())
            return 1;
        //Se o ano e o mês da data atual fores iguais e o dia menor
        if(this.getDia() < o.getDia())
            return -1;
        //Se o ano e o mês da data atual fores iguais e o dia maior
        if(this.getDia() > o.getDia())
            return 1;
        //Se o ano, o mês e o dia forem iguai a data é igual
        return 0;
    }
    
    
}
