/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package provapartedois.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;
import javax.swing.JOptionPane;
import provapartedois.Voo;

/**
 *
 * @author CristianoCouto
 */
public class VooDAO implements GenericDAO<Voo>{

    @Override
    public int insert(Voo voo) {
        int chavePrimaria = -1;
        int idRota = new RotaDAO().insert(voo.getRota());
        int idData = new DataDAO().insert(voo.getData());
        
        try (Connection connection = new ConnectionFactory().getConnection();
                PreparedStatement stmt = connection.prepareStatement(VooSQLs.INSERT.getSql(),
                        Statement.RETURN_GENERATED_KEYS)) {
//            System.out.println("Conexão Insert Voo aberta!");
//            System.out.println("Voo a ser incluido: " + voo.toString());
//            System.out.println("idRota: " + idRota);
//            System.out.println("idData: " + idData);
            stmt.setLong(1, voo.getNumero());
            stmt.setString(2, voo.getCiaAerea());
            stmt.setString(3, voo.getHorarioSaida());
            stmt.setString(4, voo.getHorarioChegada());
            stmt.setInt(5, idRota);
            stmt.setInt(6, idData);
            stmt.execute();
            
            System.out.println("Dados do Voo gravados com Sucesso!");
            ResultSet chaves = stmt.getGeneratedKeys();
            if (chaves.next()) {
                chavePrimaria = chaves.getInt(1);
            }
        } 
        catch (SQLException e) {
            System.out.println("Exceção com recursos em Insert Voo! " + e.getMessage());
            System.out.println("Exceção com recursos em Insert Voo! " + e.getSQLState());
        } 
        catch (ClassNotFoundException e) {
            System.out.println("Classe não encontrada Insert Voo!");
        }
        return chavePrimaria;
    }

@Override
    public List<Voo> listAll() {
        List<Voo> lista = new LinkedList<>();

        try (Connection connection = new ConnectionFactory().getConnection();
            PreparedStatement stmt = connection.prepareStatement(VooSQLs.LISTALL.getSql())) {

            //JOptionPane.showMessageDialog(null,"connected with "+connection.toString());
            System.out.println("Conexão listAll Voo aberta!");
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int idVoo = rs.getInt("idVoo");
                String ciaArea = rs.getString("ciaAerea");
                String horarioSaida = rs.getString("horarioSaida");
                String horarioChegada = rs.getString("horarioChegada");
                int idRota = rs.getInt("horarioChegada");
                int idData = rs.getInt("horarioChegada");
                lista.add(new Voo(idVoo, ciaArea, horarioSaida, horarioChegada, new RotaDAO().findByID(idRota), new DataDAO().findByID(idData)));
            }
            return lista;
        } 
        catch (SQLException e) {
            System.out.println("Exceção SQL em listAll Voo! " + e.getSQLState());
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada listAll Voo!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código em listAll Voo!");
        }
        return null;
    }

    @Override
    public int delete(Voo voo) {
        try (Connection connection = new ConnectionFactory().getConnection();
                PreparedStatement stmt = connection.prepareStatement(VooSQLs.DELETE.getSql())) {
            System.out.println("Conexão Delete Voo aberta!");
            stmt.setInt(1, voo.getIdVoo());
            return stmt.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println("Exceção SQL em Delete Voo! " + e.getSQLState());
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada em Delete Voo!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código em Delete Voo!");
        }
        return 0;
    }

    @Override
    public int update(Voo voo) {
        try (Connection connection = new ConnectionFactory().getConnection();
                PreparedStatement stmt = connection.prepareStatement(VooSQLs.UPDATE.getSql())) {
            System.out.println("\nConexão Update Voo aberta!"); 
            stmt.setLong(1, voo.getNumero());
            stmt.setString(2, voo.getCiaAerea());
            stmt.setString(3, voo.getHorarioSaida());
            stmt.setString(4, voo.getHorarioChegada());
            stmt.setInt(5, voo.getRota().getIdRota());
            stmt.setInt(6, voo.getData().getIdData());
            stmt.setInt(7, voo.getIdVoo());
            return stmt.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println("Exceção SQL em Update Voo! " + e.getMessage());
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada em Update Voo!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código em Update Voo!");
        }
        return 0;
    }

    @Override
    public Voo findByID(int id) {
        try (Connection connection = new ConnectionFactory().getConnection();
            PreparedStatement stmt = connection.prepareStatement(VooSQLs.FINDBYID.getSql())) {

            System.out.println("Conexão FindById Voo aberta!");
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int idVoo = rs.getInt("idVoo");
                String ciaArea = rs.getString("ciaAerea");
                String horarioSaida = rs.getString("horarioSaida");
                String horarioChegada = rs.getString("horarioChegada");
                int idRota = rs.getInt("idRota");
                int idData = rs.getInt("idData");
                return new Voo(idVoo, ciaArea, horarioSaida, horarioChegada, new RotaDAO().findByID(idRota), new DataDAO().findByID(idData));
            }
        } 
        catch (SQLException e) {
            System.out.println("Exceção SQL em FindById Voo! " + e.getSQLState());
        }
        catch (ClassNotFoundException e) {
            System.out.println("Classe/Tabela não encontrada em FindById Voo!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código em FindById Voo!");
        }
        return null;
    }
}

