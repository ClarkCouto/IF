/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package provapartedois.DAO;

/**
 *
 * @author CristianoCouto
 */
public enum VooSQLs {
    INSERT("insert into voo(numero, ciaAerea, horarioSaida, horarioChegada, idRota, idData) values (?, ?, ?, ?, ?, ?)"), 
    UPDATE("update voo set numero = ?, ciaAerea = ?, horarioSaida = ?, horarioChegada = ?, idRota = ?, idData = ? where idVoo = ?"), 
    FINDBYID("select * from voo where idVoo = ?"), 
    DELETE("delete from voo where idVoo = ?"), 
    LISTALL("select * from voo");
    
    private final String sql;
    VooSQLs(String sql){
        this.sql = sql; 
    }

    public String getSql() {
        return sql;
    }    
}
