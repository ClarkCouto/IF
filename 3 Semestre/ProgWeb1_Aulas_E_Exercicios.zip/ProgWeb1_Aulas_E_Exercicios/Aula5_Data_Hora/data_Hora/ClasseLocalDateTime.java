package data_Hora;
import java.time.LocalDateTime;

public class ClasseLocalDateTime {
	public static void main(String[] args) {
		LocalDateTime dataHoraAtual = LocalDateTime.now();
		System.out.println("Data e Hora: " + dataHoraAtual);
		System.out.println("Data - dia do ano: " + dataHoraAtual.getDayOfYear());
	}
}
