package exercicio4_5_6_Mapa_Interface_Genericos;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class MeuMapa<K, V> implements Mapa{
	private K key;
	private V value;
	LinkedList<MeuMapa> mapas = new LinkedList<MeuMapa>();
	
	public MeuMapa(){}
	public MeuMapa(K k, V v){
		
	}
	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Set keySet() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void put(K k, V v) {
		mapas.add(new MeuMapa());
		// TODO Auto-generated method stub
		
	}

	@Override
	public void remove(V v) {
		// TODO Auto-generated method stub
		
	}

}
