package Aula2;
import java.util.ArrayList;
import java.util.Collections;

public class Exercicio2 {
	public static void main(String[] args) {
		//Usando a classe String adicionar 5 palavras na lista
		//ordenar a lista
		//imprimir a lista
		ArrayList<String> lista = new ArrayList<String>();
		
		lista.add("Cristiano");
		lista.add("Thayse");
		lista.add("Matheus");

		System.out.println("Lista N�o Ordenada: ");
		for(String nome : lista)
			System.out.println(nome);
		
		Collections.sort(lista);

		System.out.println("\nLista Ordenada: ");
		for(String nome : lista)
			System.out.println(nome);
			
		
	}
}
