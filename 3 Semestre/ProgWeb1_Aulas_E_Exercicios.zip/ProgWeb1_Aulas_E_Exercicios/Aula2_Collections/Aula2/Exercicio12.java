package Aula2;

public class Exercicio12 {
	public static void main(String[] args) {
      //Use a classe Par definida anteriormente para armazenar:
	  //O nome e a nota de um aluno (<String, Double>)
		
	  //Use a classe Par definida anteriormente para armazenar:
      //As coordenadas x e y (<Float, Float>) 

	}
}
