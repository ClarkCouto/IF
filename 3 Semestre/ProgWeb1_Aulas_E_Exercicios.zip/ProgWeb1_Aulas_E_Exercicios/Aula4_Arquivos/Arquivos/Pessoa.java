package Arquivos;
import java.io.Serializable;

public class Pessoa implements Serializable{
	private String nome;
	private int idade;
	
	public Pessoa() {
	}
	public Pessoa(String nome, int idade) {
		super();
		this.nome = nome;
		this.idade = idade;
	}
	
	public String toString(){
		return "Nome: " + nome + " Idade: " + idade;
	}
}
