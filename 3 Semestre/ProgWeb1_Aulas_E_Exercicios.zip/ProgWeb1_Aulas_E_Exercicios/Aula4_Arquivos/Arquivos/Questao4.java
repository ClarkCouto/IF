package Arquivos;
public class Questao4{
	public static void main(String[] args) {
		File arquivo = new File("Ex4.bin");
		//gravando fluxo baseados em bytes
		OutputStream saida = new FileOutputStream(arquivo);
		byte[] b = {50,51,52,53};
		String string = "Teste com v�rias palavras";
		saida.write( 53 );
		saida.write( b );
		saida.write( string.getBytes() );
		saida.flush();
		saida.close();

		//lendo fluxo baseados em bytes
		InputStream entrada = new FileInputStream(arquivo);
		int content;
		while ( (content = entrada.read() ) != -1) {
		    System.out.println( content +" - "+ ( (char) content) );
		}
		entrada.close();
	}
}
