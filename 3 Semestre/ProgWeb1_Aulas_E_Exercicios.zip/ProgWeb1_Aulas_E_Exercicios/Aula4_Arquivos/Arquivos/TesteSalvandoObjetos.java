package Arquivos;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.NotSerializableException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.StreamCorruptedException;

public class TesteSalvandoObjetos {

	public static void main(String[] args) {
		String nomeArq = "TesteSalvandoObjetos.txt";
		
		try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(nomeArq))){
			Pessoa obj = new Pessoa("Cristiano", 27);
			out.writeObject(obj);
		}  
		catch (NotSerializableException ex) {
			System.out.println("Objeto n�o pode ser serializado! " + ex.getMessage());
		}
		catch (FileNotFoundException | NullPointerException ex) {
			System.out.println("Arquivo de escrita nulo ou n�o encontrado! " + ex.getMessage());
		}
		catch (SecurityException ex) {
			System.out.println("Exce��o de seguran�a! " + ex.getMessage());
		}
		catch (IOException ex) {
			System.out.println("Exce��o de I/O na escrita! " + ex.getMessage());
		}
		catch (Exception ex) {
			System.out.println("Ocorreu uma exce��o n�o tratada! " + ex.getMessage());
		}
		
		try(ObjectInputStream in = new ObjectInputStream(new FileInputStream(nomeArq))){
			Pessoa obj = (Pessoa) in.readObject();
			System.out.println(obj);
		}
		catch (StreamCorruptedException ex) {
			System.out.println("Arquivo de leitura nulo ou n�o encontrado! " + ex.getMessage());
		}
		catch (FileNotFoundException | NullPointerException ex) {
			System.out.println("Arquivo de leitura nulo ou n�o encontrado! " + ex.getMessage());
		}
		catch (SecurityException ex) {
			System.out.println("Exce��o de seguran�a! " + ex.getMessage());
		}
		catch (IOException ex) {
			System.out.println("Exce��o de I/O na leitura! " + ex.getMessage());
		}
		catch (ClassNotFoundException ex) {
			System.out.println("Classe do objeto n�o encontrada! " + ex.getMessage());
		}
		catch (Exception ex) {
			System.out.println("Ocorreu uma exce��o n�o tratada! " + ex.getMessage());
		}
	}

}
