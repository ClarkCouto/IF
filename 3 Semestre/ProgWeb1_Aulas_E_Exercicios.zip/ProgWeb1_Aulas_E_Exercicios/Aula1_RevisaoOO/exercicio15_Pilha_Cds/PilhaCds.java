package exercicio15_Pilha_Cds;


import java.util.LinkedList;

public class PilhaCds {
//	Crie uma classe com o nome PilhaCDs que deve armazenar os CDs que você tem. 
//	Você deve inserir 7 CDs na pilha, remover dois CDs, depois, imprimir todos os objetos inseridos.
//	(obs.: para resolver esse exercício use a classe LinkedList; a classe CD acima e implementar toda 
//	a solução usando os conceitos de pilha).
	
	public static void main(String[] args) {
		LinkedList<CD> pilha = new LinkedList<CD>();
		System.out.println("Preenchendo Lista...");
		pilha.add(new CD("Halo", 2014, "Beyonce"));
		pilha.add(new CD("19", 2009, "Adele"));
		pilha.add(new CD("21", 2011, "Adele"));
		pilha.add(new CD("25", 2016, "Adele"));
		pilha.add(new CD("Fireworks", 2009, "Katy Perry"));
		pilha.add(new CD("Try", 2012, "Pink"));
		pilha.add(new CD("Beyonce", 2016, "Beyonce"));
		System.out.println("\nLista Preenchida: (" + pilha.size() + " itens)");
		for(CD cd: pilha)
			System.out.println(cd.toString());
		System.out.println("\nRemovendo Itens...");
		pilha.removeLast();
		pilha.removeLast();
		System.out.println("\nLista Final... (" + pilha.size() + " itens)");
		for(CD cd: pilha)
			System.out.println(cd.toString());
	}

}
