package exercicio16_Fila_Carros;


public class Carro {
	String placa;
	int ano;
	String modelo;
	
	public Carro(){};
	public Carro(String placa, int ano, String modelo) {
		this.placa = placa;
		this.ano = ano;
		this.modelo = modelo;
	}
	public String getPlaca() {
		return placa;
	}
	public void setPlaca(String placa) {
		this.placa = placa;
	}
	public int getAno() {
		return ano;
	}
	public void setAno(int ano) {
		this.ano = ano;
	}
	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	@Override
	public String toString() {
		return "Carro Placa: " + placa + " Ano: " + ano + " Modelo: " + modelo;
	}
	
}
