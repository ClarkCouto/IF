/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifrs.poa.pessoas;

import br.edu.ifrs.poa.docs.Cpf;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author 0729159
 */
public class Menu {

    /**
     * @param args the command line arguments
     */
    
    private List<Pessoa> pessoas;

    public Menu(List<Pessoa> pessoas) {
        this.pessoas = pessoas;
    }
    
    private static int mostrarMenu(){
        String menu = ("========= MENU =========\n" + 
                        "1 - Cadastrar Aluno\n" +
                        "2 - Pesquisar Aluno pelo Nome\n" +
                        "3 - Pesquisar Aluno pelo CPF\n"  +
                        "4 - Lista todos os alunos\n"  +
                        "5 - Sair\n" 
                      );
        
        return Integer.parseInt(JOptionPane.showInputDialog(menu)); 
    }
    
    public void imprime(String str){
        System.out.print(str + "\n");
    }
    
    private static void buscarAlunoPeloNome(Pessoa v){
        
    }
    
    public static void main(String[] args) {
        //Como declarar o vetor que vai armazenar os objetos?
        Pessoa alunos[] = new Pessoa[2];
        try{
            //Como mostrar o menu repetirdamente?
            while(true){
                switch(mostrarMenu()){
                    case 1:
                        alunos[0] = new Aluno("Cris", "985436313", "Adão Baino, 701/409", 729159, "Sistemas para Internet", 1, new Cpf(15988250, 89));
                        alunos[1] = new Aluno("Matheus Beeshona", "987654321", "Gaston Englert, 385", 123456, "Sistemas para Internet", 1);

                        /*
                        for(int i = 0; i < alunos.length; i++){
                            String nome = JOptionPane.showInputDialog("Digite o nome: ");
                            String endereco = JOptionPane.showInputDialog("Digite o endereço: ");
                            String telefone = JOptionPane.showInputDialog("Digite o telefone: ");
                            String curso = JOptionPane.showInputDialog("Digite o curso: ");
                            int situacao = Integer.parseInt(JOptionPane.showInputDialog("Digite a situação: "));
                            long matricula = Long.parseLong(JOptionPane.showInputDialog("Digite a matrícula: "));
                            long numero = Long.parseLong(JOptionPane.showInputDialog("Digite o número do CPF: "));
                            int digito = Integer.parseInt(JOptionPane.showInputDialog("Digite o dígito do CPF: "));
                            alunos[i] = new Aluno(nome, telefone, endereco, matricula, curso, situacao, new Cpf(numero, digito));
                        }
                        */
                        break;
                    case 2:
                        String nome = JOptionPane.showInputDialog("Digite o nome a ser encontrado: ");
                        boolean encontrou = false;
                        for(int i = 0; i < alunos.length; i++){
                            if(alunos[i] != null && alunos[i].getNome().equals(nome)){
                                encontrou = true;
                                System.out.println("\n============== Busca por Nome ==============");
                                System.out.println("============== Aluno " + (i + 1) + " ==============");
                                alunos[i].imprime();
                                //JOptionPane.showMessageDialog(null, alunos[i].toString());
                            }
                        }
                        if(!encontrou){
                            JOptionPane.showMessageDialog(null, "O aluno " + nome + " não foi encontrado!");
                        }
                        break;
                    case 3:
                        long numero = Long.parseLong(JOptionPane.showInputDialog("Digite o número do CPF a ser encontrado: "));
                        int digito = Integer.parseInt(JOptionPane.showInputDialog("Digite o dígito do CPF a ser encontrado: "));

                        encontrou = false;
                        for(int i = 0; i < alunos.length; i++){
                            if(alunos[i] != null && ((Aluno)alunos[i]).getCpf().getNumero() == numero &&
                                                    ((Aluno)alunos[i]).getCpf().getDigito() == digito){
                                encontrou = true;
                                System.out.println("\n============== Busca por CPF ==============");
                                System.out.println("============== Aluno " + (i + 1) + " ==============");
                                alunos[i].imprime();
                                //JOptionPane.showMessageDialog(null, "" + alunos[i].toString());
                            }
                        }
                        if(!encontrou){
                            JOptionPane.showMessageDialog(null, "O cpf " + numero + "-" + digito + " não foi encontrado!");
                        }

                        break;
                    case 4:  
                        System.out.println("\n============== Buscar todos Alunos ==============");
                        for(int i = 0; i < alunos.length; i++){
                            System.out.println("============== Aluno " + (i + 1) + " ==============");
                            alunos[i].imprime();
                        }
                        break;
                    case 5:
                        JOptionPane.showMessageDialog(null, "Encerrando Sistema!");
                        System.exit(0);
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Opção inválida!");
                        break;
                }
            }
                
        }
        catch(Exception e){
            throw e;
        }
        /*
        Aluno a1 = new Aluno("Cris", "985436313", "Adão Baino, 701/409", 729159, "Sistemas para Internet", 1);
        Aluno a2 = new Aluno("Matheus Beeshona", "987654321", "Gaston Englert, 385", 123456, "Sistemas para Internet", 1);
        a1.setCpf(new Cpf(15988250,89));
        System.out.println("============== Aluno 1 ==============");
        a1.imprime();
        System.out.println("============== Aluno 2 ==============");
        a2.imprime();
        */
    }
    
}
