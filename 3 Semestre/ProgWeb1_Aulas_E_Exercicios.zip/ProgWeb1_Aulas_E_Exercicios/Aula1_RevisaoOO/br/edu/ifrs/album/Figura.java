package br.edu.ifrs.album;

public class Figura {

}
