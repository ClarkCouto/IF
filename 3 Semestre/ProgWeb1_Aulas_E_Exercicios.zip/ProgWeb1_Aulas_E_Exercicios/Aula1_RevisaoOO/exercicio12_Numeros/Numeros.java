package exercicio12_Numeros;


import java.util.ArrayList;

import javax.swing.JOptionPane;

public class Numeros {
	//12.1 Adiciona os números na lista, exibindo uma mensagem se conseguiu adicionar ou não na lista o número;
	//12.2 Remove o primeiro item da lista;
	//12.3 Imprime o número de elementos da lista;
	//12.4 Adiciona um número lido na posição 1;
	//12.5 Verifica se um número lido está dentro da coleção e mostra uma mensagem;
	//12.6 Remover todos os objetos da coleção e imprimir uma mensagem que informa se a lista está ou não vazia;

	public static void main(String[] args) {
		ArrayList<Integer> lista = new ArrayList<Integer>();
		int opcao = 9;
		while(opcao != 0){
			executar(menu(), lista);
		}
		
	}
	
	public static int menu(){
		try{
			return Integer.parseInt(JOptionPane.showInputDialog(
					"============ Menu ============\n" + 
					"1 - Adicionar na lista\n" + 
					"2 - Remover primeiro número\n" + 
					"3 - Imprimir tamanho da lista\n" + 
					"4 - Adiciona número 1a posição\n" + 
					"5 - Buscar número\n" + 
					"6 - Esvaziar lista\n" +
					"0 - Sair\n\n" +
					"Digite a opção desejada:"));
		}
		catch(Exception e){
			return 777;
		}
	}
	
	public static void executar(int opcao, ArrayList<Integer> l){
		ArrayList<Integer> lista = l;
		switch(opcao){
			case 0:
				//JOptionPane.showMessageDialog(null, "Sistema Encerrado!");
				System.exit(0);
				break;
			case 1:
				try{
					lista.add(Integer.parseInt(JOptionPane.showInputDialog("Digite o número: ")));
					JOptionPane.showMessageDialog(null, "Número Inserido!");
				}
				catch(Exception e){
					JOptionPane.showMessageDialog(null, "Não foi possível inserir o número!");
				}
				break;
			case 2:
				try{
					if(!lista.isEmpty()){
						lista.remove(0);
						JOptionPane.showMessageDialog(null, "O primeiro elemento da lista foi excluído!");
					}
					else
						JOptionPane.showMessageDialog(null, "A lista já está vazia!");	
				}
				catch(Exception e){
					JOptionPane.showMessageDialog(null, "Ocorreu um erro!");
				}
				break;
//				try{
//					num = Integer.parseInt(JOptionPane.showInputDialog("Digite o número a ser excluído: "));
//					boolean encontrou = false;
//					for(Integer n : lista){
//						if(num == lista.get(n)){
//							lista.remove(n);
//							encontrou = true;
//						}
//					}
//					String mensagem = encontrou ? "O número " + num + " foi excluído da lista" : "O número " + num + " não foi encontrado na lista"; 
//					JOptionPane.showMessageDialog(null, mensagem);
//				}
//				catch(Exception e){
//					JOptionPane.showMessageDialog(null, "O  número " + num + " não foi encontrado!");
//				}
//				break;
			case 3:
				JOptionPane.showMessageDialog(null, "A lista contém " + lista.size() + " elementos!");
				break;
			case 4:
				try{
					lista.add(0, Integer.parseInt(JOptionPane.showInputDialog("Digite o número a ser inserido: ")));
					JOptionPane.showMessageDialog(null, "Número inserido na 1a posição!");
				}
				catch(Exception e){
					JOptionPane.showMessageDialog(null, "Não foi possível inserir o número!");
				}
				break;
			case 5:
				if(!lista.isEmpty()){
					try {
						int num = Integer.parseInt(JOptionPane.showInputDialog("Digite o número a ser encontrado: "));
						boolean encontrou = false;
						for (Integer n : lista) {
							if (num == lista.get(n))
								encontrou = true;
						}
						String encontrado = encontrou ? "" : " NÃO";
						JOptionPane.showMessageDialog(null, "O número " + num + encontrado + " foi encontrado na lista");
					} 
					catch (Exception e) {
						JOptionPane.showMessageDialog(null, "Caractere inválido!");
					}
				}
				else
					JOptionPane.showMessageDialog(null, "A lista está vazia!");	
				break;
			case 6:
				if(!lista.isEmpty()){
					try{
						lista.removeAll(lista);
						JOptionPane.showMessageDialog(null, "Tamanho atual da lista: " + lista.size());
					}
					catch(Exception e){
						JOptionPane.showMessageDialog(null, "Ocorreu um erro! A lista ainda contém " + lista.size() + " elementos");
					}
				}
				else
					JOptionPane.showMessageDialog(null, "A lista já está vazia!");	
				break;
			default:
				JOptionPane.showMessageDialog(null, "Opção inválida!");
				break;
		}
	}
	

}
