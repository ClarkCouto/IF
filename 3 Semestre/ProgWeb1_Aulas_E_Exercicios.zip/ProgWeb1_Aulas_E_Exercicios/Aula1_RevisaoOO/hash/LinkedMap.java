/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hash;

import java.util.Set;
import java.util.LinkedHashMap;

/**
 *
 * @author 0729159
 */
public class LinkedMap {
    public static void main(String[] args) {
        LinkedHashMap<Integer, String> map = new LinkedHashMap<>();
        map.put(1, "um");
        map.put(2, "dois");
        map.put(3, "três");

        Set<Integer> chaves = map.keySet();
        for(Integer chave : chaves)
            System.out.println(chave);
    }
}
