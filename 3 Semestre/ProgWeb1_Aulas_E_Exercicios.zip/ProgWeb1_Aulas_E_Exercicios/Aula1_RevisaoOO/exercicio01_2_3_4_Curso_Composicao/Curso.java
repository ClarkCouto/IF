package exercicio01_2_3_4_Curso_Composicao;
import exercicio05_6_7.Data;

public class Curso {
	private String nome;
	private double duracao;
	private Data data;
	
	public Curso() {
	}

	public Curso(String nome, double duracao, Data data) {
		this.nome = nome;
		this.duracao = duracao;
		this.data = data;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public double getDuracao() {
		return duracao;
	}

	public void setDuracao(double duracao) {
		this.duracao = duracao;
	}

	public Data getData() {
		return data;
	}

	public void setData(Data data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "Curso: " + nome + " Duração: " + duracao + " Data: " + data;
	}
	
	public void imprime(){
		System.out.println(toString());
	}
	
}
