package exercicio08_9_10_Cheques_Heranca_Composicao;


public class Teste {
//		8) Analise a figura abaixo para responder as questões 9 e 10:
//		9) Implemente as classes do esquema acima(PagamentoeCheque) e depois preencha as lacunas
//		no código abaixo. Note que PagamentoCheque pode ser composto por vários cheques.
//		public class PagamentoCheque _____________________________{1
//			private String data; _______________________________________//2
//			public PagamentoCheque(){}
//			public PagamentoCheque(double t, String d, Cheque c[]){ 
//				_________________________________//3
//		    }
//		    public String toString(){
//		    	_________________________________//4
//			}
//			public String getData() {
//				return data;
//			}
//			public void setData(String data) {
//				this.data = data;
//			}
//		    //5 - getCheques
//		    //6 - setCheques
//		}
//		10) Analise o código abaixo e determine as linhas que contém erros:
//		public class Teste {
//			public static void main(String[] args) {
//				Pagamento vetor [] = new Pagamento[5];
//				Cheque c1 = new Cheque(1234, 1267);
//				Cheque cheques[] = new Cheque[2];
//				cheques[2] = new Cheque(1235, 12, 1245);
//				vetor[0] = new PagamentoCheque(100.0, "12/11/2008", c1);
//				vetor[2] = new PagamentoCheque (150.0, "16/11/2008", 1234, 1, 3453); 
//				vetor[4] = new PagamentoCheque (50.0, "18/11/2008",cheques);
//				for(int i=0; i<vetor.length; i++) 
//					System.out.println(vetor[i].toString());
//			} 
//		}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
