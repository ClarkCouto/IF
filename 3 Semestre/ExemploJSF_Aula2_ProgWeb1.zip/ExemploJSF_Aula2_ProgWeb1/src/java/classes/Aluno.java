package classes;

import java.util.*;

public class Aluno extends Pessoa{
    private String descricao;
    private String senha;
    private String curso;
    private boolean matriculado;
    private double mensalidade;
    private long anoIngresso;
    private LinkedList<String> cursosSelecionados;
    public Aluno(){}
    public Aluno(String nome, long anoIngresso, double mensalidade) {
        super(nome);
        this.mensalidade = mensalidade;
        this.anoIngresso = anoIngresso;
    }


    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }    

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public boolean isMatriculado() {
        return matriculado;
    }

    public void setMatriculado(boolean matriculado) {
        this.matriculado = matriculado;
    }

    public double getMensalidade() {
        return mensalidade;
    }

    public void setMensalidade(double mensalidade) {
        this.mensalidade = mensalidade;
    }

    public long getAnoIngresso() {
        return anoIngresso;
    }

    public void setAnoIngresso(long anoIngresso) {
        this.anoIngresso = anoIngresso;
    }

   
    public void imprime(){
        super.imprime();
        System.out.println("Descrição:"+descricao);
        System.out.println("Senha:"+senha);
        if(cursosSelecionados!=null){
            for(String cursos : cursosSelecionados)
                System.out.println("Curso:"+cursos);
        }
        System.out.println("Curso:"+curso);
        if(matriculado)System.out.println("Matriculado");
    }
    public LinkedList<String> getCursos(){
        LinkedList<String> cursos = new LinkedList<>();
        cursos.add("EC");
        cursos.add("CIC");
        cursos.add("SSI");
        cursos.add("TADS");
        return cursos;
    }

    public void setCursosSelecionados(LinkedList<String> cursos) {
        this.cursosSelecionados = cursos;
    }

    public LinkedList<String> getCursosSelecionados() {
        return cursosSelecionados;
    }
    
  
}
