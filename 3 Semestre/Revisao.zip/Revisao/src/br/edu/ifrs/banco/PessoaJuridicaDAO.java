/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifrs.banco;

import br.edu.ifrs.pessoas.PessoaJuridica;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author CristianoSilva
 */
public class PessoaJuridicaDAO implements GenericDAO<PessoaJuridica>{

    @Override
    public int insert(PessoaJuridica pessoaJuridica) {
        int chavePrimaria = -1;
        
        try (Connection connection = new ConnectionFactory().getConnection();
                PreparedStatement stmt = connection.prepareStatement(PessoaJuridicaSQLs.INSERT.getSql(),
                        Statement.RETURN_GENERATED_KEYS)) {
            System.out.println("Conexão insert aberta!");
            stmt.setString(1, pessoaJuridica.getCnpj());
            stmt.setString(2, pessoaJuridica.getRazaoSocial());
            stmt.execute();
            
            System.out.println("Dados da Pessoa Jurídica gravados com Sucesso!");
            ResultSet chaves = stmt.getGeneratedKeys();
            if (chaves.next()) {
                chavePrimaria = chaves.getInt(1);
            }
        } 
        catch (SQLException e) {
            System.out.println("exceção com recursos");
        } 
        catch (ClassNotFoundException e) {
            System.out.println("Classe não encontrada!");
        }
        return chavePrimaria;
    }

@Override
    public List<PessoaJuridica> listAll() {
        List<PessoaJuridica> lista = new LinkedList<>();

        try (Connection connection = new ConnectionFactory().getConnection();
            PreparedStatement stmt = connection.prepareStatement(FornecedorSQLs.LISTALL.getSql())) {

            System.out.println("Conexão listAll aberta!");
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int idPessoaJuridica = rs.getInt("idPessoaJuridica");
                String cnpj = rs.getString("cnpj");
                String razaoSocial = rs.getString("razaoSocial");
                //lista.add(new PessoaJuridica(idPessoaJuridica, cnpj, razaoSocial));
            }
            return lista;
        } 
        catch (SQLException e) {
            System.out.println("Exceção SQL");
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código!");
        }
        return null;
    }

    @Override
    public int delete(PessoaJuridica pessoaJuridica) {
        try (Connection connection = new ConnectionFactory().getConnection();
                PreparedStatement stmt = connection.prepareStatement(PessoaJuridicaSQLs.DELETE.getSql())) {
            System.out.println("Conexão delete aberta!");
            //stmt.setInt(1, pessoaJuridica.getIdPessoaJuridica());
            return stmt.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println("Exceção SQL");
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código!");
        }
        return 0;
    }

    @Override
    public int update(PessoaJuridica pessoaJuridica) {
        try (Connection connection = new ConnectionFactory().getConnection();
                PreparedStatement stmt = connection.prepareStatement(FornecedorSQLs.UPDATE.getSql())) {
            System.out.println("\nConexão Update aberta!");
            System.out.println("Dados atualizados " + pessoaJuridica.toString());
            stmt.setString(1, pessoaJuridica.getCnpj());
            stmt.setString(2, pessoaJuridica.getRazaoSocial());
            return stmt.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println("Exceção SQL" + e.getMessage());
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código!");
        }
        return 0;
    }

    @Override
    public PessoaJuridica findByID(int id) {
        try (Connection connection = new ConnectionFactory().getConnection();
            PreparedStatement stmt = connection.prepareStatement(FornecedorSQLs.FINDBYID.getSql())) {

            System.out.println("Conexão FindById aberta!");
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int idPessoaJuridica = rs.getInt("idPessoaJuridica");
                String cnpj = rs.getString("cnpj");
                String razaoSocial = rs.getString("razaosocial");
                //PessoaJuridica pessoaJuridica = new PessoaJuridica(idPessoaJuridica, cnpj, razaoSocial);
                PessoaJuridica pessoaJuridica = new PessoaJuridica(cnpj, razaoSocial);
                System.out.println("Pessoa Juridica encontrada: " + pessoaJuridica.toString());
                return pessoaJuridica;
            }
        } 
        catch (SQLException e) {
            System.out.println("Exceção SQL" + e.getMessage());
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código!");
        }
        return null;
    }
}

