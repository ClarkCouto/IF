/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifrs.banco;

/**
 *
 * @author CristianoSilva
 */
public enum ProdutoSQLs {
    INSERT("insert into produto(codBarras, nome, valor) values (?, ?, ?)"), 
    UPDATE("update produto set codBarras = ?, nome = ?, valor = ? where idProduto = ?"), 
    FINDBYID("select * from produto where idProduto = ?"), 
    DELETE("delete from produto where idProduto = ?"), 
    LISTALL("select * from produto");
    
    private final String sql;
    ProdutoSQLs(String sql){
        this.sql = sql; 
    }

    public String getSql() {
        return sql;
    }    
}
