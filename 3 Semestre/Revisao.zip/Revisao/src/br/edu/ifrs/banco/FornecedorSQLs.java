/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifrs.banco;

/**
 *
 * @author CristianoSilva
 */
public enum FornecedorSQLs {
    INSERT("insert into fornecedor(cnpj, razaosocial, nomeContato, idEndereco) values (?, ?, ?, ?)"), 
    UPDATE("update fornecedor set cnpj = ?, razaosocial = ?, nomeContato = ?, idEndereco = ? where idFornecedor = ?"), 
    FINDBYID("select * from fornecedor where idFornecedor = ?"), 
    DELETE("delete from fornecedor where idFornecedor = ?"), 
    LISTALL("select * from fornecedor");
    
    private final String sql;
    FornecedorSQLs(String sql){
        this.sql = sql; 
    }

    public String getSql() {
        return sql;
    }    
}
