/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifrs.banco;

/**
 *
 * @author CristianoSilva
 */
public enum PessoaJuridicaSQLs {
    INSERT("insert into pessoaJuridica(cnpj, razaoSociao) values (?, ?)"), 
    UPDATE("update pessoaJuridica set cnpj = ?, razaoSocial = ? where idPessoaJuridica = ?"), 
    FINDBYID("select * from pessoaJuridica where idPessoaJuridica = ?"), 
    DELETE("delete from pessoaJuridica where idPessoaJuridica = ?"), 
    LISTALL("select * from pessoaJuridica");
    
    private final String sql;
    PessoaJuridicaSQLs(String sql){
        this.sql = sql; 
    }

    public String getSql() {
        return sql;
    }    
}
