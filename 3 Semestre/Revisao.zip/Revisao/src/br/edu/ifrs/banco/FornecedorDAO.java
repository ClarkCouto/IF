/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifrs.banco;

import br.edu.ifrs.contatos.Endereco;
import br.edu.ifrs.pessoas.Fornecedor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author CristianoSilva
 */
public class FornecedorDAO implements GenericDAO<Fornecedor>{

    @Override
    public int insert(Fornecedor fornecedor) {
        int chavePrimaria = -1;
        int idEndereco = new EnderecoDAO().insert(fornecedor.getEndereco());
        
        try (Connection connection = new ConnectionFactory().getConnection();
                PreparedStatement stmt = connection.prepareStatement(FornecedorSQLs.INSERT.getSql(),
                        Statement.RETURN_GENERATED_KEYS)) {
            System.out.println("Conexão insert Fornecedor aberta!");
            System.out.println("cnpj: " + fornecedor.getCnpj());
            System.out.println("razaosocial: " + fornecedor.getRazaoSocial());
            System.out.println("contato: " + fornecedor.getNomeContato());
            System.out.println("endereco: " + idEndereco);
            stmt.setString(1, fornecedor.getCnpj());
            stmt.setString(2, fornecedor.getRazaoSocial());
            stmt.setString(3, fornecedor.getNomeContato());
            stmt.setInt(4, idEndereco); 
            stmt.execute();
            
            System.out.println("Dados do Fornecedor gravados com Sucesso!");
            ResultSet chaves = stmt.getGeneratedKeys();
            if (chaves.next()) {
                chavePrimaria = chaves.getInt(1);
            }
        } 
        catch (SQLException e) {
            System.out.println("exceção com recursos em Insert Fornecedor");
        } 
        catch (ClassNotFoundException e) {
            System.out.println("Classe não encontrada em Insert Fornecedor!");
        }
        return chavePrimaria;
    }

@Override
    public List<Fornecedor> listAll() {
        List<Fornecedor> lista = new LinkedList<>();

        try (Connection connection = new ConnectionFactory().getConnection();
            PreparedStatement stmt = connection.prepareStatement(FornecedorSQLs.LISTALL.getSql())) {

            System.out.println("Conexão listAll Fornecedor aberta!");
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int idFornecedor = rs.getInt("idFornecedor");
                String cnpj = rs.getString("cnpj");
                String razaoSocial = rs.getString("razaoSocial");
                String nomeContato = rs.getString("nomeContato");
                int idEndereco = rs.getInt("idEndereco");
                
                Fornecedor fornecedor = new Fornecedor(idFornecedor, cnpj, razaoSocial, nomeContato, new Endereco().findById(idEndereco));
                System.out.println("Fornecedor Encontrado DAO: " + fornecedor.toString());
                lista.add(fornecedor);

                //lista.add(new Fornecedor(idFornecedor, cnpj, razaoSocial, nomeContato, new Endereco().findById(idEndereco)));
            }
            return lista;
        } 
        catch (SQLException e) {
            System.out.println("Exceção SQL em listAll Fornecedor");
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada em listAll Fornecedor!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código em listAll Fornecedor!");
        }
        return null;
    }

    @Override
    public int delete(Fornecedor fornecedor) {
        try (Connection connection = new ConnectionFactory().getConnection();
                PreparedStatement stmt = connection.prepareStatement(FornecedorSQLs.DELETE.getSql())) {
            System.out.println("Conexão Delete Fornecedor aberta!");
            stmt.setInt(1, fornecedor.getIdFornecedor());
            return stmt.executeUpdate();
        } 
        catch (IndexOutOfBoundsException e) {
            System.out.println("Posição inválida para exclusão em Delete Fornecedor");
        }
        catch (SQLException e) {
            System.out.println("Exceção SQL em Delete Fornecedor");
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada em Delete Fornecedor!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código em Delete Fornecedor!");
        }
        return 0;
    }

    @Override
    public int update(Fornecedor fornecedor) {
        try (Connection connection = new ConnectionFactory().getConnection();
                PreparedStatement stmt = connection.prepareStatement(FornecedorSQLs.UPDATE.getSql())) {
            System.out.println("\nConexão Update Fornecedor aberta!");
            stmt.setString(1, fornecedor.getCnpj());
            stmt.setString(2, fornecedor.getRazaoSocial());
            stmt.setString(3, fornecedor.getNomeContato());
            stmt.setInt(4, fornecedor.getEndereco().getIdEndereco());
            stmt.setInt(5, fornecedor.getIdFornecedor());
            System.out.println("Dados atualizados " + fornecedor.toString());
            return stmt.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println("Exceção SQL em Update Fornecedor" + e.getSQLState() + "\n"+ e.getMessage());
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada em Update Fornecedor!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código!");
        }
        return 0;
    }

    @Override
    public Fornecedor findByID(int id) {
        try (Connection connection = new ConnectionFactory().getConnection();
            PreparedStatement stmt = connection.prepareStatement(FornecedorSQLs.FINDBYID.getSql())) {

            System.out.println("Conexão FindById Fornecedor aberta!");
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int idFornecedor = rs.getInt("idFornecedor");
                String cnpj = rs.getString("cnpj");
                String razaoSocial = rs.getString("razaosocial");
                String nomeContato = rs.getString("nomeContato");
                int idEndereco = rs.getInt("idEndereco");
                //Fornecedor fornecedor = new Fornecedor(idFornecedor, cnpj, razaoSocial, nomeContato, new Endereco().findById(idEndereco));
                //System.out.println("Fornecedor encontrado: " + fornecedor.toString());
                //return fornecedor;
                return new Fornecedor(idFornecedor, cnpj, razaoSocial, nomeContato, new Endereco().findById(idEndereco));
            }
        } 
        catch (SQLException e) {
            System.out.println("Exceção SQL em FindById Fornecedor" + e.getMessage());
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada em FindById Fornecedor!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código em FindById Fornecedor!");
        }
        return null;
    }
}

