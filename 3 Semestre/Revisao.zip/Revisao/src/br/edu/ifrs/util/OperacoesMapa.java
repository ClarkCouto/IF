/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifrs.util;

import java.util.Set;

/**
 *
 * @author 0729159
 */
public interface OperacoesMapa <K, V> {
    /*
    8) Criar a interface OperacoesMapa, genérica, conforme as regras abaixo:
    8.1 Lista está definida no pacote package br.edu.ifrs.util;
    8.2 método void adicionar(Object chave, Object valor)
    8.3 Set getChaves
    8.4 Object getValor(Object chave)
    8.5 Object remover(Object chave)
    8.6 boolean substituir(Object chave, Object valorVelho, Object valorNovo)
    8.7 String toString() 
    */
    public void adicionar(K key, V value);
    public Set<K> getChaves();
    public V getValor(K key);
    public V remover(K key);
    public boolean substituir(K key, V oldValue, V newValue);
    public String toString();
}
