/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifrs.pessoas;

import br.edu.ifrs.banco.FornecedorDAO;
import br.edu.ifrs.contatos.Endereco;
import java.util.List;

/**
 *
 * @author 0729159
 */
public class Fornecedor extends PessoaJuridica{
    private String nomeContato;
    private Endereco endereco;
    private int idFornecedor;
    
    public Fornecedor() {}

    public Fornecedor(String cnpj, String razaoSocial, String nomeContato, Endereco endereco) {
        this(-1, cnpj, razaoSocial, nomeContato, endereco);
    }
    
    public Fornecedor(int idFornecedor, String cnpj, String razaoSocial, String nomeContato, Endereco endereco) {
        super(cnpj, razaoSocial);
        this.idFornecedor = idFornecedor;
        this.nomeContato = nomeContato;
        this.endereco = endereco;
    }

    public int getIdFornecedor() {
        return idFornecedor;
    }

    public String getNomeContato() {
        return nomeContato;
    }

    public Endereco getEndereco() {
        return endereco;
    }

    public void setIdFornecedor(int idFornecedor) {
        this.idFornecedor = idFornecedor;
    }

    public void setNomeContato(String nomeContato) {
        this.nomeContato = nomeContato;
    }

    public void setEndereco(Endereco endereco) {
        this.endereco = endereco;
    }
    
    @Override
    public void listar(){
        System.out.println(toString());
    }

    @Override
    public String toString() {
        return "\n\tFornecedor " + (idFornecedor != -1 ? "\tID: " + idFornecedor : "") + super.toString() + "\n\t\tNome Contato: " + nomeContato +
                (endereco != null ? "\n\t\tEndereço " + endereco.toString() : "\n\t\tEndereço Inválido!");
    }
    
    public int insert() {
        return new FornecedorDAO().insert(this);
    }
    public List<Fornecedor> listAll(){
        return new FornecedorDAO().listAll();
    }
    public int delete() {
        return new FornecedorDAO().delete(this);
    }
    public int update() {
        return new FornecedorDAO().update(this);
    }
    public Fornecedor findById(int idFornecedor) {
        return new FornecedorDAO().findByID(idFornecedor);
    }
    
}
