/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifrs.pessoas;

//import br.edu.ifrs.banco.PessoaJuridicaDAO;
//import java.util.List;

/**
 *
 * @author 0729159
 */
public class PessoaJuridica {
    private String cnpj;
    private String razaoSocial;
//    private int idPessoaJuridica;

    public PessoaJuridica() {}
    
    public PessoaJuridica(String cnpj, String razaoSocial) {
        //this(-1, cnpj, razaoSocial);
        this.cnpj = cnpj;
        this.razaoSocial = razaoSocial;
    }
    
//    public PessoaJuridica(int idPessoaJuridica, String cnpj, String razaoSocial) {
//        this.idPessoaJuridica = idPessoaJuridica;
//        this.cnpj = cnpj;
//        this.razaoSocial = razaoSocial;
//    }

//    public int getIdPessoaJuridica() {
//        return idPessoaJuridica;
//    }

    public String getCnpj() {
        return cnpj;
    }

    public String getRazaoSocial() {
        return razaoSocial;
    }

//    public void setIdPessoaJuridica(int idPessoaJuridica) {
//        this.idPessoaJuridica = idPessoaJuridica;
//    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public void setRazaoSocial(String razaoSocial) {
        this.razaoSocial = razaoSocial;
    }
    
    public void listar(){}

    @Override
    public String toString() {
        //return "ID: "+ idPessoaJuridica + " CNPJ: " + cnpj + "\nRazão Social: " + razaoSocial;
        return "\n\t\tCNPJ: " + cnpj + "\n\t\tRazão Social: " + razaoSocial;
    }
    /*
    public int insert() {
        return new PessoaJuridicaDAO().insert(this);
    }
    public List<PessoaJuridica> listAll(){
        return new PessoaJuridicaDAO().listAll();
    }
    public int delete() {
        return new PessoaJuridicaDAO().delete(this);
    }
    public int update() {
        return new PessoaJuridicaDAO().update(this);
    }
    public PessoaJuridica findById(int idPessoaJuridica) {
        return new PessoaJuridicaDAO().findByID(idPessoaJuridica);
    }
    */
}
