/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifrs.testes;

import br.edu.ifrs.contatos.Endereco;
import br.edu.ifrs.pessoas.Fornecedor;
import br.edu.ifrs.produtos.Produto;
import java.util.LinkedList;

/**
 *
 * @author 0729159
 */
public class Exercicio_1_e_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args){
        /*
        1) Analise o esquema abaixo e crie todas as classes usando a linguagem de programação em Java.
        1.1 A classe Fornecedor tem um endereço
        1.2 A classe Fornecedor é subclasse de PessoaJuridica
        1.3 A classe Produto tem vários fornecedores - use uma LinkedList para implementar isso
        1.4 Use, sempre que possível, this e super
        
        2) Monte uma classe de testes para criar e listar dois produtos. Crie o primeiro objeto usando o
        construtor com parâmetros e o segundo objeto usando o construtor sem parâmetros. 
        */
        
        LinkedList<Produto> lista = new LinkedList<>();
        
        LinkedList<Fornecedor> fornecedores = new LinkedList<>();
        fornecedores.add(new Fornecedor("0123456789", "Fornecedor1", "Contato1", new Endereco("Rua x", "apto 1")));
        fornecedores.add(new Fornecedor("9876543210", "Fornecedor2", "Contato2", new Endereco("Rua y", "apto 2")));
        
        System.out.println("Adiciona um produto usando construtor com parâmetros...");
        lista.add(new Produto(123456789, "Produto 1", 10.5D, fornecedores));
        
        System.out.println("\nAdiciona um produto usando construtor sem parâmetros...");
        Produto p = new Produto();
        p.setCodBarras(987654321);
        p.setNome("Produto 2");
        p.setValor(5.5);
        p.setFornecedores(fornecedores);
        lista.add(p);
        
        System.out.println(lista.toString());
    }
    
}
