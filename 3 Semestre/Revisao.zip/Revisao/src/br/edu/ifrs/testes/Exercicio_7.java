/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifrs.testes;

/**
 *
 * @author 0729159
 */
public class Exercicio_7 {
    public static void main(String[] args){
        System.out.println("Início do main()");
        metodo1();
        System.out.println("Fim do main()");
    }
    
    private static void metodo1() {
        System.out.println("Início do metodo1()");
        try{
            metodo2();
        }
        catch(ArrayIndexOutOfBoundsException e){
            System.out.println("ArrayIndexOutOfBoundsException"); 
        }
        System.out.println("Fim do metodo1()");
    }

    private static void metodo2() {
        System.out.println("Início do metodo2()");
        int[] array = new int[5];
        for (int i = 5; i >0; i--) {
                array[i] = i;
                System.out.println(i);
        }
        System.out.println("Fim do metodo2()"); 
    }
    
    /*
    7.1 Execute o código acima. Agora, determine qual exceção foi gerada.
        ArrayIndexOutOfBoundsException
    
    7.2 Adicione um try/catch em volta do for, dentro do metodo2(). O que o código imprime?
    
        private static void metodo2() {
            System.out.println("Início do metodo2()");
            int[] array = new int[5];
            try{
                for (int i = 5; i >0; i--) {
                    array[i] = i;
                    System.out.println(i);
                }
            }
            catch(ArrayIndexOutOfBoundsException e){
                System.out.println("ArrayIndexOutOfBoundsException"); 
            }
            System.out.println("Fim do metodo2()"); 
        }
    
        IMPRIME:
        Início do main()
        Início do metodo1()
        Início do metodo2()
            ArrayIndexOutOfBoundsException
        Fim do metodo2()
        Fim do metodo1()
        Fim do main()
    
    7.3 Agora, adicione o try/catch em torno de todo o método2(). O que o código vai imprimir?
    Qual a diferença entre a saída do item 7.2 e esta?
    
        try{
            private static void metodo2() {
                System.out.println("Início do metodo2()");
                int[] array = new int[5];
                for (int i = 5; i >0; i--) {
                        array[i] = i;
                        System.out.println(i);
                }
                System.out.println("Fim do metodo2()"); 
            }
        }
        catch(ArrayIndexOutOfBoundsException e){
            System.out.println("ArrayIndexOutOfBoundsException"); 
        }
    
        IMPRIME:
        Início do main()
        Início do metodo1()
        Exception in thread "main" java.lang.ArrayIndexOutOfBoundsException: 5
        Início do metodo2()
                at br.edu.ifrs.testes.Exercicio_7.metodo2(Exercicio_7.java:30)
                at br.edu.ifrs.testes.Exercicio_7.metodo1(Exercicio_7.java:21)
                at br.edu.ifrs.testes.Exercicio_7.main(Exercicio_7.java:15)
        C:\Users\0729159\AppData\Local\NetBeans\Cache\8.2\executor-snippets\run.xml:53: Java returned: 1
    
        Gera Exceção
    
    7.4 Adicione o try/catch dentro do for no metodo2(). O que o código vai imprimir?
    
        int[] array = new int[5];
        for (int i = 5; i >0; i--) {
            try{
                array[i] = i;
                System.out.println(i);
            }
            catch(ArrayIndexOutOfBoundsException e){
                System.out.println("ArrayIndexOutOfBoundsException"); 
            }
        }
    
        IMPRIME:
        Início do main()
        Início do metodo1()
        Início do metodo2()
        ArrayIndexOutOfBoundsException
        4
        3
        2
        1
        Fim do metodo2()
        Fim do metodo1()
        Fim do main()
    
    
    7.5 Retire o try/catch e coloque ele em torno da chamada do metodo2. Qual as saída gerada?
    Qual a diferença entre a saída dos itens 7.1, 7.2 e esta? 
    
        try{
            metodo2();
        }
        catch(ArrayIndexOutOfBoundsException e){
            System.out.println("ArrayIndexOutOfBoundsException"); 
        }
    
        IMPRIME:
        Início do main()
        Início do metodo1()
        Início do metodo2()
        ArrayIndexOutOfBoundsException
        Fim do metodo1()
        Fim do main()
    
        Não imprime o metodo2()
    */
    
}
