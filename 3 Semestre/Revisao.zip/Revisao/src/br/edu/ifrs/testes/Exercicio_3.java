/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifrs.testes;

import br.edu.ifrs.contatos.Endereco;
import br.edu.ifrs.pessoas.Fornecedor;
import br.edu.ifrs.produtos.Produto;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;

/**
 *
 * @author 0729159
 */
public class Exercicio_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException, IOException{
        /*
        3) Reescreva as linhas abaixo utilizando o menor número de linhas e variáveis possível:
        3.1
        FileSystem fs = FileSystems.getDefault();
        Path diretorio = fs.getPath("C:", "Diretorio", "Teste");
        Path arquivo = diretorio.resolve("Teste.txt");
        */
        
        Path fs = FileSystems.getDefault().getPath("C:", "Diretorio", "Teste").resolve("Teste.txt");
        
        /*
        3.2
        File arquivo = new File("Q1.txt");
        FileOutputStream saida = new FileOutputStream( arquivo );
        BufferedOutputStream escrita = new BufferedOutputStream(saida);
        escrita.write( "questao1_prova".getBytes());
        */
        
        new BufferedOutputStream(new FileOutputStream(new File("Q1.txt"))).write("questao1_prova".getBytes());
        
        /*
        3.3
        File arquivo = new File("Q1.txt");
        FileReader entrada = new FileReader(arquivo);
        BufferedReader leitura = new BufferedReader(fr); 
        */
        
        BufferedReader leitura = new BufferedReader(new FileReader(new File("Q1.txt"))); 
        
    }
    
}
