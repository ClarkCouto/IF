/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifrs.testes;

/**
 *
 * @author 0729159
 */
public class Exercicio_4 {
    public static void main(String[] args){
        /*
        4) Analise a saída gerada (pilha de execução) quando um programa Java é executado. Agora,
        responda os itens 4.1 a 4.5.
        Exception in thread "main" java.lang.IndexOutOfBoundsException: Index: 3,
        Size: 2
         at java.util.LinkedList.checkPositionIndex(LinkedList.java:560)
         at java.util.LinkedList.add(LinkedList.java:507)
         at excecoes.Questao1.main(Questao1.java:18)
        Java Result: 1
        4.1 Qual o nome da classe em que foi gerada a exceção? Questao1
        4.2 Qual o nome do método em que a exceção foi gerada? main
        4.3 Qual a linha que gerou a exceção? 18
        4.4 Qual exceção foi gerada? IndexOutOfBoundsException
        4.5 Qual a causa da exceção gerada? Index: 3, Size: 2
        */
    }
}
