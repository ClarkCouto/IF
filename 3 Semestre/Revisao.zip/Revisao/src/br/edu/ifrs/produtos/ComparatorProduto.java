/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifrs.produtos;

import java.util.Comparator;

/**
 *
 * @author CristianoSilva
 */
public class ComparatorProduto implements Comparator<Produto> {
    public int compare(Produto p1, Produto p2) {
        return p1.compareTo(p2); 
    }
}
