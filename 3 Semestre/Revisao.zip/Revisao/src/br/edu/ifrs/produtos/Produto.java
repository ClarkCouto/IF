/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifrs.produtos;

import br.edu.ifrs.banco.ProdutoDAO;
import br.edu.ifrs.pessoas.Fornecedor;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author 0729159
 */
public class Produto implements Comparable<Produto>{
    /*
    12) Redefina a classe Produto de modo que ela possa ser armazenada em um TreeSet. Lembre-se
    que para fazer isso é necessário implementar interfaces que possibilitam ordenar os seus objetos.
    Use o código de barras para a sua ordenação. 
    */
        
    private long codBarras;
    private String nome;
    private double valor;
    private LinkedList<Fornecedor> fornecedores;
    private int idProduto;

    public Produto() {}
    
    public Produto(long codBarras, String nome, double valor, LinkedList<Fornecedor> fornecedores) {
        this(-1, codBarras, nome, valor, fornecedores);
    }
    
    public Produto(int idProduto, long codBarras, String nome, double valor, LinkedList<Fornecedor> fornecedores) {
        this.idProduto = idProduto;
        this.codBarras = codBarras;
        this.nome = nome;
        this.valor = valor;
        this.fornecedores = fornecedores;
    }

    public int getIdProduto() {
        return idProduto;
    }

    public long getCodBarras() {
        return codBarras;
    }

    public String getNome() {
        return nome;
    }

    public double getValor() {
        return valor;
    }

    public LinkedList<Fornecedor> getFornecedores() {
        return fornecedores;
    }

    public void setIdProduto(int idProduto) {
        this.idProduto = idProduto;
    }

    public void setCodBarras(long codBarras) {
        this.codBarras = codBarras;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public void setFornecedores(LinkedList<Fornecedor> fornecedores) {
        this.fornecedores = fornecedores;
    }
    
    public void listar(){}

    @Override
    public String toString() {
        String aux = "\nFornecedores não informados";
        if(fornecedores.size() != 0){
            aux = "\n\tFornecedores: ";
            for(Fornecedor f : fornecedores)
                aux += f.toString() + "\n";
        }
        return "\nProduto" + (idProduto != -1 ? " ID: " + idProduto : "") + "\n\tCód. Barras: " + codBarras + "\n\tNome: " + nome + "\n\tValor: " + valor + aux;
    }

    @Override
    public int compareTo(Produto p) {
        return Long.compare(this.getCodBarras(), p.getCodBarras());
    }
    
    public int insert() {
        return new ProdutoDAO().insert(this);
    }
    public List<Produto> listAll(){
        return new ProdutoDAO().listAll();
    }
    public int delete() {
        return new ProdutoDAO().delete(this);
    }
    public int update() {
        return new ProdutoDAO().update(this);
    }
    public Produto findById(int idProduto) {
        return new ProdutoDAO().findByID(idProduto);
    }
}
