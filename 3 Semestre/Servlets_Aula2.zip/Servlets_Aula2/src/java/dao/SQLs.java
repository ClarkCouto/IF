/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

/**
 *
 * @author Silvia Bertagnolli
 */
public enum SQLs {
    INSERT_PESSOA("insert into pessoa(nome, endereco) values (?, ?)"), 
    LISTALL_PESSOA("select * from pessoa"),
    AUTENTICA_USUARIO("select * from usuario WHERE email=? and senha=?");
   
    
    private final String sql;
    SQLs(String sql){
        this.sql = sql; 
    
    }

    public String getSql() {
        return sql;
    }    
}

