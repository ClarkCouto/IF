package dao;

import classes.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class UsuarioDAO implements GenericDAO<Usuario>{
    @Override
    public int insert(Usuario p) {
        return 1;
    }
    @Override
    public  List<Usuario> listAll() {
        return null;
    }
    public boolean autentica(Usuario user){
        boolean retorno = false;
         try(Connection connection = new ConnectionFactory().getConnection();
            PreparedStatement stmt = 
                    connection.prepareStatement(SQLs.AUTENTICA_USUARIO.getSql())){
       
            ResultSet rs = stmt.executeQuery();
            System.out.println("Dados Recuperados!");
            rs.last();
            if(rs.getRow()>=1) return true;
        }catch(SQLException e){ System.out.println("Exceção SQL - autentica");
        }catch(Exception e){  System.out.println("Exceção no código!");
        }
        return retorno;
    }
}
