package classes;

import dao.UsuarioDAO;

public class Usuario{  
    private Long id;  
    private String email;  
    private String senha;  

    public Usuario(){}
    public Usuario(String email, String senha) {
        this.email = email;
        this.senha = senha;
    }
      
    public String getEmail() {  
        return email;  
    }  
    public void setEmail(String email) {  
        this.email = email;  
    }  
    public String getSenha() {  
        return senha;  
    }  
    public void setSenha(String senha) {  
        this.senha = senha;  
    }       
    
    public boolean autentica(){
        UsuarioDAO user = new UsuarioDAO();
        return user.autentica(this);
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    
}