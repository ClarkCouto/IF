/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/**
 *
 * @author 0729159
 */
public class Pessoa {
    private String nome;
    private String nascimento;

    public Pessoa() {
    }

    public Pessoa(String nome, String nascimento) {
        this.nome = nome;
        this.nascimento = nascimento;
    }

    public String getNome() {
        return nome;
    }

    public String getNascimento() {
        return nascimento;
    }
    
    public long calculaIdade() {
        String data[] =  null;
        LocalDate dataNascimento = null;
        try{ 
            data = getNascimento().split("/");
        }
        catch(Exception e){
            System.out.println("Erro no split da data");
        }
        if(data != null){
            try{
                dataNascimento = LocalDate.of(Integer.parseInt(data[2]), Integer.parseInt(data[1]), Integer.parseInt(data[0]));
            }
            catch(NumberFormatException e){
                System.out.println("Erro na instanciação da data");
            }
            if(dataNascimento != null)
                return ChronoUnit.YEARS.between(dataNascimento, LocalDate.now());
        }
        return 0;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setNascimento(String nascimento) {
        this.nascimento = nascimento;
    }

    @Override
    public String toString() {
        return "Nome: " + nome + "\tData de Nascimento: " + nascimento + "\tIdade: " + calculaIdade();
    }
    
    
}
