/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

/**
 *
 * @author 
 */
public enum EnderecoSQLs {
    INSERT("insert into endereco(logradouro, complemento, uf) values (?, ?, ?)"), 
    UPDATE("update endereco set logradouro = ?, complemento = ?, uf = ? where idendereco = ?"), 
    FINDBYID("select * from endereco where idendereco = ?"), 
    DELETE("delete from endereco where idendereco = ?"), 
    LISTALL("select * from endereco");
    
    private final String sql;
    EnderecoSQLs(String sql){
        this.sql = sql; 
    }

    public String getSql() {
        return sql;
    }    
}

