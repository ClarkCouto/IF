/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

/**
 *
 * @author 
 */
public enum CpfSQLs {
    INSERT("insert into cpf(numero, digito) values (?, ?)"), 
    UPDATE("update cpf set numero = ?, digito = ? where idCpf = ?"), 
    FINDBYID("select * from cpf where idCpf = ?"), 
    DELETE("delete from cpf where idCpf = ?"), 
    LISTALL("select * from cpf");
    
    private final String sql;
    CpfSQLs(String sql){
        this.sql = sql; 
    }

    public String getSql() {
        return sql;
    }    
}

