/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import classes.Cpf;
import java.sql.*;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author silviacb
 */
public class CpfDAO implements GenericDAO<Cpf>{
    
    public Cpf find (Connection con, int idCpf){
        try{
            PreparedStatement stmt = 
                    con.prepareStatement("select * from cpf where idcpf = ?");
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                long numero = rs.getLong("numero");
                int digito = rs.getInt("digito");
                return new Cpf(numero, digito);
            }
        }
        catch(SQLException e){
            System.out.println("Exceção find CpfDAO");
        }
        return null;
    }

    @Override
    public int insert(Cpf cpf) {
        int chavePrimaria = -1;
        
        try (Connection connection = new ConnectionFactory().getConnection();
                PreparedStatement stmt = connection.prepareStatement(CpfSQLs.INSERT.getSql(),
                        Statement.RETURN_GENERATED_KEYS)) {
            System.out.println("Conexão insert aberta!");
            stmt.setLong(1, cpf.getNumero());
            stmt.setInt(2, cpf.getDigito());
            
            stmt.execute();
            
            System.out.println("Dados do Cpf Gravados!");
            ResultSet chaves = stmt.getGeneratedKeys();
            if (chaves.next()) {
                chavePrimaria = chaves.getInt(1);
            }
        } 
        catch (SQLException e) {
            System.out.println("exceção com recursos");
        } 
        catch (ClassNotFoundException e) {
            System.out.println("Classe não encontrada!");
        }
        return chavePrimaria;
    }

@Override
    public List<Cpf> listAll() {
        List<Cpf> lista = new LinkedList<>();

        try (Connection connection = new ConnectionFactory().getConnection();
            PreparedStatement stmt = connection.prepareStatement(CpfSQLs.LISTALL.getSql())) {

            System.out.println("Conexão listAll aberta!");
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int idCpf = rs.getInt("idCpf");
                int numero = rs.getInt("numero");
                int digito = rs.getInt("digito");
                lista.add(new Cpf(idCpf, numero, digito));
            }
            return lista;
        } 
        catch (SQLException e) {
            System.out.println("Exceção SQL");
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código!");
        }
        return null;
    }

    @Override
    public int delete(Cpf cpf) {
        try (Connection connection = new ConnectionFactory().getConnection();
                PreparedStatement stmt = connection.prepareStatement(CpfSQLs.DELETE.getSql())) {
            System.out.println("Conexão delete aberta!");
            stmt.setInt(1, cpf.getIdCpf());
            return stmt.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println("Exceção SQL");
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código!");
        }
        return 0;
    }

    @Override
    public int update(Cpf cpf) {
        try (Connection connection = new ConnectionFactory().getConnection();
                PreparedStatement stmt = connection.prepareStatement(CpfSQLs.UPDATE.getSql())) {
            System.out.println("\nConexão Update aberta!");
            System.out.println("Dados atualizados " + cpf.toString());
            stmt.setLong(1, cpf.getNumero());
            stmt.setInt(2, cpf.getDigito());;
            return stmt.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println("Exceção SQL" + e.getMessage());
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código!");
        }
        return 0;
    }

    @Override
    public Cpf findByID(int id) {
        try (Connection connection = new ConnectionFactory().getConnection();
            PreparedStatement stmt = connection.prepareStatement(CpfSQLs.FINDBYID.getSql())) {

            System.out.println("Conexão FindById aberta!");
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int idCpf = rs.getInt("idCpf");
                long numero = rs.getLong("numero");
                int digito = rs.getInt("digito");
                Cpf cpf = new Cpf(idCpf, numero, digito);
                System.out.println("Cpf encontrado: " + cpf.toString());
                return cpf;
                //return new Cpf(idCpf, numero, digito);
            }
        } 
        catch (SQLException e) {
            System.out.println("Exceção SQL" + e.getMessage());
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código!");
        }
        return null;
    }
}
