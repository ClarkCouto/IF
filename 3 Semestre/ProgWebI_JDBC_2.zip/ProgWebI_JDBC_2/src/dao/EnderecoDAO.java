/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import classes.Endereco;
import java.sql.*;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author silviacb
 */
public class EnderecoDAO implements GenericDAO<Endereco> {

    @Override
    public int insert(Endereco endereco) {
        int chavePrimaria = -1;
        try (Connection connection = new ConnectionFactory().getConnection();
                PreparedStatement stmt = connection.prepareStatement(EnderecoSQLs.INSERT.getSql(),
                        Statement.RETURN_GENERATED_KEYS)) {
            System.out.println("Conexão insert aberta!");
            stmt.setString(1, endereco.getLogradouro());
            stmt.setString(2, endereco.getComplemento());
            stmt.setString(3, endereco.getUf());
            stmt.execute();
            System.out.println("Dados Gravados!");
            ResultSet chaves = stmt.getGeneratedKeys();
            if (chaves.next()) {
                chavePrimaria = chaves.getInt(1);
            }
        } 
        catch (SQLException e) {
            System.out.println("exceção com recursos");
        } 
        catch (ClassNotFoundException e) {
            System.out.println("Classe não encontrada!");
        }
        return chavePrimaria;
    }

    @Override
    public List<Endereco> listAll() {
        List<Endereco> lista = new LinkedList<>();

        try (Connection connection = new ConnectionFactory().getConnection();
            PreparedStatement stmt = connection.prepareStatement(EnderecoSQLs.LISTALL.getSql())) {

            System.out.println("Conexão listAll aberta!");
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int idEndereco = rs.getInt("idEndereco");
                String logradouro = rs.getString("logradouro");
                String complemento = rs.getString("complemento");
                String uf = rs.getString("uf");
                lista.add(new Endereco(idEndereco, logradouro, complemento, uf));
            }
            return lista;
        } 
        catch (SQLException e) {
            System.out.println("Exceção SQL");
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código!");
        }
        return null;
    }

    @Override
    public int delete(Endereco obj) {
        try (Connection connection = new ConnectionFactory().getConnection();
                PreparedStatement stmt = connection.prepareStatement(EnderecoSQLs.DELETE.getSql())) {
            System.out.println("Conexão delete aberta!");
            stmt.setInt(1, obj.getIdEndereco());
            return stmt.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println("Exceção SQL");
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código!");
        }
        return 0;
    }

    @Override
    public int update(Endereco obj) {
        try (Connection connection = new ConnectionFactory().getConnection();
                PreparedStatement stmt = connection.prepareStatement(EnderecoSQLs.UPDATE.getSql())) {
            System.out.println("\nConexão Update aberta!");
            System.out.println("Dados atualizados " + obj.toString());
            stmt.setString(1, obj.getLogradouro());
            stmt.setString(2, obj.getComplemento());
            stmt.setString(3, obj.getUf());
            return stmt.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println("Exceção SQL" + e.getMessage());
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código!");
        }
        return 0;
    }

    @Override
    public Endereco findByID(int id) {
        try (Connection connection = new ConnectionFactory().getConnection();
            PreparedStatement stmt = connection.prepareStatement(EnderecoSQLs.FINDBYID.getSql())) {

            System.out.println("Conexão FindById aberta!");
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int idEndereco = rs.getInt("idEndereco");
                String logradouro = rs.getString("logradouro");
                String complemento = rs.getString("complemento");
                String uf = rs.getString("uf");
                Endereco end = new Endereco(idEndereco, logradouro, complemento, uf);
                System.out.println("Endereco Encontrado: " + end.toString());
                return end;
                //return new Pessoa(idPessoa, nome, endereco);
            }
        } 
        catch (SQLException e) {
            System.out.println("Exceção SQL" + e.getMessage());
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código!");
        }
        return null;
    }
}
