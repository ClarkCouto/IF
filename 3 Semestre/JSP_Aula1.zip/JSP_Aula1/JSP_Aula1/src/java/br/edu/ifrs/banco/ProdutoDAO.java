/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifrs.banco;

import br.edu.ifrs.contatos.Endereco;
import br.edu.ifrs.pessoas.Fornecedor;
import br.edu.ifrs.produtos.Produto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author CristianoSilva
 */
public class ProdutoDAO implements GenericDAO<Produto>{

    @Override
    public int insert(Produto produto) {
        int chavePrimaria = -1;
        
        try (Connection connection = new ConnectionFactory().getConnection();
                PreparedStatement stmt = connection.prepareStatement(ProdutoSQLs.INSERT.getSql(),
                        Statement.RETURN_GENERATED_KEYS)) {
            System.out.println("Conexão Insert Protudo aberta!");
            stmt.setLong(1, produto.getCodBarras());
            stmt.setString(2, produto.getNome());
            stmt.setDouble(3, produto.getValor());
            stmt.execute();
            
            System.out.println("Dados do Produto gravados com Sucesso!");
            ResultSet chaves = stmt.getGeneratedKeys();
            if (chaves.next()) {
                chavePrimaria = chaves.getInt(1);
            }
            
            //List<Fornecedor> fornecedores = produto.getFornecedores();
            //for(Fornecedor f : fornecedores)
                
        } 
        catch (SQLException e) {
            System.out.println("exceção com recursos em Insert Protudo");
        } 
        catch (ClassNotFoundException e) {
            System.out.println("Classe não encontrada em Insert Protudo!");
        }
        return chavePrimaria;
    }

@Override
    public List<Produto> listAll() {
        List<Produto> lista = new LinkedList<>();

        try (Connection connection = new ConnectionFactory().getConnection();
            PreparedStatement stmt = connection.prepareStatement(ProdutoSQLs.LISTALL.getSql())) {

            System.out.println("Conexão listAll Produto aberta!");
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int idProduto = rs.getInt("idProduto");
                long codBarras = rs.getLong("codBarras");
                String nome = rs.getString("nome");
                Double valor = rs.getDouble("valor");
                lista.add(new Produto(idProduto, codBarras, nome, valor, new LinkedList<Fornecedor>()));
            }
            return lista;
        } 
        catch (SQLException e) {
            System.out.println("Exceção SQL em ListAll Produto");
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada em ListAll Produto!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código em ListAll Produto!");
        }
        return null;
    }

    @Override
    public int delete(Produto Produto) {
        try (Connection connection = new ConnectionFactory().getConnection();
                PreparedStatement stmt = connection.prepareStatement(ProdutoSQLs.DELETE.getSql())) {
            System.out.println("Conexão Delete Produto aberta!");
            stmt.setInt(1, Produto.getIdProduto());
            return stmt.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println("Exceção SQL em Delete Produto");
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada em Delete Produto!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código em Delete Produto!");
        }
        return 0;
    }

    @Override
    public int update(Produto produto) {
        try (Connection connection = new ConnectionFactory().getConnection();
                PreparedStatement stmt = connection.prepareStatement(ProdutoSQLs.UPDATE.getSql())) {
            System.out.println("\nConexão Update Produto aberta!");
            System.out.println("Dados atualizados " + produto.toString());
            stmt.setLong(1, produto.getCodBarras());
            stmt.setString(2, produto.getNome());
            stmt.setDouble(3, produto.getValor());
            return stmt.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println("Exceção SQL em Update Produto " + e.getMessage());
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada em Update Produto!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código em Update Produto!");
        }
        return 0;
    }

    @Override
    public Produto findByID(int id) {
        try (Connection connection = new ConnectionFactory().getConnection();
            PreparedStatement stmt = connection.prepareStatement(ProdutoSQLs.FINDBYID.getSql())) {

            System.out.println("Conexão FindById Produto aberta!");
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int idProduto = rs.getInt("idProduto");
                long codBarras = rs.getLong("codBarras");
                String nome = rs.getString("nome");
                Double valor = rs.getDouble("valor");
                Produto produto = new Produto(idProduto, codBarras, nome, valor, new LinkedList<Fornecedor>());
                System.out.println("Fornecedor encontrado: " + produto.toString());
                return produto;
                //return new Empregado(idEmpregado, nome, endereco, telefone, new Cpf().findById(idCpf));
            }
        } 
        catch (SQLException e) {
            System.out.println("Exceção SQL em FindById Produto" + e.getMessage());
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada em FindById Produto!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código em FindById Produto!");
        }
        return null;
    }
}

