/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifrs.util;

import java.util.HashMap;
import java.util.Set;

/**
 *
 * @author 0729159
 */
public class MeuMapa <K, V> implements OperacoesMapa <K, V>{
    /*
    9) Crie a classe MeuMapa que deve ser definida como genérica e utilizar a classe HashMap. Para
    resolver essa questão você ainda deve usar a interface definida na questão anterior e tratamento
    de exceções. 
    */
    
    /*
    10) Agora, determine:
    10.1 Qual código deveria ser incluído/excluído na classe anterior se o método adicionar propagasse
    a exceção NullPointerException? throws NullPointerException
    10.2 Qual código deveria ser incluído/excluído na classe anterior se o método substituir causasse
    a exceção NullPointerException? catch NullPointerException
    */
    
    private HashMap<K, V> mapa = new HashMap<>();
    /*
    private K key;
    private V value;
    
    public MeuMapa(){}
    
    public MeuMapa(K key, V value){
        this.key = key;
        this.value = value;
    }
    */
    @Override
    public void adicionar(K key, V value) throws NullPointerException{
        mapa.put(key, value);
//   	try {
//            mapa.put(key, value);
//        } 
//        catch (NullPointerException | IndexOutOfBoundsException e) {
//            System.out.println("Tentou adicionar uma posi��o nula ou inv�lida: " + e.getMessage());
//        } 
//        catch (Exception e) {
//            System.out.println("Ocorreu uma exce��o indeterminada!");
//        }
    }

    @Override
    public Set<K> getChaves() {
        return mapa.keySet();
//   	try {
//            return mapa.keySet();
//        } 
//        catch (NullPointerException | IndexOutOfBoundsException e) {
//            System.out.println("Tentou acessar uma posi��o nula ou inv�lida: " + e.getMessage());
//        } 
//        catch (Exception e) {
//            System.out.println("Ocorreu uma exce��o indeterminada!");
//        }
//        return null;
    }

    @Override
    public V getValor(K key) {
        return mapa.get(key);
//   	try {
//            return mapa.get(key);
//        } 
//        catch (NullPointerException | IndexOutOfBoundsException e) {
//            System.out.println("Tentou acessar uma posi��o nula ou inv�lida: " + e.getMessage());
//        } 
//        catch (Exception e) {
//            System.out.println("Ocorreu uma exce��o indeterminada!");
//        }
//        return null;
    }

    @Override
    public V remover(K key) {
        return mapa.remove(key);
//   	try {
//            return mapa.remove(key);
//        } 
//        catch (NullPointerException | IndexOutOfBoundsException e) {
//            System.out.println("Tentou remover uma posi��o nula ou inv�lida: " + e.getMessage());
//        } 
//        catch (Exception e) {
//            System.out.println("Ocorreu uma exce��o indeterminada!");
//        }
//        return null;
    }

    @Override
    public boolean substituir(K key, V oldValue, V newValue) {
        return mapa.replace(key, oldValue, newValue);
        //throw new NullPointerException();
        
//   	try {
//            return mapa.replace(key, oldValue, newValue);
//        } 
//        catch (NullPointerException | IndexOutOfBoundsException e) {
//            System.out.println("Tentou acessar uma posi��o nula ou inv�lida: " + e.getMessage());
//        } 
//        catch (Exception e) {
//            System.out.println("Ocorreu uma exce��o indeterminada!");
//        }
//        return false;
    }    
    
    @Override
    public String toString(){
        String aux = "";
        Set<K> chaves = mapa.keySet();
        for(K chave: chaves)
            aux += "Chave: " + chave + "\tValor: " + mapa.get(chave) + "\n";
        return aux;
    }
}
