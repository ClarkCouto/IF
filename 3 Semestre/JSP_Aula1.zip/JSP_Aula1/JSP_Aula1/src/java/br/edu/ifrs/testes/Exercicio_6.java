/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifrs.testes;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author 0729159
 */
public class Exercicio_6 {
    public static void main(String[] args){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String query = "select nome, cpf from clientes";
            String urlDB = "jdbc:mysql://localhost:3306/testbd";
            try(Connection con = DriverManager.getConnection(urlDB,"user","user");
                Statement stmt = con.createStatement();){
                
                ResultSet rs = stmt.executeQuery(query);
                while (rs.next()) {
                    String nome = rs.getString("nome");
                    String cpf = rs.getString("cpf");
                    System.out.printf("Nome:%s\t Cpf:%s %n", nome, cpf);
                } 
            }
            catch (SQLException ex) {
                System.out.println("Exceção no SQL. " + ex.getSQLState());
            }
        } 
        catch (ClassNotFoundException ex) {
            System.out.println("Classe não encontrada!");
        }
    } 
}
