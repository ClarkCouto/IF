/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifrs.util;

import java.util.Set;

/**
 *
 * @author 0729159
 */
public class Exercicio_11_Testes_MeuMapa {
    /*
    11) Monte uma classe de testes para a classe MeuMapa após as modificações realizadas na Questão 10. 
    */
    public static void main(String[] args) {
        MeuMapa<Integer, String> mapa = new MeuMapa<>();
        
        System.out.println("Adicionar");
        //Adicionar => void adicionar(K key, V value);
        try{
            mapa.adicionar(1, "Um");
            mapa.adicionar(2, "Dois");
            mapa.adicionar(3, "Três");
            mapa.adicionar(4, "Quatro");
        }
        catch(NullPointerException e){
            System.out.println("Exceção ao Adicionar. Posição Inválida!");
        }
        System.out.println("GetChaves: ");
        //GetChaves => Set getChaves();
        Set<Integer> chaves = mapa.getChaves();
        for(Integer chave : chaves)
              System.out.println(chave);
       
        System.out.print("GetValor: ");
        //GetValor => V getValor(K key);
        try{
            System.out.println(mapa.getValor(2));
        }
        catch(NullPointerException e){
            System.out.println("Exceção ao Buscar. Posição Inválida!");
        }
        
        System.out.print("Remover: ");
        //Remover => V remover(K key);
        System.out.println(mapa.remover(3));
        
        
        System.out.println("GetChaves: ");
        chaves = mapa.getChaves();
        for(Integer chave : chaves)
              System.out.println(chave);
        
        System.out.println("Substituir: ");
        //Substituir => boolean substituir(K key, V oldValue, V newValue);
        try{
            mapa.substituir(4, "Quatro", "Quarenta");
        }
        catch(NullPointerException e){
            System.out.println("Exceção ao Substituir. Posição Inválida!");
        }
        System.out.print("GetValor: ");
        System.out.println(mapa.getValor(4));
    }
}
