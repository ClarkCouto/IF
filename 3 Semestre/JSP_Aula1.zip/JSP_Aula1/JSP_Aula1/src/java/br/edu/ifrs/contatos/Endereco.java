/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifrs.contatos;

import br.edu.ifrs.banco.EnderecoDAO;
import java.util.List;

/**
 *
 * @author 0729159
 */
public class Endereco {
    private String logradouro;
    private String complemento;
    private int idEndereco;

    public Endereco() {}

    public Endereco(String logradouro, String complemento) {
        this(-1, logradouro, complemento);
    }
    public Endereco(int idEndereco, String logradouro, String complemento) {
        this.idEndereco = idEndereco;
        this.logradouro = logradouro;
        this.complemento = complemento;
    }

    public int getIdEndereco() {
        return idEndereco;
    }

    public String getLogradouro() {
        return logradouro;
    }

    public String getComplemento() {
        return complemento;
    }

    public void setIdEndereco(int idEndereco) {
        this.idEndereco = idEndereco;
    }

    public void setLogradouro(String logradouro) {
        this.logradouro = logradouro;
    }

    public void setComplemento(String complemento) {
        this.complemento = complemento;
    }
    
    public void listar(){
        System.out.println(toString());
    }

    @Override
    public String toString() {
        return (idEndereco != -1 ? "\tID: " + idEndereco : "")+ "\n\t\t\tLogradouro: " + logradouro + "\n\t\t\tComplemento: " + complemento;
    }
    
    public int insert() {
        return new EnderecoDAO().insert(this);
    }
    public List<Endereco> listAll(){
        return new EnderecoDAO().listAll();
    }
    public int delete() {
        return new EnderecoDAO().delete(this);
    }
    public int update() {
        return new EnderecoDAO().update(this);
    }
    public Endereco findById(int idEndereco) {
        return new EnderecoDAO().findByID(idEndereco);
    }
}
