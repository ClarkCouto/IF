/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifrs.testes;

import br.edu.ifrs.contatos.Endereco;
import br.edu.ifrs.pessoas.Fornecedor;
import br.edu.ifrs.produtos.ComparatorProduto;
import br.edu.ifrs.produtos.Produto;
import java.util.LinkedList;
import java.util.TreeSet;

/**
 *
 * @author 0729159
 */
public class Exercicio_13 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args){
        /*
        13) Agora, monte uma classe de testes de modo que: 5 objetos sejam adicionados ao TreeSet e
        que o conjunto seja impresso, sem nenhuma chamada explícita a métodos de ordenação. 
        */
        
        ComparatorProduto comparador = new ComparatorProduto();
        TreeSet<Produto> lista = new TreeSet<>(comparador);
        
        LinkedList<Fornecedor> fornecedores = new LinkedList<>();
        fornecedores.add(new Fornecedor("0123456789", "Fornecedor1", "Contato1", new Endereco("Rua x", "apto 1")));
        fornecedores.add(new Fornecedor("9876543210", "Fornecedor2", "Contato2", new Endereco("Rua y", "apto 2")));
        
        System.out.println("Adiciona um produto usando construtor com parâmetros...");
        lista.add(new Produto(020, "Produto 1", 1.5D, fornecedores));
        lista.add(new Produto(456, "Produto 2", 5.5D, fornecedores));
        lista.add(new Produto(123, "Produto 3", 6.5D, fornecedores));
        lista.add(new Produto(789, "Produto 4", 10.5D, fornecedores));
        lista.add(new Produto(001, "Produto 5", 2.5D, fornecedores));
        
        for (Produto p : lista) {
                System.out.println(p.toString() + "\n");
        }
    }
    
}
