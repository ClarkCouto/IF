/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifrs.testes;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author 0729159
 */
public class Exercicio_5 {
    //Certo
    public static void main(String[] args){
        FileReader in = null;
        BufferedReader buff = null;
        try {
            in = new FileReader("teste.txt"); //caminho do arquivo
            buff = new BufferedReader(in, 1024);
            StringBuilder builder = new StringBuilder();
            String s = null;
            while ((s = buff.readLine()) != null) {
                builder.append(s).append("\n");
            }
            System.out.println("Conteudo do arquivo:\n\n"+builder);
        }
        catch (FileNotFoundException ex) {
            System.out.println("Arquivo de leitura não encontrado!");
        } 
        catch (IllegalArgumentException ex) {
            System.out.println("Argumento inválido para arquivo de leitura!");
        }
        catch (IOException ex) {
            System.out.println("Exceção ao escrever arquivo!");
        }
        finally{
            try{
                if(buff != null)
                    buff.close();
                if(in != null)
                    in.close();
            }
            catch (IOException ex) {
                System.out.println("Exceção ao fechar arquivo!");
            }
        }
                

    }
    
    /*
    //Errado
    public static void main(String[] args){
        FileReader in;
        try {
            in = new FileReader("teste.txt"); //caminho do arquivo
            
            BufferedReader buff = new BufferedReader(in, 1024);

            StringBuilder builder = new StringBuilder();
            String s = null;
            try {
                while ((s = buff.readLine()) != null) {
                    builder.append(s).append("\n");
                }
                System.out.println("Conteudo do arquivo:\n\n"+builder);
            } 
            catch (IOException ex) {
                Logger.getLogger(Exercicio_5.class.getName()).log(Level.SEVERE, null, ex);
            }
            finally{
                buff.close();
                in.close(); 
            }
        }
        catch (FileNotFoundException ex) {
            Logger.getLogger(Exercicio_5.class.getName()).log(Level.SEVERE, null, ex);
        } 
        catch (IOException ex) {
            Logger.getLogger(Exercicio_5.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    */
}
