/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifrs.banco;

import br.edu.ifrs.contatos.Endereco;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author CristianoSilva
 */
public class EnderecoDAO implements GenericDAO<Endereco>{

    @Override
    public int insert(Endereco endereco) {
        int chavePrimaria = -1;
        
        try (Connection connection = new ConnectionFactory().getConnection();
                PreparedStatement stmt = connection.prepareStatement(EnderecoSQLs.INSERT.getSql(),
                        Statement.RETURN_GENERATED_KEYS)) {
            System.out.println("Conexão Insert Endereco aberta!");
            stmt.setString(1, endereco.getLogradouro());
            stmt.setString(2, endereco.getComplemento());
            stmt.execute();
            
            System.out.println("Dados do Endereco gravados com Sucesso!");
            ResultSet chaves = stmt.getGeneratedKeys();
            if (chaves.next()) {
                chavePrimaria = chaves.getInt(1);
            }
        } 
        catch (SQLException e) {
            System.out.println("exceção com recursos em insert Endereco");
        } 
        catch (ClassNotFoundException e) {
            System.out.println("Classe não encontrada insert Endereco!");
        }
        return chavePrimaria;
    }

@Override
    public List<Endereco> listAll() {
        List<Endereco> lista = new LinkedList<>();

        try (Connection connection = new ConnectionFactory().getConnection();
            PreparedStatement stmt = connection.prepareStatement(EnderecoSQLs.LISTALL.getSql())) {

            JOptionPane.showMessageDialog(null,"connected with "+connection.toString());
            System.out.println("Conexão listAll Endereco aberta!");
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int idEndereco = rs.getInt("idEndereco");
                String logradouro = rs.getString("logradouro");
                String complemento = rs.getString("complemento");
                lista.add(new Endereco(idEndereco, logradouro, complemento));
            }
            return lista;
        } 
        catch (SQLException e) {
            System.out.println("Exceção SQL em listAll Endereco");
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada listAll Endereco!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código em listAll Endereco!");
        }
        return null;
    }

    @Override
    public int delete(Endereco endereco) {
        try (Connection connection = new ConnectionFactory().getConnection();
                PreparedStatement stmt = connection.prepareStatement(EnderecoSQLs.DELETE.getSql())) {
            System.out.println("Conexão Delete Endereco aberta!");
            stmt.setInt(1, endereco.getIdEndereco());
            return stmt.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println("Exceção SQL em Delete Endereco");
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada em Delete Endereco!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código em Delete Endereco!");
        }
        return 0;
    }

    @Override
    public int update(Endereco endereco) {
        try (Connection connection = new ConnectionFactory().getConnection();
                PreparedStatement stmt = connection.prepareStatement(EnderecoSQLs.UPDATE.getSql())) {
            System.out.println("\nConexão Update Endereco aberta!");
            System.out.println("Dados atualizados " + endereco.toString());
            stmt.setString(1, endereco.getLogradouro());
            stmt.setString(2, endereco.getComplemento());
            stmt.setInt(3, endereco.getIdEndereco());
            return stmt.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println("Exceção SQL em Update Endereco" + e.getMessage());
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada em Update Endereco!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código em Update Endereco!");
        }
        return 0;
    }

    @Override
    public Endereco findByID(int id) {
        try (Connection connection = new ConnectionFactory().getConnection();
            PreparedStatement stmt = connection.prepareStatement(EnderecoSQLs.FINDBYID.getSql())) {

            System.out.println("Conexão FindById Endereco aberta!");
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int idEndereco = rs.getInt("idEndereco");
                String logradouro = rs.getString("logradouro");
                String complemento = rs.getString("complemento");
                Endereco endereco = new Endereco(idEndereco, logradouro, complemento);
                return endereco;
            }
        } 
        catch (SQLException e) {
            System.out.println("Exceção SQL em FindById Endereco" + e.getMessage());
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada em FindById Endereco!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código em FindById Endereco!");
        }
        return null;
    }
}

