/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 0729159
 */
public class Tabuada {
    public static List<String> imprimeTabuada(int numero) {
        List<String> minhaLista = new ArrayList<>();
        for (int i = 1; i <= 10; i++) {
            minhaLista.add(numero + " X " + i + " = " + numero * i);
        }
        return minhaLista;
    }
}
