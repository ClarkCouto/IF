/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testes;

import classes.Cpf;
import dao.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author 0729159
 */
public class TesteCpf {
    public static void main(String[] args) {
        
        LinkedList<Cpf> lista = new LinkedList<>();
        lista.add(new Cpf(15988250, 89));
        lista.add(new Cpf(987654321, 01));
        
        LinkedList<Integer> chavesPrimarias = new LinkedList<>();
        try(Connection connection = new ConnectionFactory().getConnection();
            PreparedStatement stmt = connection.prepareStatement(
                "insert into cpf (numero, digito) values (?, ?)", Statement.RETURN_GENERATED_KEYS)){
        
            System.out.println("Conexão aberta!");
            for(Cpf cpf : lista){
                stmt.setLong(1, cpf.getNumero());
                stmt.setInt(2, cpf.getDigito());
                stmt.executeUpdate();
                ResultSet chaves = stmt.getGeneratedKeys();
                if (chaves.next())
                    chavesPrimarias.add(chaves.getInt(1));
            }
            
            System.out.println("Chaves criadas:");
            for(Integer c : chavesPrimarias)
                System.out.println("Chave: " + c.toString());
            
        } 
        catch (SQLException ex) {
            Logger.getLogger(TesteCpf.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        LinkedList<Cpf> listaRetorno = new LinkedList<>();
        try(Connection connection = new ConnectionFactory().getConnection();){
        
            System.out.println("\nDados que foram inseridos:");
             String sql = "Select * from cpf";
            //Cria o statement que aponta para o Banco
            Statement stmt = connection.createStatement();
            //Executa a query e monta a tabela com os resultados
            ResultSet rs = stmt.executeQuery(sql);
            //Aponta para a primeira linha e enquanto houverem dados no retorno da execução da query, executa
            
            while(rs.next()){
                int idCpf = rs.getInt("idCpf");
                long numero = rs.getLong("numero");
                int digito = rs.getInt("digito");
                
                listaRetorno.add(new Cpf(numero, digito));
            }   
        
            for(Cpf cpf : listaRetorno)
                System.out.println(cpf.toString());
        } catch (SQLException ex) {
            Logger.getLogger(TesteCpf.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
