/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testes;
import java.sql.*;

/**
 *
 * @author Silvia Bertagnolli
 */
public class Exemplo1{
   public static void main(String[] args){ 
       try {
           Class.forName("com.mysql.jdbc.Driver");
       } 
       catch (ClassNotFoundException ex) {
           System.out.println("Driver não encontrado!");
           //Logger.getLogger(Exemplo1.class.getName()).log(Level.SEVERE, null, ex);
       }
       String urlBD="jdbc:mysql://localhost:3306/AulaJDBC";
               
       try (Connection conexao = DriverManager.getConnection(urlBD, "root", "");){
            System.out.println("Conectou!"); 
       } 
       catch (SQLException ex) {
           System.out.println("Não conseguiu conectar com o BD!");
           //Logger.getLogger(Exemplo1.class.getName()).log(Level.SEVERE, null, ex);
       }
   }
}

