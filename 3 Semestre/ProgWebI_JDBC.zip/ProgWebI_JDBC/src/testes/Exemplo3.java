/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testes;

import dao.ConnectionFactory;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Silvia
 */
public class Exemplo3 {
    /*
    public static void main(String[] args) throws SQLException, ClassNotFoundException{
        //Estabelece a conexão com o BD
        Connection connection = new ConnectionFactory().getConnection();
        System.out.println("Conexão aberta!");
        
        //Monta a consulta que deverá ser executado
        String sql = "Select * from pessoa";
        
        //Cria o statement que aponta para o Banco
        Statement stmt = connection.createStatement();
        
        //Executa a query e monta a tabela com os resultados
        ResultSet rs = stmt.executeQuery(sql);
        
        //Aponta para a primeira linha e enquanto houverem dados no retorno da execução da query, executa
        while(rs.next()){
            //Busca as informações das colunas e imprime
            //int idPessoa = rs.getInt("idpessoa");
            //String nome = rs.getString("nome");
            //String endereco = rs.getString("endereco");
            
            //Exercício 10
            int idPessoa = rs.getInt(1);
            String nome = rs.getString(2);
            String endereco = rs.getString(3);
            System.out.println("\nDados = " + idPessoa + " " + nome + " " + endereco);
            
            //Exercício 11
            String name = rs.getString("nome");
            System.out.println("\nDados = " + name);
        }      
    }
    */
    
    public static void main(String[] args){
        //Estabelece a conexão com o BD
        try (Connection connection = new ConnectionFactory().getConnection()) {
            System.out.println("Conexão aberta!\n");
            //Monta a consulta que deverá ser executado
            String sql = "Select nome from pessoa";
            //Cria o statement que aponta para o Banco
            Statement stmt = connection.createStatement();
            //Executa a query e monta a tabela com os resultados
            ResultSet rs = stmt.executeQuery(sql);
            //Aponta para a primeira linha e enquanto houverem dados no retorno da execução da query, executa
            while (rs.next()) {
                //Exercício 11
                String name = rs.getString("nome");
                System.out.println("Dados = " + name);
            }
        } 
        catch (SQLException ex) {
            System.out.println("Erro de conexão com o BD!");
        }
    }
}
