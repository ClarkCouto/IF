/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testes;

import classes.Endereco;
import dao.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author 0729159
 */
public class TesteEndereco{
    public static void main(String[] args) {
        
        LinkedList<Endereco> lista = new LinkedList<>();
        lista.add(new Endereco(-1, "Rua A", "1", "RS"));
        lista.add(new Endereco(-1, "Rua B", "2", "SC"));
        lista.add(new Endereco(-1, "Rua C", "3", "PR"));
        lista.add(new Endereco(-1, "Rua D", "4", "SP"));
        
        LinkedList<Integer> chavesPrimarias = new LinkedList<>();
        try(Connection connection = new ConnectionFactory().getConnection();
            PreparedStatement stmt = connection.prepareStatement(
                "insert into endereco (logradouro, complemento, uf) values (?, ?, ?)", Statement.RETURN_GENERATED_KEYS)){
        
            System.out.println("Conexão aberta!");
            for(Endereco e : lista){
                stmt.setString(1, e.getLogradouro());
                stmt.setString(2, e.getComplemento());
                stmt.setString(3, e.getUF());
                stmt.executeUpdate();
                ResultSet chaves = stmt.getGeneratedKeys();
                if (chaves.next())
                    chavesPrimarias.add(chaves.getInt(1));
            }
            
            System.out.println("Últimas chaves criadas:");
            for(Integer c : chavesPrimarias)
                System.out.println("Chave: " + c.toString());
            
        } 
        catch (SQLException ex) {
            Logger.getLogger(TesteEndereco.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        LinkedList<Endereco> listaRetorno = new LinkedList<>();
        try(Connection connection = new ConnectionFactory().getConnection();){
        
            System.out.println("\nDados já inseridos:");
             String sql = "Select * from endereco";
            //Cria o statement que aponta para o Banco
            Statement stmt = connection.createStatement();
            //Executa a query e monta a tabela com os resultados
            ResultSet rs = stmt.executeQuery(sql);
            //Aponta para a primeira linha e enquanto houverem dados no retorno da execução da query, executa
            
            while(rs.next()){
                int idEndereco = rs.getInt("idEndereco");
                String logradouro = rs.getString("logradouro");
                String complemento = rs.getString("complemento");
                String uf = rs.getString("uf");
                
                listaRetorno.add(new Endereco(idEndereco, logradouro, complemento, uf));
            }   
        
            for(Endereco e : listaRetorno)
                System.out.println(e.toString());
        } catch (SQLException ex) {
            Logger.getLogger(TesteEndereco.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
