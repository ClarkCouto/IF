/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import classes.Endereco;
import java.sql.*;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author silviacb
 */
public class EnderecoDAO implements GenericDAO<Endereco>{
    @Override
    public int insert(Endereco e) {
        int chavePrimaria = -1;
        try(Connection connection = new ConnectionFactory().getConnection();
            PreparedStatement stmt = connection.prepareStatement(
                "insert into endereco (logradouro, complemento, uf) values (?, ?, ?)", Statement.RETURN_GENERATED_KEYS)){
        
            System.out.println("Conexão aberta!");
            stmt.setString(1, e.getLogradouro());
            stmt.setString(2,e.getComplemento());
            stmt.setString(3, e.getUF());
            stmt.execute();
            System.out.println("Dados Gravados!");
            ResultSet chaves = stmt.getGeneratedKeys();
            if (chaves.next())
                chavePrimaria = chaves.getInt(1);
        }
        catch(SQLException ex){
            System.out.println("exceção com recursos");
        }
        return chavePrimaria;
       
    }
    @Override
    public  List<Endereco> listAll() {
        List<Endereco> lista = new LinkedList<>();
        
        try(Connection connection = new ConnectionFactory().getConnection();
            PreparedStatement stmt = connection.prepareStatement(PessoaSQLs.LISTALL.getSql())){
            
            System.out.println("Conexão aberta!");
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                int idEndereco = rs.getInt("idEndereco");
                String logradouro = rs.getString("logradouro");
                String complemento = rs.getString("complemento");
                String uf = rs.getString("uf");
                lista.add(new Endereco(idEndereco, logradouro, complemento, uf));
            }
            return lista;
        }
        catch(SQLException ex){ 
            System.out.println("Exceção SQL");
        }
        catch(Exception ex){
            System.out.println("Exceção no código!");
        }
        return null;
    }
}
