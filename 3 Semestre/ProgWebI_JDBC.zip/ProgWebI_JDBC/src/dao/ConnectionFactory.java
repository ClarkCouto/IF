package dao;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author silviacb
 */
public class ConnectionFactory {
    public Connection getConnection(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            
            String urlBD="jdbc:mysql://localhost:3306/AulaJDBC";
            try {
                return DriverManager.getConnection(urlBD, "root", "");
            } 
            catch (SQLException ex) {
                System.out.println("Não conseguiu conectar com o BD!");
            }
        } 
        catch (ClassNotFoundException ex) {
           System.out.println("Driver não encontrado!");
        }
        return null;
    }
}
