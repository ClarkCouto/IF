/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testes;

import classes.Pessoa;
import dao.PessoaDAO;
import java.sql.SQLException;
import java.util.LinkedList;

/**
 *
 * @author silviacb
 */
public class Exercicio17 {
    public static void main(String[] args) throws SQLException{ 
        /*
        LinkedList<Pessoa> pessoas = new LinkedList<>();
        Pessoa p = new Pessoa();
        pessoas.addAll(p.listAll());
        p = pessoas.getFirst();
        
        System.out.println("Pessoas cadastradas (" + pessoas.size() + "):");
        for(Pessoa pessoa : pessoas)
            System.out.println(pessoa.toString());
        
        System.out.println("\nPessoa a ser excluída: " + p.toString());
        System.out.println("\nQuantidade de pessoas excluídas: " + p.delete());
        
        pessoas.clear();
        pessoas.addAll(p.listAll());
        
        System.out.println("\nPessoas que sobraram (" + pessoas.size() + "):");
        for(Pessoa pessoa : pessoas)
            System.out.println(pessoa.toString());
        */
        Pessoa p = new Pessoa();
        p = p.findById(8);
        p.setNome("Cris");
        p.setEndereco("Adão Baino, 701");
        System.out.println("\nLinhas atualizadas: " + p.update());
        
        LinkedList<Pessoa> pessoas = new LinkedList<>();
        pessoas.addAll(p.listAll());
        
        System.out.println("\nPessoas cadastradas (" + pessoas.size() + "):");
        for(Pessoa pessoa : pessoas)
            System.out.println(pessoa.toString());
        
    }
}

