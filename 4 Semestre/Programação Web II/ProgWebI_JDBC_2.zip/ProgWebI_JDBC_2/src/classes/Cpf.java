/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import dao.CpfDAO;
import java.util.List;

/**
 *
 * @author Silvia
 */
public class Cpf {
    private int idCpf;
    private long numero;
    private int digito;

    public Cpf() {}

    public Cpf(long numero, int digito) {
        this(-1, numero, digito);
    }
    
    public Cpf(int idCpf, long numero, int digito) {
        this.idCpf = idCpf;
        this.numero = numero;
        this.digito = digito;
    }

    public int getIdCpf() {
        return idCpf;
    }

    public long getNumero() {
        return numero;
    }

    public int getDigito() {
        return digito;
    }

    public void setIdCpf(int idCpf) {
        this.idCpf = idCpf;
    }

    public void setNumero(long numero) {
        this.numero = numero;
    }

    public void setDigito(int digito) {
        this.digito = digito;
    }

    @Override
    public String toString() {
        return "CPF: " + numero + "-" + digito;
    }
    
    
    public int insert() {
        return new CpfDAO().insert(this);
    }
    public List<Cpf> listAll(){
        return new CpfDAO().listAll();
    }
    public int delete() {
        return new CpfDAO().delete(this);
    }
    public int update() {
        return new CpfDAO().update(this);
    }
    public Cpf findById(int idCpf) {
        return new CpfDAO().findByID(idCpf);
    }
}
