/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import dao.EnderecoDAO;
import java.util.List;

/**
 *
 * @author Silvia
 */
public class Endereco {
    private int idEndereco;
    private String logradouro;
    private String complemento;
    private String uf;

    public Endereco(){}
    public Endereco(String logradouro, String complemento, String uf) {
        this(-1, logradouro, complemento, uf);
    }
    public Endereco(int idEndereco, String logradouro, String complemento, String uf) {
        this.idEndereco = idEndereco;
        this.logradouro = logradouro;
        this.complemento = complemento;
        this.uf = uf;
    }

    public int getIdEndereco() {
        return idEndereco;
    }

    public void setIdEndereco(int idEndereco) {
        this.idEndereco = idEndereco;
    }

    public String getLogradouro() {
        return logradouro;
    }

    public void setLogradouro(String logradouro) {
        this.logradouro = logradouro;
    }

    public String getComplemento() {
        return complemento;
    }

    public void setComplemento(String complemento) {
        this.complemento = complemento;
    }

    public String getUf() {
        return uf;
    }

    public void setUf(String uf) {
        this.uf = uf;
    }

    @Override
    public String toString() {
        return "Logradouro: " + logradouro + "\tComplemento: " + complemento + "\tUF: " + uf;
    }
    
    public int insert() {
        return new EnderecoDAO().insert(this);
    }
    public List<Endereco> listAll(){
        return new EnderecoDAO().listAll();
    }
    public int delete() {
        return new EnderecoDAO().delete(this);
    }
    public int update() {
        return new EnderecoDAO().update(this);
    }
    public Endereco findById(int idEndereco) {
        return new EnderecoDAO().findByID(idEndereco);
    }
    
}
