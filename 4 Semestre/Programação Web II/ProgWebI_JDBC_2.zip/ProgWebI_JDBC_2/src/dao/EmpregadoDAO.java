/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import classes.Cpf;
import classes.Empregado;
import java.sql.*;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author silviacb
 */
public class EmpregadoDAO implements GenericDAO<Empregado>{

    @Override
    public int insert(Empregado empregado) {
        int chavePrimaria = -1;
        int idCpf = new CpfDAO().insert(empregado.getCpf());
        
        try (Connection connection = new ConnectionFactory().getConnection();
                PreparedStatement stmt = connection.prepareStatement(EmpregadoSQLs.INSERT.getSql(),
                        Statement.RETURN_GENERATED_KEYS)) {
            System.out.println("Conexão insert aberta!");
            stmt.setString(1, empregado.getNome());
            stmt.setString(2, empregado.getEndereco());
            stmt.setString(3, empregado.getTelefone());
            stmt.setInt(4, idCpf); 
            
            stmt.execute();
            
            System.out.println("Dados do Empregado Gravados!");
            ResultSet chaves = stmt.getGeneratedKeys();
            if (chaves.next()) {
                chavePrimaria = chaves.getInt(1);
            }
        } 
        catch (SQLException e) {
            System.out.println("exceção com recursos");
        } 
        catch (ClassNotFoundException e) {
            System.out.println("Classe não encontrada!");
        }
        return chavePrimaria;
    }

@Override
    public List<Empregado> listAll() {
        List<Empregado> lista = new LinkedList<>();

        try (Connection connection = new ConnectionFactory().getConnection();
            PreparedStatement stmt = connection.prepareStatement(EmpregadoSQLs.LISTALL.getSql())) {

            System.out.println("Conexão listAll aberta!");
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int idEmpregado = rs.getInt("idEmpregado");
                String nome = rs.getString("nome");
                String endereco = rs.getString("endereco");
                String telefone = rs.getString("telefone");
                int idCpf = rs.getInt("idCpf");
                lista.add(new Empregado(idEmpregado, nome, endereco, telefone, new Cpf().findById(idCpf)));
            }
            return lista;
        } 
        catch (SQLException e) {
            System.out.println("Exceção SQL");
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código!");
        }
        return null;
    }

    @Override
    public int delete(Empregado empregado) {
        try (Connection connection = new ConnectionFactory().getConnection();
                PreparedStatement stmt = connection.prepareStatement(EmpregadoSQLs.DELETE.getSql())) {
            System.out.println("Conexão delete aberta!");
            stmt.setInt(1, empregado.getIdEmpregado());
            return stmt.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println("Exceção SQL");
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código!");
        }
        return 0;
    }

    @Override
    public int update(Empregado empregado) {
        try (Connection connection = new ConnectionFactory().getConnection();
                PreparedStatement stmt = connection.prepareStatement(EmpregadoSQLs.UPDATE.getSql())) {
            System.out.println("\nConexão Update aberta!");
            System.out.println("Dados atualizados " + empregado.toString());
            stmt.setString(1, empregado.getNome());
            stmt.setString(2, empregado.getEndereco());
            stmt.setString(3, empregado.getTelefone());
            stmt.setInt(3, empregado.getCpf().getIdCpf());
            return stmt.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println("Exceção SQL" + e.getMessage());
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código!");
        }
        return 0;
    }

    @Override
    public Empregado findByID(int id) {
        try (Connection connection = new ConnectionFactory().getConnection();
            PreparedStatement stmt = connection.prepareStatement(EmpregadoSQLs.FINDBYID.getSql())) {

            System.out.println("Conexão FindById aberta!");
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int idEmpregado = rs.getInt("idEmpregado");
                String nome = rs.getString("nome");
                String endereco = rs.getString("endereco");
                String telefone = rs.getString("telefone");
                int idCpf = rs.getInt("cpf");
                Empregado empregado = new Empregado(idEmpregado, nome, endereco, telefone, new Cpf().findById(idCpf));
                System.out.println("Empregado encontrado: " + empregado.toString());
                return empregado;
                //return new Empregado(idEmpregado, nome, endereco, telefone, new Cpf().findById(idCpf));
            }
        } 
        catch (SQLException e) {
            System.out.println("Exceção SQL" + e.getMessage());
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Classe/Tabela não encontrada!");
        }
        catch (Exception e) {
            System.out.println("Exceção no código!");
        }
        return null;
    }
}
