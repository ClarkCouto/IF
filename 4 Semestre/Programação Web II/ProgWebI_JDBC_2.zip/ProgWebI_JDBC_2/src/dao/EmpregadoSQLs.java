/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

/**
 *
 * @author 
 */
public enum EmpregadoSQLs {
    INSERT("insert into empregado(nome, endereco, telefone, idCpf) values (?, ?, ?, ?)"), 
    UPDATE("update empregado set nome = ?, endereco = ?, telefone = ?, idCpf = ? where idEmpregado = ?"), 
    FINDBYID("select * from empregado where idEmpregado = ?"), 
    DELETE("delete from empregado where idEmpregado = ?"), 
    LISTALL("select * from empregado");
    
    private final String sql;
    EmpregadoSQLs(String sql){
        this.sql = sql; 
    }

    public String getSql() {
        return sql;
    }    
}

