/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

/**
 *
 * @author CristianoSilva
 */
@Entity
public class Edital implements Serializable{
    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue
    @Column(nullable=false, unique=true)
    private long idEdital;
    
    @Column(nullable=false, unique=true)
    private String titulo;
    
    @Column(nullable=false, unique=true)
    private String numero;
    
    @Column(nullable=false, unique=true)
    private String origem;
    
//    @OneToOne(mappedBy="idEdital")
//    private Agenda agenda;
    
    @Column(nullable=false, unique=true)
    private String pdf;
    
    @Column(nullable=false, unique=true)
    private boolean ativo;
    
//    @OneToMany(mappedBy="idEdital")
//    private List<Bolsa> bolsas;
//    
//    @OneToMany(mappedBy="idEdital")
//    private List<Projeto> projetos;
    
    public Edital() {
    }

    public Edital(long idEdital, String titulo, String numero, String origem, Agenda agenda, String pdf, boolean ativo) {
        this.idEdital = idEdital;
        this.titulo = titulo;
        this.numero = numero;
        this.origem = origem;
//        this.agenda = agenda;
        this.pdf = pdf;
        this.ativo = ativo;
    }

    public long getIdEdital() {
        return idEdital;
    }

    public void setIdEdital(long idEdital) {
        this.idEdital = idEdital;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getOrigem() {
        return origem;
    }

    public void setOrigem(String origem) {
        this.origem = origem;
    }

//    public Agenda getAgenda() {
//        return agenda;
//    }
//
//    public void setAgenda(Agenda agenda) {
//        this.agenda = agenda;
//    }

    public String getPdf() {
        return pdf;
    }

    public void setPdf(String pdf) {
        this.pdf = pdf;
    }

    public boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }

}
