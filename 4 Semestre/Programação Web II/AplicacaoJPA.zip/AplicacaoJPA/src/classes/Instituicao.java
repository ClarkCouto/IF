/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

/**
 *
 * @author CristianoSilva
 */
@Embeddable
public class Instituicao implements Serializable{
    private static final long serialVersionUID = 1L;
    
//    @Id
//    @GeneratedValue
//    @Column(nullable=false, unique=true)
//    private int idInstituicao;
    
    @Column(nullable=false, unique=true)
    private String nome;
    
    @Column(nullable=false, unique=true)
    private boolean ativo;
    
//    @OneToMany(mappedBy="instituicao")
//    //@OrderBy("dataLimiteEntrega")
//    private Collection<Pessoa> pessoas;

    public Instituicao() {
    }

    public Instituicao(String nome, boolean ativo) {
        this.nome = nome;
        this.ativo = ativo;
    }

//    public Instituicao(int idInstituicao, String nome, boolean ativo) {
//        this.idInstituicao = idInstituicao;
//        this.nome = nome;
//        this.ativo = ativo;
//    }
//
//    public int getIdInstituicao() {
//        return idInstituicao;
//    }
//
//    public void setIdInstituicao(int idInstituicao) {
//        this.idInstituicao = idInstituicao;
//    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }

}
