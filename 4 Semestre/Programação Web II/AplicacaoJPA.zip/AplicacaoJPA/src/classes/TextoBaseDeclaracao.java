/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author CristianoSilva
 */
@Entity
public class TextoBaseDeclaracao implements Serializable{
    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(nullable=false, unique=true)
    private int idTextoBaseDeclaracao;
    
    @Column(nullable=false, unique=true)
    private String identificador;
    
    @Column(nullable=false, unique=true)
    private String texto;
    
    @Column(nullable=false, unique=true)
    private boolean ativo;
    
    @Column(nullable=false, unique=false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataCadastro;
    
    @Column(nullable=true, unique=false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataDesativacao;

    public TextoBaseDeclaracao() {
    }

    public TextoBaseDeclaracao(int idTextoBaseDeclaracao, String identificador, String texto, boolean ativo, Date dataCadastro, Date dataDesativacao) {
        this.idTextoBaseDeclaracao = idTextoBaseDeclaracao;
        this.identificador = identificador;
        this.texto = texto;
        this.ativo = ativo;
        this.dataCadastro = dataCadastro;
        this.dataDesativacao = dataDesativacao;
    }

    public int getIdTextoBaseDeclaracao() {
        return idTextoBaseDeclaracao;
    }

    public void setIdTextoBaseDeclaracao(int idTextoBaseDeclaracao) {
        this.idTextoBaseDeclaracao = idTextoBaseDeclaracao;
    }

    public String getIdentificador() {
        return identificador;
    }

    public void setIdentificador(String identificador) {
        this.identificador = identificador;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    public boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }

    public Date getDataCadastro() {
        return dataCadastro;
    }

    public void setDataCadastro(Date dataCadastro) {
        this.dataCadastro = dataCadastro;
    }

    public Date getDataDesativacao() {
        return dataDesativacao;
    }

    public void setDataDesativacao(Date dataDesativacao) {
        this.dataDesativacao = dataDesativacao;
    }
    
}
