/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author CristianoSilva
 */
@Entity
public class Documento implements Serializable{
    @Id
    @GeneratedValue
    @Column(nullable=false, unique=true)
    private long idDocumento;
    
    @Column(nullable=false, unique=false)
    private boolean entregue;
    
    @Column(nullable=false, unique=false)
    private boolean ativo;
    
    @Column(nullable=true, unique=false)
    private String anexo;
    
    @Embedded
    @ManyToOne
    private TipoDocumento tipoDocumento;
    
    @ManyToOne
    private Projeto projeto;
    
//    @ManyToOne
//    private DataLimiteEntrega dataLimiteEntrega;
    
    @Column
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataEntregue;

    public Documento() {
    }

    public Documento(long idDocumento, boolean entregue, boolean ativo, String anexo, TipoDocumento tipoDocumento, Projeto projeto, DataLimiteEntrega dataLimiteEntrega, Date dataEntregue) {
        this.idDocumento = idDocumento;
        this.entregue = entregue;
        this.ativo = ativo;
        this.anexo = anexo;
        this.tipoDocumento = tipoDocumento;
        this.projeto = projeto;
//        this.dataLimiteEntrega = dataLimiteEntrega;
        this.dataEntregue = dataEntregue;
    }

    public long getIdDocumento() {
        return idDocumento;
    }

    public void setIdDocumento(long idDocumento) {
        this.idDocumento = idDocumento;
    }

    public boolean isEntregue() {
        return entregue;
    }

    public void setEntregue(boolean entregue) {
        this.entregue = entregue;
    }

    public boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }

    public String getAnexo() {
        return anexo;
    }

    public void setAnexo(String anexo) {
        this.anexo = anexo;
    }

    public TipoDocumento getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(TipoDocumento tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public Projeto getProjeto() {
        return projeto;
    }

    public void setProjeto(Projeto projeto) {
        this.projeto = projeto;
    }

//    public DataLimiteEntrega getDataLimiteEntrega() {
//        return dataLimiteEntrega;
//    }
//
//    public void setDataLimiteEntrega(DataLimiteEntrega dataLimiteEntrega) {
//        this.dataLimiteEntrega = dataLimiteEntrega;
//    }

    public Date getDataEntregue() {
        return dataEntregue;
    }

    public void setDataEntregue(Date dataEntregue) {
        this.dataEntregue = dataEntregue;
    }
   
}
