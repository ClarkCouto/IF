/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

/**
 *
 * @author CristianoSilva
 */
@Entity
@DiscriminatorColumn(name = "tipo")
@DiscriminatorValue(value="setorDePesquisa")
public class SetorDePesquisa extends Usuario implements Serializable{
    private static final long serialVersionUID = 1L;

    public SetorDePesquisa() {
    }

    public SetorDePesquisa(String senha, Date ultimoAcesso, long idPessoa, String nome, Sexo sexo, long cpf, String email, String telefoneFixo, String telefoneCelular, Instituicao instituicao, boolean ativo) {
        super(senha, ultimoAcesso, idPessoa, nome, sexo, cpf, email, telefoneFixo, telefoneCelular, instituicao, ativo);
    }
    
    
}
