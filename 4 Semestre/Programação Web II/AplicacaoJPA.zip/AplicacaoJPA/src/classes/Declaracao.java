/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author CristianoSilva
 */
@Entity
public class Declaracao implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(nullable=false, unique=true)
    private long idDeclaracao;
    
    @Column(nullable=false, unique=false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataEmissao;
    
    @ManyToOne
    private TextoBaseDeclaracao textoBaseDeclaracao;
    
//    @ManyToOne
//    private Coordenador responsavel;
    
    @ManyToOne
    private Projeto projeto;
    
    @Column(nullable=false, unique=true)
    private boolean ativo;

    public Declaracao() {
    }

    public Declaracao(long idDeclaracao, Date dataEmissao, TextoBaseDeclaracao textoBaseDeclaracao, Coordenador responsavel, Projeto projeto, boolean ativo) {
        this.idDeclaracao = idDeclaracao;
        this.dataEmissao = dataEmissao;
        this.textoBaseDeclaracao = textoBaseDeclaracao;
//        this.responsavel = responsavel;
        this.projeto = projeto;
        this.ativo = ativo;
    }

    public long getIdDeclaracao() {
        return idDeclaracao;
    }

    public void setIdDeclaracao(long idDeclaracao) {
        this.idDeclaracao = idDeclaracao;
    }

    public Date getDataEmissao() {
        return dataEmissao;
    }

    public void setDataEmissao(Date dataEmissao) {
        this.dataEmissao = dataEmissao;
    }

    public TextoBaseDeclaracao getTextoBaseDeclaracao() {
        return textoBaseDeclaracao;
    }

    public void setTextoBaseDeclaracao(TextoBaseDeclaracao textoBaseDeclaracao) {
        this.textoBaseDeclaracao = textoBaseDeclaracao;
    }

//    public Coordenador getResponsavel() {
//        return responsavel;
//    }
//
//    public void setResponsavel(Coordenador responsavel) {
//        this.responsavel = responsavel;
//    }

    public Projeto getProjeto() {
        return projeto;
    }

    public void setProjeto(Projeto projeto) {
        this.projeto = projeto;
    }

    public boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }
    
}
