/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

/**
 *
 * @author CristianoSilva
 */
@Embeddable
public class Area implements Serializable{
    private static final long serialVersionUID = 1L;
    
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    @Column(nullable=false, unique=true)
//    private int idArea;
    
    @Column(nullable=false, unique=true)
    private String nome;
    
    @Column(nullable=false, unique=true)
    private boolean ativo;
    
//    @ManyToOne
//    @JoinColumn("idCoordenador")
//    private Coordenador coordenador;

    public Area() {
    }

    public Area(String nome, boolean ativo, Coordenador coordenador) {
        this.nome = nome;
        this.ativo = ativo;
//        this.coordenador = coordenador;
    }

//    public Area(int idArea, String nome, boolean ativo, Coordenador coordenador) {
//        this.idArea = idArea;
//        this.nome = nome;
//        this.ativo = ativo;
//        this.coordenador = coordenador;
//    }
//
//    public int getIdArea() {
//        return idArea;
//    }
//
//    public void setIdArea(int idArea) {
//        this.idArea = idArea;
//    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }

//    public Coordenador getCoordenador() {
//        return coordenador;
//    }
//
//    public void setCoordenador(Coordenador coordenador) {
//        this.coordenador = coordenador;
//    }
//   
}
