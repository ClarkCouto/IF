package classes;

import dao.UsuarioDAO;
import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;


public class Usuario implements Serializable{
    private static final long serialVersionUID = 7371518231621030644L;
    private String nome;
    private String identificador;
    private String senha;

    public Usuario(){}
    public Usuario(String nome, String identificador) {
        this.nome = nome;
        this.identificador = identificador;
    }

    public Usuario(String nome, String identificador, String senha) {
        this.nome = nome;
        this.identificador = identificador;
        this.senha = senha;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getIdentificador() {
        return identificador;
    }

    public void setIdentificador(String identificador) {
        this.identificador = identificador;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    @Override
    public String toString() {
        return "Usuario{" + "nome=" + nome + ", identificador=" + identificador + '}';
    }

    public List<Usuario> listar(){
        List<Usuario> lista = new LinkedList<>();
        lista.add(new Usuario("Angelo da Silva", "asilva"));
        lista.add(new Usuario("Mariana da Silva", "msilva"));
        lista.add(new Usuario("José Costa", "fcosta"));
        lista.add(new Usuario("Agnes Silveira", "asilveira"));
        lista.add(new Usuario("Pedro Gomes", "pgomes"));
        lista.add(new Usuario("Marcela Ramos", "mramos"));
        return lista;
    }
  
    public boolean validar() {
        return UsuarioDAO.validar(this);
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 53 * hash + Objects.hashCode(this.nome);
        hash = 53 * hash + Objects.hashCode(this.identificador);
        hash = 53 * hash + Objects.hashCode(this.senha);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Usuario other = (Usuario) obj;
        if (!Objects.equals(this.nome, other.nome)) {
            return false;
        }
        if (!Objects.equals(this.identificador, other.identificador)) {
            return false;
        }
        if (!Objects.equals(this.senha, other.senha)) {
            return false;
        }
        return true;
    }
    
    
}
