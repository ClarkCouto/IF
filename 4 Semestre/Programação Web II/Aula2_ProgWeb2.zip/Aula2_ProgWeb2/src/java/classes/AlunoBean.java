/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import dao.AlunoDAO;
import java.io.Serializable;
import java.util.LinkedList;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.bean.ViewScoped;


@ManagedBean
@SessionScoped
public class AlunoBean implements Serializable{
    private Aluno aluno = new Aluno();
    private LinkedList<String> ufs;
    private LinkedList<String> cidades;
    private LinkedList<Aluno> alunos;
    private boolean editando;
    
    public Aluno getAluno() {
        return aluno;
    }

    public void setAluno(Aluno aluno) {
        this.aluno = aluno;
    }

    public LinkedList<String> getUFs() {
        if(ufs == null)
           return aluno.getUFs();
        return ufs; 
    }
    public LinkedList<String> getCidades() {
       if(cidades==null)
              this.cidades = new LinkedList<>();
        return cidades;
    
    }
    
    public LinkedList<Aluno> getAlunosLocal() {
       if(alunos==null)
              this.alunos = new LinkedList<>();
        return alunos;
    
    }
    
    public String salvarLocal(){
        alunos.add(new Aluno(aluno.getNome(), aluno.getCpf(), aluno.getMatricula(), aluno.getTelefone(), aluno.getEstado(), aluno.getMunicipio(), aluno.getCep(), aluno.getDataIngresso()));
        for (Aluno a: alunos) {
            System.out.println(a.toString());
        }
       // if(!isEditando())
       //     alunos.add(new Aluno(aluno.getNome(), aluno.getAnoIngresso(), aluno.getMensalidade()));
        this.aluno = new Aluno();
        setEditando(false);
        return "listar";
    }
        
    public String salvar(){
        AlunoDAO.cadastrar(aluno);
        return "cadastrarAluno";
    }
    
    public LinkedList<Aluno> getAlunos() {
       return AlunoDAO.getLista();
    
    }
    
    public String excluir(Aluno a){
        System.out.println("Excluindo!!!");
        alunos.remove(a);
        setEditando(false);
        return "operacoes_aluno";
    }
    public String editar(Aluno a){
        this.aluno = a;
        setEditando(true);
        return "editar";
    }
    
    public void limpar() {
       this.aluno = new Aluno();
       setEditando(false);
    }

    public boolean isEditando() {
        return editando;
    }

    public void setEditando(boolean editando) {
        this.editando = editando;
    }
    
}
