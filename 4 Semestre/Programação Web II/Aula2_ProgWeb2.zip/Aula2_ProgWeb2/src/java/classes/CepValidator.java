/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

/**
 *
 * @author 0729159
 */
public class CepValidator implements Validator{

    @Override
    public void validate(FacesContext context, UIComponent component, Object cep) throws ValidatorException {          
        if (!validarCEP(String.valueOf(cep))) {
            FacesMessage message = new FacesMessage();
            message.setSeverity(FacesMessage.SEVERITY_ERROR);
            message.setSummary("Cep Inválido");
            throw new ValidatorException(message);
        }
    }
    
    public boolean validarCEP(String cep){
        if(cep == null || !somenteNumeros(cep) || !quantidadeDigitosValida(cep)){
            return false;
        }
        return true;
    }
    
    public boolean somenteNumeros(String cep){
        try{
            int numeros = Integer.parseInt(cep);
            return true;
        }
        catch(NumberFormatException ex){
            return false;
        }
    }
    
    public boolean quantidadeDigitosValida(String cep){
        return cep.length() == 8;
    }
    
}
