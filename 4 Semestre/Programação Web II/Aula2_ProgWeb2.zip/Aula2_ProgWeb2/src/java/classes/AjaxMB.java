/*
 * Fonte: https://github.com/uaihebert/jsf_eficaz/blob/master/src/main/java/parte5/AjaxMB.java
 */
package classes;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@ManagedBean
@ViewScoped
public class AjaxMB implements Serializable {
    private String estadoSelecionado;
    private String bairroSelecionado;
    private String cidadeSelecionada;

    private List<String> estados;
    private List<String> bairros;
    private List<String> cidades;


    @PostConstruct
    private void init() {
        estados = new ArrayList<>();
        estados.add("RS");
        estados.add("SC");
        estados.add("PR");

        cidades = new ArrayList<>();
        bairros = new ArrayList<>();
    }

    public void chamadaAjax(){
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void alterarEstado() {
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        cidades.clear();
        bairros.clear();

        if (estadoSelecionado == null || estadoSelecionado.isEmpty()) {
            return;
        }

        if ("RS".equals(estadoSelecionado)) {
            cidades.add("Alvorada");
            cidades.add("Canoas");
            cidades.add("POA");
        }

        if ("SC".equals(estadoSelecionado)) {
            cidades.add("Florianópolis");
        }

        if ("PR".equals(estadoSelecionado)) {
            cidades.add("Londrina");
        }
    }

    public void alterarCidade() {
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        bairros.clear();

        if (cidadeSelecionada == null || cidadeSelecionada.isEmpty()) {
            return;
        }

        if ("Londrina".equals(cidadeSelecionada)) {
            bairros.add("Aeroporto");
            bairros.add("Cilo 2");
            bairros.add("Jardim Ideal");
        }

        if ("Florianópolis".equals(cidadeSelecionada)) {
            bairros.add("Barra da Lagoa");
            bairros.add("Ingleses");
        }

        if ("Alvorada".equals(cidadeSelecionada)) {
            bairros.add("Sumaré");
            bairros.add("Americana");
            bairros.add("Piratini");
        }

        if ("Canoas".equals(cidadeSelecionada)) {
            bairros.add("Igara");
            bairros.add("Mathias Velho");
        }

        if ("POA".equals(cidadeSelecionada)) {
            bairros.add("Tristeza");
            bairros.add("Ipanema");
        }
    }

    public String getEstadoSelecionado() {
        return estadoSelecionado;
    }

    public void setEstadoSelecionado(String estadoSelcionado) {
        this.estadoSelecionado = estadoSelcionado;
    }

    public String getBairroSelecionado() {
        return bairroSelecionado;
    }

    public void setBairroSelecionado(String bairroSelcionado) {
        this.bairroSelecionado = bairroSelcionado;
    }

    public String getCidadeSelecionada() {
        return cidadeSelecionada;
    }

    public void setCidadeSelecionada(String cidadeSelecionada) {
        this.cidadeSelecionada = cidadeSelecionada;
    }

    public List<String> getEstados() {
        return estados;
    }

    public void setEstados(List<String> estados) {
        this.estados = estados;
    }

    public List<String> getBairros() {
        return bairros;
    }

    public void setBairros(List<String> bairros) {
        this.bairros = bairros;
    }

    public List<String> getCidades() {
        return cidades;
    }

    public void setCidades(List<String> cidades) {
        this.cidades = cidades;
    }
}