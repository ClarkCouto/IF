/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

/**
 *
 * @author Silvia
 */
public enum AlunoSQLs {
  INSERIR("insert into aluno(nome, cpf) values (?, ?)"),
  LISTAR_TODOS("select * from aluno");
        
  private final String sql;
  AlunoSQLs(String sql){
        this.sql = sql; 
  }

    public String getSql() {
        return sql;
    }       
}
