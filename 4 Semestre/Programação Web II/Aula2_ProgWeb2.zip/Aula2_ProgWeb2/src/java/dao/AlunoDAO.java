package dao;

import classes.Aluno;
import java.sql.*;
import java.util.*;


public class AlunoDAO {
    
    public static boolean cadastrar(Aluno aluno) {
        try(Connection connection = new ConnectionFactory().getConnection();
        PreparedStatement stmt = 
                connection.prepareStatement(AlunoSQLs.INSERIR.getSql());){
            stmt.setString(1, aluno.getNome());
            stmt.setString(2, aluno.getCpf());         
            System.out.println("Dados Gravados!");
            return stmt.execute();
        }catch(SQLException e){
            System.out.println("exceção com recursos - cadastrar" + e.getMessage());
        }
        return false;      
    }
    
    public static LinkedList<Aluno> getLista() {
        LinkedList<Aluno> lista = new LinkedList<>();
        
        try(Connection connection = new ConnectionFactory().getConnection();
            PreparedStatement stmt = 
                    connection.prepareStatement(AlunoSQLs.LISTAR_TODOS.getSql());){
            System.out.println("Conexão aberta - lista!");
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                String nome = rs.getString("nome");
                String cpf = rs.getString("cpf");
                lista.add(new Aluno(nome, cpf));
            }
            return lista;
        }catch(SQLException e){ System.out.println("Exceção SQL" + e.getMessage());
        }catch(Exception e){  System.out.println("Exceção no código!");
        }
        return null;
    }
}
