/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.io.Serializable;

public class Produto implements Serializable {

    private String nome;
    private String descricao;
    private String categoria;
    private Double valorUnitario;
    private String fornecedor;
    private Integer quantidadeAtualEstoque;
    private Integer estoqueMinimo;
    private String unidade;

    public Produto() {
    }

    public Produto(String nome, String descricao, String categoria, Double valorUnitario, String fornecedor, Integer quantidadeAtualEstoque, Integer estoqueMinimo, String unidade) {
        this.nome = nome;
        this.descricao = descricao;
        this.categoria = categoria;
        this.valorUnitario = valorUnitario;
        this.fornecedor = fornecedor;
        this.quantidadeAtualEstoque = quantidadeAtualEstoque;
        this.estoqueMinimo = estoqueMinimo;
        this.unidade = unidade;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public Double getValorUnitario() {
        return valorUnitario;
    }

    public void setValorUnitario(Double valorUnitario) {
        this.valorUnitario = valorUnitario;
    }

    public String getFornecedor() {
        return fornecedor;
    }

    public void setFornecedor(String fornecedor) {
        this.fornecedor = fornecedor;
    }

    public Integer getQuantidadeAtualEstoque() {
        return quantidadeAtualEstoque;
    }

    public void setQuantidadeAtualEstoque(Integer quantidadeAtualEstoque) {
        this.quantidadeAtualEstoque = quantidadeAtualEstoque;
    }

    public Integer getEstoqueMinimo() {
        return estoqueMinimo;
    }

    public void setEstoqueMinimo(Integer estoqueMinimo) {
        this.estoqueMinimo = estoqueMinimo;
    }

    public String getUnidade() {
        return unidade;
    }

    public void setUnidade(String unidade) {
        this.unidade = unidade;
    }

    @Override
    public String toString() {
        return "Produto{" + "nome=" + nome + ", descricao=" + descricao + ", categoria=" + categoria + ", valorUnitario=" + valorUnitario + ", fornecedor=" + fornecedor + ", quantidadeAtualEstoque=" + quantidadeAtualEstoque + ", estoqueMinimo=" + estoqueMinimo + ", unidade=" + unidade + '}';
    }
}
