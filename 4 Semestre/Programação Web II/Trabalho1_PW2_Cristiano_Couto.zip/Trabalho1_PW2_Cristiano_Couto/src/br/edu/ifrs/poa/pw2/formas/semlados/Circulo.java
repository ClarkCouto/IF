package br.edu.ifrs.poa.pw2.formas.semlados;

import br.edu.ifrs.poa.pw2.formas.Figura;
import br.edu.ifrs.poa.pw2.util.Cor;

public class Circulo extends Figura{
	public static final double PI = 3.1415;
	private double raio;
	
	public Circulo(){
		super();
	}
	
	public Circulo(double raio){
		this.raio = raio;
	}
	
	public Circulo(double raio, Cor cor) {
		super(cor);
		this.raio = raio;
	}
	
	public double getRaio(){
		return raio;
	}
	
	public void setRaio(double raio){
		this.raio = raio;
	}
	
	public double calculaArea(){
		return 2 * PI + raio;
	}

	@Override
	public String toString(){
		String cor = getCor() != null ? getCor().toString() : "Não informada!";
		return "Círculo\nRaio = " + raio + "\nÁrea = " + calculaArea() + "\nCor = " + cor;
	}
}
