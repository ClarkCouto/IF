package br.edu.ifrs.poa.pw2.formas;

import br.edu.ifrs.poa.pw2.formas.doislados.Quadrado;
import br.edu.ifrs.poa.pw2.formas.semlados.Circulo;
import br.edu.ifrs.poa.pw2.formas.treslados.TrianguloEquilatero;
import br.edu.ifrs.poa.pw2.util.Cor;

public class Teste1 {
	public static void main(String args[]){ 
		Figura vet[] = new Figura[4]; 
		vet[0] = new Figura();
		vet[1] = new Quadrado();
		vet[2] = new Circulo();
		vet[3] = new TrianguloEquilatero();
		for(Figura f: vet){
			System.out.println(f.calculaArea()); 
		}

//		//Teste Correto
//		Figura vet[] = new Figura[3]; 
//		vet[0] = new TrianguloEquilatero(5, new Cor(1,2,3));
//		System.out.println("Quantidade de Figuras: " + vet[0].getContador()); 
//		vet[1] = new Quadrado(6, new Cor(4,5,6));
//		System.out.println("Quantidade de Figuras: " + vet[1].getContador()); 
//		vet[2] = new Circulo(7, new Cor(7,8,9));
//		System.out.println("Quantidade de Figuras: " + vet[2].getContador()); 
//		for(Figura f: vet){
//			System.out.println(f.toString()); 
//		}
	}
}
