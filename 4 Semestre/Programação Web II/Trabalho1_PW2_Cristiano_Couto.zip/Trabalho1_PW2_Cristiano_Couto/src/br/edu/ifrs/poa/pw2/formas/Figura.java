package br.edu.ifrs.poa.pw2.formas;

import br.edu.ifrs.poa.pw2.util.Cor;

public abstract class Figura {
	static int contador;
	protected Cor cor;
	
	public Figura(){
		setContador();
	}

	public Figura(Cor cor){
		setContador();
		setCor(cor);
	}
	
	public abstract double calculaArea();
	
	public static void setContador(){
		contador++;
	}
	
	public static int getContador(){
		return contador;
	}
	
	public Cor getCor() {
		return cor;
	}

	public void setCor(Cor cor) {
		this.cor = cor;
	}

	public String toString(){
		return "Figura\nContador = " + contador;
	}
}
