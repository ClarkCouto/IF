package classes;

import java.util.LinkedList;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author Marcos Taborda (SSI 2017/01)
 */
@ManagedBean
@SessionScoped
public class AutomovelBean {
    private Automovel automovel = new Automovel();
    private LinkedList<Automovel> automoveis = new LinkedList();
    private LinkedList<String> montadoras;

    public Automovel getAutomovel() {
        return automovel;
    }

    public void setAuto(Automovel auto) {
        this.automovel = auto;
    }
    
    public LinkedList<String> getMontadoras() {
        if(montadoras == null)
           return automovel.getMontadoras();
        return montadoras; 
    }
    public LinkedList<Automovel> getAutos() {
       if(automoveis==null)
              this.automoveis = new LinkedList<>();
        return automoveis;
    
    }
    
    public String salvar(){
        automoveis.add(new Automovel(automovel.getAnoFabricacao(), automovel.getAnoModelo(), automovel.getPreco(), automovel.getQuilometragem(),automovel.getPlaca()));
        return "Listar";
    }   
}
