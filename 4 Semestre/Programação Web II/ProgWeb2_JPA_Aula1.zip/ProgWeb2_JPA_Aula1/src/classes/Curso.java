/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author CristianoSilva
 */
@Embeddable
public class Curso implements Serializable {
    private static final long serialVersionUID = 1L;
    
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    @Column(nullable=false, unique=true)
//    private int idCurso;
    
    @Column(nullable=false, unique=true)
    private String nome;
    
    @Column(nullable=false, unique=true)
    private boolean ativo;
        
    public Curso() {
    }

    public Curso(String nome, boolean ativo) {
        this.nome = nome;
        this.ativo = ativo;
    }

//    public Curso(int idCurso, String nome, boolean ativo) {
//        this.idCurso = idCurso;
//        this.nome = nome;
//        this.ativo = ativo;
//    }
//
//    public int getIdCurso() {
//        return idCurso;
//    }
//
//    public void setIdCurso(int idCurso) {
//        this.idCurso = idCurso;
//    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }
    
}
