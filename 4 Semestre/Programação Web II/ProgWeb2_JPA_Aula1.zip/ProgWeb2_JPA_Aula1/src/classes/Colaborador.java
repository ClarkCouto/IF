/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

/**
 *
 * @author CristianoSilva
 */
@Embeddable
public class Colaborador implements Serializable{
    private static final long serialVersionUID = 1L;
    
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    @Column(nullable=false, unique=true)
//    private int idColaborador;
    
    @Column(nullable=false, unique=true)
    private String nome;
    
    @Column(nullable=false, unique=true)
    private boolean ativo;
    
    @ManyToOne
    private Projeto projeto;

    public Colaborador() {
    }

    public Colaborador(String nome, boolean ativo, Projeto projeto) {
        this.nome = nome;
        this.ativo = ativo;
        this.projeto = projeto;
    }

//    public Colaborador(int idColaborador, String nome, boolean ativo, Projeto projeto) {
//        this.idColaborador = idColaborador;
//        this.nome = nome;
//        this.ativo = ativo;
//        this.projeto = projeto;
//    }

//    public int getIdColaborador() {
//        return idColaborador;
//    }
//
//    public void setIdColaborador(int idColaborador) {
//        this.idColaborador = idColaborador;
//    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }

    public Projeto getProjeto() {
        return projeto;
    }

    public void setProjeto(Projeto projeto) {
        this.projeto = projeto;
    }
    
}
