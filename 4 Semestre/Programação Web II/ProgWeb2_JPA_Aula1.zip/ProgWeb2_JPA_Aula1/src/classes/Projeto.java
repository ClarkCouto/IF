/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

/**
 *
 * @author CristianoSilva
 */
@Entity
public class Projeto implements Serializable{
    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue
    @Column(nullable=false, unique=true)
    private int idProjeto;
    
    @Column(nullable=false, unique=true)
    private String titulo;
    
    @Column(nullable=false, unique=false)
    private String periodo;
    
    @Column(nullable=false, unique=false)
    private int ano;
    
    @Column(nullable=false, unique=false)
    private boolean aipct;
    
    @Column(nullable=false, unique=false)
    private boolean ativo;
   
    @ManyToOne
    private Edital edital;
    
//    @OneToMany(mappedBy="projeto")
//    //@OrderBy("")
//    private Collection<Documento> documentos;
//    
//    @OneToMany(mappedBy="projeto")
//    private Collection<Declaracao> declaracoes;
//    
//    @OneToMany(mappedBy="projeto")
//    private Collection<Colaborador> colaboradores;
//    
//    @OneToMany(mappedBy="projeto")
//    private Collection<Aluno> alunos;
//    
//    @OneToMany(mappedBy="projeto")
//    private Collection<Relatorio> relatorios;

    public Projeto() {
    }

    public Projeto(int idProjeto, String titulo, String periodo, int ano, boolean aipct, boolean ativo, Edital edital) {
        this.idProjeto = idProjeto;
        this.titulo = titulo;
        this.periodo = periodo;
        this.ano = ano;
        this.aipct = aipct;
        this.ativo = ativo;
        this.edital = edital;
    }

    public int getIdProjeto() {
        return idProjeto;
    }

    public void setIdProjeto(int idProjeto) {
        this.idProjeto = idProjeto;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getPeriodo() {
        return periodo;
    }

    public void setPeriodo(String periodo) {
        this.periodo = periodo;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public boolean isAipct() {
        return aipct;
    }

    public void setAipct(boolean aipct) {
        this.aipct = aipct;
    }

    public boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }

    public Edital getEdital() {
        return edital;
    }

    public void setEdital(Edital edital) {
        this.edital = edital;
    }
    
    
}
