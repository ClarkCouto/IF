/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.OneToMany;

/**
 *
 * @author CristianoSilva
 */
@Embeddable
public class TipoDocumento implements Serializable{
    private static final long serialVersionUID = 1L;
    
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    @Column(nullable=false, unique=true)
//    private int idTipoDocumento;
    
    @Column(nullable=false, unique=true)
    private String nome;
    
    @Column(nullable=false, unique=true)
    private boolean ativo;
    
//    @OneToMany(mappedBy="tipoDocumento")
//    //@OrderBy("dataLimiteEntrega")
//    private Collection<Documento> documentos;

    public TipoDocumento() {
    }

    public TipoDocumento(String nome, boolean ativo) {
        this.nome = nome;
        this.ativo = ativo;
    }

//    public TipoDocumento(int idTipoDocumento, String nome, boolean ativo) {
//        this.idTipoDocumento = idTipoDocumento;
//        this.nome = nome;
//        this.ativo = ativo;
//    }

//    public int getIdTipoDocumento() {
//        return idTipoDocumento;
//    }
//
//    public void setIdTipoDocumento(int idTipoDocumento) {
//        this.idTipoDocumento = idTipoDocumento;
//    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }

//    public Collection<Documento> getDocumentos() {
//        return documentos;
//    }
//
//    public void setDocumentos(Collection<Documento> documentos) {
//        this.documentos = documentos;
//    }
    
    

}
