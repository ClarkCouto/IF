/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;

/**
 *
 * @author CristianoSilva
 */
@Entity
@DiscriminatorValue(value="aluno")
public class Aluno extends Pessoa implements Serializable{
    private static final long serialVersionUID = 1L;
    
    @Column(nullable=false, unique=true)
    private boolean bolsista;
    
    @Column(nullable=false, unique=true)
    @Embedded
    private Curso curso;
    
    @Column(nullable=true, unique=true)
    @Embedded
    private Bolsa bolsa;
    
    @ManyToOne
    private Projeto projeto;

    public Aluno() {
    }

    public Aluno(boolean bolsista, Curso curso, Bolsa bolsa, Projeto projeto, long idPessoa, String nome, Sexo sexo, long cpf, String email, String telefoneFixo, String telefoneCelular, Instituicao instituicao, boolean ativo) {
        super(idPessoa, nome, sexo, cpf, email, telefoneFixo, telefoneCelular, instituicao, ativo);
        this.bolsista = bolsista;
        this.curso = curso;
        this.bolsa = bolsa;
        this.projeto = projeto;
    }

    public boolean isBolsista() {
        return bolsista;
    }

    public void setBolsista(boolean bolsista) {
        this.bolsista = bolsista;
    }

    public Curso getCurso() {
        return curso;
    }

    public void setCurso(Curso curso) {
        this.curso = curso;
    }

    public Bolsa getBolsa() {
        return bolsa;
    }

    public void setBolsa(Bolsa bolsa) {
        this.bolsa = bolsa;
    }

    public Projeto getProjeto() {
        return projeto;
    }

    public void setProjeto(Projeto projeto) {
        this.projeto = projeto;
    }
    
}
