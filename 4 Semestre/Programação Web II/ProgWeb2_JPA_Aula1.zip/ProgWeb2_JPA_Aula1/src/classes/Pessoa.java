/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.ManyToOne;

/**
 *
 * @author CristianoSilva
 */
@Entity
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "tipo")
public abstract class Pessoa implements Serializable{
    private static final long serialVersionUID = 1L;
    
    public static enum Sexo {
        Masculino, Feminino
    }
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(nullable=false, unique=true)
    private long idPessoa;
    
    @Column(nullable=false, unique=true, columnDefinition = "text", length = 50)
    private String nome;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable=false)
    private Sexo sexo;
    
    @Column(nullable=false, unique=true)
    private long cpf; 
    
    @Column(nullable=false, unique=true, columnDefinition = "text", length = 50)
    private String email;
    
    @Column(nullable=false, unique=false, columnDefinition = "text", length = 11)
    private String telefoneFixo;
    
    @Column(nullable=false, unique=false, columnDefinition = "text", length = 11)
    private String telefoneCelular;
    
    @ManyToOne
    @Embedded
    private Instituicao instituicao;
    
    @Column(nullable=false, unique=true)
    private boolean ativo;

    public Pessoa() {
    }

    public Pessoa(long idPessoa, String nome, Sexo sexo, long cpf, String email, String telefoneFixo, String telefoneCelular, Instituicao instituicao, boolean ativo) {
        this.idPessoa = idPessoa;
        this.nome = nome;
        this.sexo = sexo;
        this.cpf = cpf;
        this.email = email;
        this.telefoneFixo = telefoneFixo;
        this.telefoneCelular = telefoneCelular;
        this.instituicao = instituicao;
        this.ativo = ativo;
    }

    public long getIdPessoa() {
        return idPessoa;
    }

    public void setIdPessoa(long idPessoa) {
        this.idPessoa = idPessoa;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Sexo getSexo() {
        return sexo;
    }

    public void setSexo(Sexo sexo) {
        this.sexo = sexo;
    }

    public long getCpf() {
        return cpf;
    }

    public void setCpf(long cpf) {
        this.cpf = cpf;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefoneFixo() {
        return telefoneFixo;
    }

    public void setTelefoneFixo(String telefoneFixo) {
        this.telefoneFixo = telefoneFixo;
    }

    public String getTelefoneCelular() {
        return telefoneCelular;
    }

    public void setTelefoneCelular(String telefoneCelular) {
        this.telefoneCelular = telefoneCelular;
    }

    public Instituicao getInstituicao() {
        return instituicao;
    }

    public void setInstituicao(Instituicao instituicao) {
        this.instituicao = instituicao;
    }

    public boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }

}
