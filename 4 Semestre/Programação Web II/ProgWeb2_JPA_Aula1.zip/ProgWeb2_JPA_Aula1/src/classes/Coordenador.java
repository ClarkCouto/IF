/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

/**
 *
 * @author CristianoSilva
 */
@Entity
//@DiscriminatorColumn(name = "tipo")
@DiscriminatorValue(value="coordenador")
public class Coordenador extends Usuario implements Serializable{
    private static final long serialVersionUID = 1L;
    
    @Column(nullable=false, unique=true)
    private String siape;
    
    @ManyToOne
    private Projeto projeto;
    
    @ManyToOne
    private Area area;
    
//    @OneToMany(mappedBy="coordenador")
//    //@OrderBy("")
//    private Collection<Declaracao> declaracoes;
//    
//    @OneToMany(mappedBy="coordenador")
//    //@OrderBy("")
//    private Collection<Relatorio> relatorios;

    public Coordenador() {
    }

    public Coordenador(String siape, Projeto projeto, Area area, String senha, Date ultimoAcesso, long idPessoa, String nome, Sexo sexo, long cpf, String email, String telefoneFixo, String telefoneCelular, Instituicao instituicao, boolean ativo) {
        super(senha, ultimoAcesso, idPessoa, nome, sexo, cpf, email, telefoneFixo, telefoneCelular, instituicao, ativo);
        this.siape = siape;
        this.projeto = projeto;
        this.area = area;
    }
    

    public String getSiape() {
        return siape;
    }

    public void setSiape(String siape) {
        this.siape = siape;
    }

    public Projeto getProjeto() {
        return projeto;
    }

    public void setProjeto(Projeto projeto) {
        this.projeto = projeto;
    }
    
}
