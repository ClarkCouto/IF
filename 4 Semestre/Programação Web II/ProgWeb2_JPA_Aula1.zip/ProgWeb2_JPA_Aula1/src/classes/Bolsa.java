/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

/**
 *
 * @author CristianoSilva
 */
@Embeddable
public class Bolsa implements Serializable{
    private static final long serialVersionUID = 1L;
    
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    @Column(nullable=false, unique=true)
//    private int idBolsa;
    
    @Column(nullable=false, unique=true)
    private String nome;
    
    @Column(nullable=false, unique=true)
    private boolean ativo;
    
    @ManyToOne
    private Edital edital;
    
//    @OneToMany(mappedBy="bolsa")
//    //@OrderBy("dataLimiteEntrega")
//    private Collection<Aluno> alunos;

    public Bolsa() {
    }

    public Bolsa( String nome, boolean ativo, Edital edital) {
        this.nome = nome;
        this.ativo = ativo;
        this.edital = edital;
    }

//    public Bolsa(int idBolsa, String nome, boolean ativo, Edital edital) {
//        this.idBolsa = idBolsa;
//        this.nome = nome;
//        this.ativo = ativo;
//        this.edital = edital;
//    }
//
//    public int getIdBolsa() {
//        return idBolsa;
//    }
//
//    public void setIdBolsa(int idBolsa) {
//        this.idBolsa = idBolsa;
//    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }

    public Edital getEdital() {
        return edital;
    }

    public void setEdital(Edital edital) {
        this.edital = edital;
    }

}
