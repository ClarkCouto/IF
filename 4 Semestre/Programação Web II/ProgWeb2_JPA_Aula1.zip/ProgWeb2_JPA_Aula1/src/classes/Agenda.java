/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

/**
 *
 * @author CristianoSilva
 */
@Entity
public class Agenda implements Serializable{
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(nullable=false, unique=true)
    private long idAgenda;
    
    @Column(nullable=false, unique=true)
    private boolean ativo;
    
//    @OneToOne(mappedBy="agenda")
//    private Edital edital;
    
//    @OneToMany(mappedBy="agenda")
//    //@OrderBy("dataLimiteEntrega")
//    private Collection<DataLimiteEntrega> dataLimiteEntregas;

    public Agenda() {
    }

    public Agenda(long idAgenda, boolean ativo, Edital edital) {
        this.idAgenda = idAgenda;
        this.ativo = ativo;
//        this.edital = edital;
    }

    public long getIdAgenda() {
        return idAgenda;
    }

    public void setIdAgenda(long idAgenda) {
        this.idAgenda = idAgenda;
    }

    public boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }

//    public Edital getEdital() {
//        return edital;
//    }
//
//    public void setEdital(Edital edital) {
//        this.edital = edital;
//    }
    
    
}
