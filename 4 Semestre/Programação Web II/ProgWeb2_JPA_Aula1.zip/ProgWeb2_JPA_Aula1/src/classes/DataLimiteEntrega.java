/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author CristianoSilva
 */
@Entity
public class DataLimiteEntrega implements Serializable{
    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long idDataEntrega;
   
    @Column
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataLimite;
    
    @Column(nullable=true, unique=false)
    private String descricao;
    
    @Column(nullable=false, unique=false)
    private boolean obrigatorio;
    
    @Column(nullable=false, unique=true)
    private boolean ativo;
    
    @ManyToOne
    private Agenda agenda;
    
//    @OneToMany(mappedBy="dataLimiteEntrega")
//    //@OrderBy("dataLimiteEntrega")
//    private Collection<Documento> documentos;

    public DataLimiteEntrega() {
    }

    public DataLimiteEntrega(long idDataEntrega, Date dataLimite, String descricao, boolean obrigatorio, boolean ativo, Agenda agenda) {
        this.idDataEntrega = idDataEntrega;
        this.dataLimite = dataLimite;
        this.descricao = descricao;
        this.obrigatorio = obrigatorio;
        this.ativo = ativo;
        this.agenda = agenda;
    }

    public long getIdDataEntrega() {
        return idDataEntrega;
    }

    public void setIdDataEntrega(long idDataEntrega) {
        this.idDataEntrega = idDataEntrega;
    }

    public Date getDataLimite() {
        return dataLimite;
    }

    public void setDataLimite(Date dataLimite) {
        this.dataLimite = dataLimite;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public boolean isObrigatorio() {
        return obrigatorio;
    }

    public void setObrigatorio(boolean obrigatorio) {
        this.obrigatorio = obrigatorio;
    }

    public boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }

    public Agenda getAgenda() {
        return agenda;
    }

    public void setAgenda(Agenda agenda) {
        this.agenda = agenda;
    }
    
}
