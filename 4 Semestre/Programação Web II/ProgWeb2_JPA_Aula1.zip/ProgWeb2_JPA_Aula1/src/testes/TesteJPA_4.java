package testes;
import dao.JPAUtil;
import classes.Usuario;
import javax.persistence.*;

public class TesteJPA_4 {
    public static void main(String[] args) {
        EntityManager em = JPAUtil.getEntityManager();
        EntityTransaction tx = null;
        try {
            tx = em.getTransaction();
            tx.begin();
//            Usuario usuario = em.find(Usuario.class, 1L); 
//            System.out.println("Identificador:"+usuario.getIdentificador());
//            tx.commit();
//            System.out.println("Usuário salvo com"
//                    + " sucesso! ID = " + usuario.getId());
        } catch (RuntimeException e) {
            if (tx != null && tx.isActive()) {
                tx.rollback();
            }
        } finally {
            em.close();
        }
    }

}
