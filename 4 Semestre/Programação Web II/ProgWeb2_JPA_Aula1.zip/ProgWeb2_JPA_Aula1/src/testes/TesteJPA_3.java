package testes;
import dao.JPAUtil;
import classes.Usuario;
import javax.persistence.*;

public class TesteJPA_3 {
    public static void main(String[] args) {
        EntityManager em = JPAUtil.getEntityManager();
        EntityTransaction tx = null;
        try {
            tx = em.getTransaction();
            tx.begin();
//            Usuario usuario = new Usuario("fsilva", "123789");
//            em.persist(usuario);
//            tx.commit();
//            System.out.println("Usuário salvo com"
//                    + " sucesso! ID = " + usuario.getId());
        } catch (RuntimeException e) {
            if (tx != null && tx.isActive()) {
                tx.rollback();
            }
        } finally {
            em.close();
        }
    }

}
