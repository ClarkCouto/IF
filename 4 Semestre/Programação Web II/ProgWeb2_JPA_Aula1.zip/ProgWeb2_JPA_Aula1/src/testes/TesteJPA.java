package testes;
import classes.Curso;
import javax.persistence.*;

public class TesteJPA {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("TesteJPA_1PU");
        EntityManager em = emf.createEntityManager();
        //Usuario user = new Usuario();
        Curso curso = new Curso();
        //em.persist(curso);
        //System.out.println("ID="+curso.getIdCurso());
        em.close();
        emf.close();
    }
    
}
