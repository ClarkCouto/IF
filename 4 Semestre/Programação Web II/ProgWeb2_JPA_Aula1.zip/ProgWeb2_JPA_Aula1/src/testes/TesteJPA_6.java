package testes;
import dao.JPAUtil;
import classes.Usuario;
import javax.persistence.*;

public class TesteJPA_6 {
    public static void main(String[] args) {
        EntityManager em = JPAUtil.getEntityManager();
        EntityTransaction tx = null;
        try {
            tx = em.getTransaction();
            tx.begin();
            Usuario usuario = em.find(Usuario.class, 701L); 
//            usuario.setIdentificador("novoid");
//            tx.commit();
//            System.out.println("Identificador alterado com sucesso");
        } catch (RuntimeException e) {
            if (tx != null && tx.isActive()) {
                tx.rollback();
            }
        } finally {
            em.close();
        }
    }

}
