package testes;

import classes.Usuario;
import javax.persistence.*;

public class TesteJPA_2 {

    public static void main(String[] args) {
        EntityManagerFactory emf
                = Persistence.createEntityManagerFactory("TesteJPA_1PU");
        EntityManager em = emf.createEntityManager();
//        Usuario user = new Usuario("sbertagnolli", "123456");
//        em.persist(user);
//        System.out.println("Usuário salvo com"
//                + " sucesso! ID = " + user.getId());
        em.close();
        emf.close();
    }

}
