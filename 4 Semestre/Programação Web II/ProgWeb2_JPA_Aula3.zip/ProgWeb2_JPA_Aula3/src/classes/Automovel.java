/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author CristianoSilva
 */
@Entity
public class Automovel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column
    private Integer anoFabricacao;
    @Column
    private Integer anoModelo;
    @Column
    private Double preco;
    @Column
    private Double quilometragem;
    @Column(length=20)
    private String montadora;
    @Column
    private Boolean novo;

    public Automovel() {
    }

    public Automovel(Integer anoFabricacao, Integer anoModelo, Double preco, Double quilometragem, String montadora, Boolean novo) {
        this.anoFabricacao = anoFabricacao;
        this.anoModelo = anoModelo;
        this.preco = preco;
        this.quilometragem = quilometragem;
        this.montadora = montadora;
        this.novo = novo;
    }

    public Automovel(Long id, Integer anoFabricacao, Integer anoModelo, Double preco, Double quilometragem, String montadora, Boolean novo) {
        this.id = id;
        this.anoFabricacao = anoFabricacao;
        this.anoModelo = anoModelo;
        this.preco = preco;
        this.quilometragem = quilometragem;
        this.montadora = montadora;
        this.novo = novo;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getAnoFabricacao() {
        return anoFabricacao;
    }

    public void setAnoFabricacao(Integer anoFabricacao) {
        this.anoFabricacao = anoFabricacao;
    }

    public Integer getAnoModelo() {
        return anoModelo;
    }

    public void setAnoModelo(Integer anoModelo) {
        this.anoModelo = anoModelo;
    }

    public Double getPreco() {
        return preco;
    }

    public void setPreco(Double preco) {
        this.preco = preco;
    }

    public Double getQuilometragem() {
        return quilometragem;
    }

    public void setQuilometragem(Double quilometragem) {
        this.quilometragem = quilometragem;
    }

    public String getMontadora() {
        return montadora;
    }

    public void setMontadora(String montadora) {
        this.montadora = montadora;
    }

    public Boolean getNovo() {
        return novo;
    }

    public void setNovo(Boolean novo) {
        this.novo = novo;
    }

    @Override
    public String toString() {
        return "Automovel{" + "id=" + id + ", anoFabricacao=" + anoFabricacao + ", anoModelo=" + anoModelo + ", preco=" + preco + ", quilometragem=" + quilometragem + ", montadora=" + montadora + ", novo=" + novo + '}';
    }
    
}
