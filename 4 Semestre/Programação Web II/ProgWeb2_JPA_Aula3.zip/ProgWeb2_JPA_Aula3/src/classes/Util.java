package classes;

import javax.persistence.EntityManager;

public class Util {
     public static void salvaMensagens( EntityManager em){
        Mensagem m1 = new Mensagem();
        m1.setMensagem("Texto da mensagem 1 sem anexo");
        Mensagem m2 = new Mensagem();
        m2.setMensagem("Texto da mensagem 2 com ANEXO");
        Mensagem m3 = new Mensagem();
        m3.setMensagem("Texto da mensagem 3");
        Mensagem m4 = new Mensagem();
        m4.setMensagem("Anexando dados na mensagem 4");
        em.getTransaction().begin();
        em.persist(m1);
        em.persist(m2);
        em.persist(m3);
        em.persist(m4);
        em.getTransaction().commit();
    }
}
