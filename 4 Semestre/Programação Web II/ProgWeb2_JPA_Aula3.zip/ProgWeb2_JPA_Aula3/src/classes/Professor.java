/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author CristianoSilva
 */
@Entity
public class Professor {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(length=20)
    private String nome;
    
    @Column
    private Long matricula;
    
    @Column(length=20)
    private String area;

    public Professor() {
    }

    public Professor(String nome, Long matricula, String area) {
        this.nome = nome;
        this.matricula = matricula;
        this.area = area;
    }

    public Professor(Long id, String nome, Long matricula, String area) {
        this.id = id;
        this.nome = nome;
        this.matricula = matricula;
        this.area = area;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Long getMatricula() {
        return matricula;
    }

    public void setMatricula(Long matricula) {
        this.matricula = matricula;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    @Override
    public String toString() {
        return "Professor{" + "id=" + id + ", nome=" + nome + ", matricula=" + matricula + ", area=" + area + '}';
    }

}
