package dao;

import classes.Professor;
import dao.JPAUtil;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class ProfessorDAO extends BaseDAO<Professor, Long>{ 
    private EntityManager em;

    public ProfessorDAO() {}

//    public void salvar(Professor professor) {
//        em = JPAUtil.getEntityManager();
//        em.getTransaction().begin();
//        em.persist(professor);
//        em.getTransaction().commit();
//        em.close();
//    }
//
//    public void atualizar(Professor professor) {
//        em = JPAUtil.getEntityManager();
//        em.getTransaction().begin();
//        em.merge(professor);
//        em.getTransaction().commit();
//        em.close();
//    }
//
//    public void remover(long id) {
//        em = JPAUtil.getEntityManager();
//        em.getTransaction().begin();
//        Professor entity = em.find(Professor.class, id);
//        if (entity != null) {
//            em.remove(entity);
//        } else {
//            throw new DAOException("Não existe o id: " + id);
//        }
//        em.getTransaction().commit();
//        em.close();
//    }
//
//    public Professor buscar(int id) {
//        em = JPAUtil.getEntityManager();
//        Professor professor = em.find(Professor.class, id);
//        em.close();
//        return professor;
//    }
//
//    public List<Professor> buscarTodos() {
//        em = JPAUtil.getEntityManager();
//        TypedQuery<Professor> query
//                = em.createQuery(
//                       "SELECT p FROM Professor p",
//                        Professor.class);
//        List<Professor> professors = query.getResultList();
//        em.close();
//        return professors;
//    }
//
//    public List<Professor> buscar(String nome) {
//        em = JPAUtil.getEntityManager();
//        TypedQuery<Professor> query = em.createQuery(
//                "SELECT p FROM Professor p "
//                + "where lower(p.nome) like '%"
//                + nome.toLowerCase() + "%'",
//                Professor.class);
//        List<Professor> professors = query.getResultList();
//        em.close();
//        return professors;
//    }
    
    public List<Professor> pesquisarPorNome(String nome) {
        em = JPAUtil.getEntityManager();
        TypedQuery<Professor> query = em.createQuery(
                "SELECT p FROM Professor p "
                + "where lower(p.nome) like '%"
                + nome.toLowerCase() + "%'",
                Professor.class);
        List<Professor> professors = query.getResultList();
        em.close();
        return professors;
    }
    
    public List<Professor> pesquisarPorMatricula(Long matricula) {
        em = JPAUtil.getEntityManager();
        TypedQuery<Professor> query = em.createQuery(
                "SELECT p FROM Professor p "
                + "where matricula = " + matricula,
                Professor.class);
        List<Professor> professors = query.getResultList();
        em.close();
        return professors;
    }
    
    public List<Professor> pesquisarPorArea(String area) {
        em = JPAUtil.getEntityManager();
        TypedQuery<Professor> query = em.createQuery(
                "SELECT p FROM Professor p "
                + "where lower(p.area) like '%"
                + area.toLowerCase() + "%'",
                Professor.class);
        List<Professor> professors = query.getResultList();
        em.close();
        return professors;
    }

}
