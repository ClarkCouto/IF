package dao;

import classes.Curso;
import dao.JPAUtil;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class CursoDAO { 
    private EntityManager em;

    public CursoDAO() {}

    public void salvar(Curso curso) {
        em = JPAUtil.getEntityManager();
        em.getTransaction().begin();
        em.persist(curso);
        em.getTransaction().commit();
        em.close();
    }

    public void atualizar(Curso curso) {
        em = JPAUtil.getEntityManager();
        em.getTransaction().begin();
        em.merge(curso);
        em.getTransaction().commit();
        em.close();
    }

    public void remover(long id) {
        em = JPAUtil.getEntityManager();
        em.getTransaction().begin();
        Curso entity = em.find(Curso.class, id);
        if (entity != null) {
            em.remove(entity);
        } else {
            throw new DAOException("Não existe o id: " + id);
        }
        em.getTransaction().commit();
        em.close();
    }

    public Curso buscar(int id) {
        em = JPAUtil.getEntityManager();
        Curso curso = em.find(Curso.class, id);
        em.close();
        return curso;
    }

    public List<Curso> buscarTodos() {
        em = JPAUtil.getEntityManager();
        TypedQuery<Curso> query
                = em.createQuery(
                       "SELECT c FROM Curso c",
                        Curso.class);
        List<Curso> cursos = query.getResultList();
        em.close();
        return cursos;
    }

    public List<Curso> buscar(String nome) {
        em = JPAUtil.getEntityManager();
        TypedQuery<Curso> query = em.createQuery(
                "SELECT c FROM Curso c "
                + "where lower(c.nome) like '%"
                + nome.toLowerCase() + "%'",
                Curso.class);
        List<Curso> cursos = query.getResultList();
        em.close();
        return cursos;
    }

}
