package dao;

import classes.Automovel;
import dao.JPAUtil;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class AutomovelDAO { 
    private EntityManager em;

    public AutomovelDAO() {}

    public void salvar(Automovel automovel) {
        em = JPAUtil.getEntityManager();
        em.getTransaction().begin();
        em.persist(automovel);
        em.getTransaction().commit();
        em.close();
    }

    public void atualizar(Automovel automovel) {
        em = JPAUtil.getEntityManager();
        em.getTransaction().begin();
        em.merge(automovel);
        em.getTransaction().commit();
        em.close();
    }

    public void remover(long id) {
        em = JPAUtil.getEntityManager();
        em.getTransaction().begin();
        Automovel entity = em.find(Automovel.class, id);
        if (entity != null) {
            em.remove(entity);
        } else {
            throw new DAOException("Não existe o id: " + id);
        }
        em.getTransaction().commit();
        em.close();
    }

    public Automovel buscar(int id) {
        em = JPAUtil.getEntityManager();
        Automovel automovel = em.find(Automovel.class, id);
        em.close();
        return automovel;
    }

    public List<Automovel> buscarTodos() {
        em = JPAUtil.getEntityManager();
        TypedQuery<Automovel> query
                = em.createQuery(
                       "SELECT a FROM Automovel a",
                        Automovel.class);
        List<Automovel> automovels = query.getResultList();
        em.close();
        return automovels;
    }

    public List<Automovel> buscar(String montadora) {
        em = JPAUtil.getEntityManager();
        TypedQuery<Automovel> query = em.createQuery(
                "SELECT a FROM Automovel a "
                + "where lower(a.montadora) like '%"
                + montadora.toLowerCase() + "%'",
                Automovel.class);
        List<Automovel> automovels = query.getResultList();
        em.close();
        return automovels;
    }

}
