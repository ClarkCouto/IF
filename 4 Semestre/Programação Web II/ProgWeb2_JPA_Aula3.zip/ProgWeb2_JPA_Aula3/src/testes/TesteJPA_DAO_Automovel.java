package testes;

import classes.Automovel;
import dao.*;


public class TesteJPA_DAO_Automovel {
    public static void main(String[] args) {
        AutomovelDAO objDAO = new AutomovelDAO();
        
        //Cria uma nova instância de automóvel e salva
        objDAO.salvar(new Automovel( 2017, 2017, 59000.0, 0.0, "Ford", true));
        objDAO.salvar(new Automovel( 2017, 2017, 59000.0, 0.0, "Chevrolet", true));
        objDAO.salvar(new Automovel( 2017, 2017, 59000.0, 0.0, "Mazda", true));
        objDAO.salvar(new Automovel( 2017, 2017, 59000.0, 0.0, "Renault", true));
        System.out.print("Automovel montadora Ford foi salvo!!!");
        
        
        System.out.println("\nLISTAR TODOS");
        
        for (Automovel a : objDAO.buscarTodos())
             System.out.printf(a.toString() + "\n");
        
        //Recupera o usuário e atualiza com novo nome
        Automovel objA = objDAO.buscar("Ford").get(0);
        objA.setAnoModelo(2018);
        objDAO.atualizar(objA);
        System.out.println("Automovel Atualizado!!");
        System.out.println("\nLISTAR TODOS");
        for (Automovel a : objDAO.buscarTodos())
             System.out.printf(a.toString() + "\n");
        
        objDAO.remover(objA.getId());
        System.out.printf(
           "Automovel excluído: [ID=%d] = %s\n", 
            objA.getId(),
           (objDAO.buscarTodos().isEmpty()));
    }
}
