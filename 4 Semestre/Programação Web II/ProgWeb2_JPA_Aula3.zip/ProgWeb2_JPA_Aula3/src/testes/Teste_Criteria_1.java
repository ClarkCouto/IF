package testes;

import dao.JPAUtil;
import classes.Mensagem;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;


public class Teste_Criteria_1 {
    public static void main(String[] args) {
        EntityManager em = JPAUtil.getEntityManager();
        CriteriaBuilder builder = em.getCriteriaBuilder();
        CriteriaQuery<Mensagem> query = builder.createQuery(Mensagem.class);
        Root<Mensagem> from = query.from(Mensagem.class);
        CriteriaQuery<Mensagem> select = query.select(from);
 
        TypedQuery<Mensagem> typedQuery = em.createQuery(select);
        List<Mensagem> msgs = typedQuery.getResultList();
        for (Mensagem m : msgs) {
            System.out.println("Mensagem:"+m.toString());
        }
        em.close();
    }
}
