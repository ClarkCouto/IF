package testes;

import dao.JPAUtil;
import classes.Mensagem;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;


public class Teste_Criteria_2 {
    public static void main(String[] args) {
        EntityManager em = JPAUtil.getEntityManager();
        TypedQuery<Mensagem> typedQuery = em.createQuery(
                            "SELECT m FROM Mensagem m WHERE m.id > :id ", Mensagem.class);
        typedQuery.setParameter("id", 2);
        List<Mensagem> msgs = typedQuery.getResultList();
        for (Mensagem m : msgs) {
            System.out.println("Mensagem:"+m.toString());
        }
 
        CriteriaBuilder builder = em.getCriteriaBuilder();
        CriteriaQuery<Mensagem> query = builder.createQuery(Mensagem.class);
        Root<Mensagem> from = query.from(Mensagem.class);
        typedQuery = em.createQuery(query.select(from).where(builder.gt(from.get("id"), 2)));
        msgs = typedQuery.getResultList();
        System.out.println("Usando API Criteria");
        for (Mensagem m : msgs) {
            System.out.println("Mensagem:"+m.toString());
        }
        em.close();
    }
}
