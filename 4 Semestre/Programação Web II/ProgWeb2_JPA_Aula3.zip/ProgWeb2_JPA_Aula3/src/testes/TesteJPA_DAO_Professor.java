package testes;

import classes.Professor;
import dao.*;


public class TesteJPA_DAO_Professor {
    public static void main(String[] args) {
        ProfessorDAO objDAO = new ProfessorDAO();
        
        //Cria uma nova instância de automóvel e salva
        objDAO.salvar(new Professor("Professor 1", 1L, "Area 1"));
        System.out.print("Professor foi salvo!!!");
        objDAO.salvar(new Professor("Professor 2", 2L, "Area 2"));
        System.out.print("Professor foi salvo!!!");
        
        
        System.out.println("\nLISTAR TODOS");
        
        for (Professor a : objDAO.buscarTodos())
             System.out.printf(a.toString() + "\n");
        
        //Recupera o usuário e atualiza com novo nome
        Professor objA = objDAO.pesquisarPorNome("Professor 2").get(0);
        objA.setNome("Teste");
        objDAO.atualizar(objA);
        System.out.println("Professor Atualizado!!");
        System.out.println("\nLISTAR TODOS");
        for (Professor a : objDAO.buscarTodos())
             System.out.printf(a.toString() + "\n");
        
        objDAO.remover(objA.getId());
        System.out.printf(
           "Professor excluído: [ID=%d] = %s\n", 
            objA.getId(),
           (objDAO.buscarTodos().isEmpty()));
    }
}
