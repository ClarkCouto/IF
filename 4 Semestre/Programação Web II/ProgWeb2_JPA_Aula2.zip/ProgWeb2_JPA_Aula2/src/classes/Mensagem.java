/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author CristianoSilva
 */
@Entity
public class Mensagem implements Serializable {
    @Id 
    @Column
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Integer id;
    
    @Column
    public String mensagem;

    public Mensagem() {
    }

    public Mensagem(Integer id, String mensagem) {
        this.id = id;
        this.mensagem = mensagem;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMensagem() {
        return mensagem;
    }

    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }
    
    
}
