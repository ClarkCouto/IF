package testes;
import classes.Pessoa;
import javax.persistence.*;

public class TesteJPA {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("TesteJPA_1PU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        Pessoa p = new Pessoa();
        em.persist(p);
        em.getTransaction().commit();
        System.out.println("PEssoa cadastrada com sucesso - Id ="+p.getId());
        em.close();
        emf.close();
    }
    
}
