package testes;

import classes.Situacao;
import classes.Veiculo;
import dao.*;
import java.util.Calendar;
import javax.persistence.EntityManager;

public class Teste {
    public static void main(String[] args) {
        EntityManager em = JPAUtil.getEntityManager();
        em.getTransaction().begin();
        Veiculo v = new Veiculo();
        v.setEstado(Situacao.ALUGADO);
        v.setDataLiberacao(Calendar.getInstance());
        em.persist(v);
        em.getTransaction().commit(); 
        em.close();
        
        em = JPAUtil.getEntityManager();
        em.getTransaction().begin();
        v = em.find(Veiculo.class, 1L);
        Calendar date = v.getDataLiberacao();
        
        System.out.println("Objeto recuperado:" + v.toString());
        em.getTransaction().commit(); 
        em.close();
        
    }
}
