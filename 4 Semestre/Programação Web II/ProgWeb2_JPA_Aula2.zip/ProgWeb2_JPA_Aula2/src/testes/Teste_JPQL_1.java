package testes;

import classes.*;
import dao.JPAUtil;
import java.util.List;
import javax.persistence.*;

public class Teste_JPQL_1 {
    public static void main(String[] args) {
        
        
        EntityManager em = JPAUtil.getEntityManager();
        em.getTransaction().begin();
        Mensagem m = new Mensagem();
        m.setMensagem("Anexo");
        em.persist(m);
        em.getTransaction().commit(); 
        em.close();
        
        em = JPAUtil.getEntityManager();
        em.getTransaction().begin();
        m = new Mensagem();
        m.setMensagem("ANEXO");
        em.persist(m);
        em.getTransaction().commit(); 
        em.close();
        
        em = JPAUtil.getEntityManager();
        em.getTransaction().begin();
        m = new Mensagem();
        m.setMensagem("anexo");
        em.persist(m);
        em.getTransaction().commit(); 
        
        TypedQuery<Mensagem> query = em.createQuery("SELECT obj FROM Mensagem obj", Mensagem.class);
        List<Mensagem> mensagens = query.getResultList();
        for (Mensagem msg : mensagens) {
            System.out.println("Mensagens: " + msg.toString());
        }
        em.close();
        
        
    }

}
