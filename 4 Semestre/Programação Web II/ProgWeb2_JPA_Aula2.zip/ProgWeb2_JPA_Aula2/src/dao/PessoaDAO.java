package dao;

import dao.JPAUtil;
import classes.Pessoa;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class PessoaDAO {
    private EntityManager em;

    public PessoaDAO() {}

    public void salvar(Pessoa pessoa) {
        em = JPAUtil.getEntityManager();
        em.getTransaction().begin();
        em.persist(pessoa);
        em.getTransaction().commit();
        em.close();
    }

    public void atualizar(Pessoa pessoa) {
        em = JPAUtil.getEntityManager();
        em.getTransaction().begin();
        em.merge(pessoa);
        em.getTransaction().commit();
        em.close();
    }

    public void remover(long id) {
        em = JPAUtil.getEntityManager();
        em.getTransaction().begin();
        Pessoa entity = em.find(Pessoa.class, id);
        if (entity != null) {
            em.remove(entity);
        } else {
            throw new DAOException("Não existe o id: " + id);
        }
        em.getTransaction().commit();
        em.close();
    }

    

    public List<Pessoa> buscarTodos() {
        em = JPAUtil.getEntityManager();
        TypedQuery<Pessoa> query
                = em.createQuery(
                       "SELECT p FROM Pessoa p",
                        Pessoa.class);
        List<Pessoa> pessoas = query.getResultList();
        em.close();
        return pessoas;
    }
    
    public List<Pessoa> buscar(String nome) {
        em = JPAUtil.getEntityManager();
        TypedQuery<Pessoa> query = em.createQuery(
                "SELECT p FROM Pessoa p "
                + "where lower(p.nome) like '%"
                + nome.toLowerCase() + "%'",
                Pessoa.class);
        List<Pessoa> pessoas = query.getResultList();
        em.close();
        return pessoas;
    }
}
