package testes;
import classes.Usuario;
import javax.persistence.*;

public class TesteJPA {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("TesteJPA_1PU");
        EntityManager em = emf.createEntityManager();
        Usuario user = new Usuario("sbertagnolli", "123456");
        em.persist(user);
        System.out.println("ID="+user.getId());
        em.close();
        emf.close();
    }
    
}
