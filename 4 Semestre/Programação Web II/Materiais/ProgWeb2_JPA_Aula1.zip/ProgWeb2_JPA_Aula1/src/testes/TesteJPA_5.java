package testes;
import dao.JPAUtil;
import classes.Usuario;
import javax.persistence.*;

public class TesteJPA_5 {
    public static void main(String[] args) {
        EntityManager em = JPAUtil.getEntityManager();
        EntityTransaction tx = null;
        try {
            tx = em.getTransaction();
            tx.begin();
            Usuario usuario = em.find(Usuario.class, 1L); 
            em.remove(usuario);
            tx.commit();
            System.out.println("Usuário excluído com"
                    + " sucesso! ID = " + usuario.getId());
        } catch (RuntimeException e) {
            if (tx != null && tx.isActive()) {
                tx.rollback();
            }
        } finally {
            em.close();
        }
    }

}
