package testes;

import dao.JPAUtil;
import classes.Usuario;
import javax.persistence.*;

public class TesteJPA_7 {

    public static void main(String[] args) {
        EntityManager em = JPAUtil.getEntityManager();
        EntityTransaction tx = null;
        try {
            tx = em.getTransaction();
            tx.begin();
            Usuario usuario = new Usuario("ident02", "Fulano");
            em.persist(usuario);
            em.close();
            //usuário não está mais no contexto de persistência
            //as alterações não refletem mais no banco de dados
            usuario.setIdentificador("ident03");//não atualiza o banco

            //criou novo contexto de persistência
            EntityManager em2 = JPAUtil.getEntityManager();

            //o merge() faz com que 'usuario' volte para um novo 
            //contexto de persistência e como o valor de seu 
            // atributo 'identificador' foi modificado, esta alteração é
            // refletida no banco.
            //O identificador foi alterado de "ident02" para "ident03" no banco.
            em2.merge(usuario);

            tx.commit();
            System.out.println("Usuário excluído com"
                    + " sucesso! ID = " + usuario.getId());
        } catch (RuntimeException e) {
            if (tx != null && tx.isActive()) {
                System.out.println("Voltou na ação!");
                tx.rollback();
            }
        }
    }

}
