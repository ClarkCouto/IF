package testes;

import dao.JPAUtil;
import classes.Usuario;
import javax.persistence.*;

public class TesteJPA_8 {
    public static void main(String[] args) {
        EntityManager em = JPAUtil.getEntityManager();
        em.getTransaction().begin();
        //busca o usuário
        Usuario user1 = em.find(Usuario.class, 702L);
        //desanexa o user1
        em.detach(user1);
        //modifica o objeto desanexado
        user1.setIdentificador("NovoId");
        //reanexa o user1 que foi modificado
        Usuario user2 = em.merge(user1);
        //o user1 não é o mesmo objeto que o user 2?
        System.out.println(user1 != user2);
        //o objeto modificado é o mesmo gerenciado?
        System.out.println(user1 == user2);
        em.close();
        em.getTransaction().commit();  
    }

}
