package classes;

import dao.JPAUtil;
import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Entity;
import javax.persistence.*;

@Entity
@Table(name="categoria")
@NamedQuery(name="Categoria.buscarCategoriaPorNome", 
    query="select c from Categoria c where c.nome = :nome")
public class Categoria implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id 
    @Column(name="id_categoria")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nome;
    
    public Categoria(){}
    public Categoria(Long id, String nome) {
        this.id = id;
        this.nome = nome;
    }
    public Categoria(String nome) {
        this(-1L, nome);
    }
    
    public Categoria buscarCategoriaPorNome(String nome) {
        EntityManager em = JPAUtil.getEntityManager();
    return em.createNamedQuery("Categoria.buscarCategoriaPorNome", Categoria.class)
        .setParameter("nome", nome)
        .getSingleResult();
}
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

  

    @Override
    public String toString() {
        return "Categoria{" + "id=" + id + ", nome=" + nome + '}';
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 53 * hash + Objects.hashCode(this.id);
        hash = 53 * hash + Objects.hashCode(this.nome);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Categoria other = (Categoria) obj;
        if (!Objects.equals(this.nome, other.nome)) {
            return false;
        }
        if (!Objects.equals(this.id, other.id)) {
            return false;
        }
        return true;
    }

  
}
