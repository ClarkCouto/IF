package classes;

public enum SituacaoAluno {
    MATRICULA, CANCELADO;
    
}
