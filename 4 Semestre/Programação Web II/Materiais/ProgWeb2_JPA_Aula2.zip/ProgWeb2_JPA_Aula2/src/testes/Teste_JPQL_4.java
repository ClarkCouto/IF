package testes;

import classes.*;
import dao.JPAUtil;
import javax.persistence.*;

public class Teste_JPQL_4 {
    public static void main(String[] args) {
        EntityManager em = JPAUtil.getEntityManager();
        Categoria c1 = new Categoria("teste");
        Categoria c2 = new Categoria("jogador");
        em.getTransaction().begin();
        em.persist(c1);
        em.persist(c2);
        em.getTransaction().commit();
        
        Categoria c = new Categoria().buscarCategoriaPorNome("teste");
        System.out.println("Categoria lida:" + c.toString());
        em.close();
        

    }

}
