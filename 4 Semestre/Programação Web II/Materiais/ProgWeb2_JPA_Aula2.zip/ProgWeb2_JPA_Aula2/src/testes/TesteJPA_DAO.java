package testes;

import classes.Pessoa;
import dao.*;


public class TesteJPA_DAO {
    public static void main(String[] args) {
        PessoaDAO objDAO = new PessoaDAO();
        
        //Cria uma nova instância de usuário e salva
        objDAO.salvar(new Pessoa("Beltrano", 50));
        System.out.print("Pessoa com nome Beltrano foi salva!!!");
        
        
        System.out.println("\nLISTAR TODOS");
        
        for (Pessoa p : objDAO.buscarTodos())
             System.out.printf(p.toString());
        
        //Recupera o usuário e atualiza com novo nome
        Pessoa objP = objDAO.buscar("Beltrano").get(0);
        objP.setNome("Novo Nome");
        objDAO.atualizar(objP);
        System.out.println("Pessoa Atualizada!!");
        System.out.println("\nLISTAR TODOS");
        for (Pessoa p : objDAO.buscarTodos())
             System.out.printf(p.toString());
        
        objDAO.remover(objP.getId());
        System.out.printf(
           "Pessoa excluída: [ID=%d] = %s\n", 
            objP.getId(),
           (objDAO.buscarTodos().isEmpty()));
    }
}
