package testes;

import dao.JPAUtil;
import classes.*;
import java.util.List;
import javax.persistence.*;

public class Teste_JPQL_3 {
    public static void main(String[] args) {
        EntityManager em = JPAUtil.getEntityManager();
        Pessoa p = new Pessoa();     
        TypedQuery<Pessoa> query = em.createQuery(
        "SELECT p FROM Pessoa p"
        + " where p.nome = :nome"
        + " and p.id = :id", Pessoa.class);
        query.setParameter("nome", "Fulano");
        query.setParameter("id", 3L);
        List<Pessoa> pessoas = query.getResultList();
        for (Pessoa pessoa : pessoas) {
            System.out.println("Pessoa:"+pessoa.toString());
        }
        em.close();
    }
}
