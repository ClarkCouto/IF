package testes;

import classes.*;
import dao.JPAUtil;
import java.util.List;
import javax.persistence.*;

public class Teste_JPQL_2 {

    public static void main(String[] args) {
        EntityManager em = JPAUtil.getEntityManager();
        Pessoa pessoa = new Pessoa();
        pessoa.setNome("FULANO");
        pessoa.setIdade(26);

        em.getTransaction().begin();
        em.persist(pessoa);
        em.getTransaction().commit();

        System.out.println("Objeto pessoa cadastrado: "
                + " ID = " + pessoa.getId());
  

        String sql = "SELECT obj FROM Pessoa obj where upper(obj.nome) like '%" +
                                                  pessoa.getNome().toUpperCase() +"'" ;

        TypedQuery<Pessoa> query = em.createQuery(sql, Pessoa.class);
        List<Pessoa> pessoas = query.getResultList();
        for (Pessoa p : pessoas) {
            System.out.println("Pessoa:" + p.toString());
        }
        em.close();

    }

}
