package testes;

import classes.*;
import dao.JPAUtil;
import java.util.List;
import javax.persistence.*;

public class Teste_JPQL_1 {
    public static void main(String[] args) {
        EntityManager em = JPAUtil.getEntityManager();
        TypedQuery<Pessoa> query = em.createQuery("SELECT obj FROM Pessoa obj", Pessoa.class);
        List<Pessoa> pessoas = query.getResultList();
        for (Pessoa p : pessoas) {
            System.out.println("Pessoa:"+p.toString());
        }
        em.close();
        

    }

}
