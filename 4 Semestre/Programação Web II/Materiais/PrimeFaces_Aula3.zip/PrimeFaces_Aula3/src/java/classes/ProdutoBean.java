package classes;

import java.util.*;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;

@ManagedBean
public class ProdutoBean {

    private LinkedList<Produto> produtos = new LinkedList();
    private Produto produto = new Produto();

    private String[] selectedCategorias;
    private List<String> categorias;

    private String fornecedor;
    private Map<String, String> fornecedores = new HashMap<>();

    
    @PostConstruct
    public void init() {
        produtos.add(new Produto("memória1", "descricao1", "memória", 300.0, "HP", 20, 10, "caixa pequena"));
        produtos.add(new Produto("memória2", "descricao2", "memória", 200.0, "LG", 20, 15, "caixa pequena"));
        produtos.add(new Produto("memória3", "descricao3", "memória", 500.0, "Dell", 20, 10, "caixa pequena"));
        produtos.add(new Produto("memória4", "descricao4", "memória", 250.0, "HP", 20, 11, "caixa pequena"));
        produtos.add(new Produto("teclado1", "descricao1", "teclado", 37.0, "HP", 30, 5, "caixa média"));
        produtos.add(new Produto("teclado2", "descricao2", "teclado", 120.0, "LG", 20, 15, "caixa média"));
        produtos.add(new Produto("teclado3", "descricao3", "teclado", 50.0, "Dell", 80, 10, "caixa média"));
        produtos.add(new Produto("teclado4", "descricao4", "teclado", 80.0, "HP", 20, 19, "caixa média"));
        produtos.add(new Produto("mouse1", "descricao1", "mouse", 30.0, "HP", 5, 5, "caixa pequena"));
        produtos.add(new Produto("mouse2", "descricao2", "mouse", 80.0, "LG", 10, 15, "caixa pequena"));
        produtos.add(new Produto("mouse3", "descricao3", "mouse", 120.0, "Dell", 15, 10, "caixa pequena"));
        produtos.add(new Produto("mouse4", "descricao4", "mouse", 50.0, "HP", 20, 11, "caixa pequena"));
        produtos.add(new Produto("computador1", "descricao1", "computador", 3000.0, "HP", 20, 10, "caixa grande"));
        produtos.add(new Produto("computador1", "descricao2", "computador", 2000.0, "LG", 16, 15, "caixa grande"));
        produtos.add(new Produto("computador1", "descricao3", "computador", 5000.0, "Dell", 12, 10, "caixa grande"));
        produtos.add(new Produto("computador1", "descricao4", "computador", 2500.0, "HP", 12, 11, "caixa grande"));
        
        
        
        
        categorias = new ArrayList<>();
        categorias.add("Computador");
        categorias.add("Memória");
        categorias.add("Teclado");
        categorias.add("Mouse");

        //cities
        fornecedores = new HashMap<>();
        fornecedores.put("Dell", "Dell");
        fornecedores.put("HP", "HP");
        fornecedores.put("LG", "LG");

    }

    public List<String> completeText(String query) {
        List<String> resultados = new ArrayList<>();
        if (query.startsWith("Cai")) {
            resultados.add("Caixa Pequena");
            resultados.add("Caixa Média");
            resultados.add("Caixa Grande");
        }

        return resultados;

    }

    public List<Produto> getProdutos() {
        return produtos;
    }

    public void setProdutos(LinkedList<Produto> produtos) {
        this.produtos = produtos;
    }

    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }

    public String[] getSelectedCategorias() {
        return selectedCategorias;
    }

    public void setSelectedCategorias(String[] selectedCategorias) {
        this.selectedCategorias = selectedCategorias;
    }

    public List<String> getCategorias() {
        return categorias;
    }

    public void setCategorias(List<String> categorias) {
        this.categorias = categorias;
    }

    public String getFornecedor() {
        return fornecedor;
    }

    public void setFornecedor(String fornecedor) {
        this.fornecedor = fornecedor;
    }

    public Map<String, String> getFornecedores() {
        return fornecedores;
    }

    public void setFornecedores(Map<String, String> fornecedores) {
        this.fornecedores = fornecedores;
    }

    public String salvar() {
        Produto p = new Produto(produto.getNome(), produto.getDescricao(), produto.getCategoria(), produto.getValorUnitario(), produto.getFornecedor(), produto.getQuantidadeAtualEstoque(), produto.getEstoqueMinimo(), produto.getUnidade());
        this.produtos.add(p);
        this.produto = new Produto();
        return "listar";
    }

    public String excluir(Produto prod) {
        //fazer excluir
        return "listar";
    }

    public String editar(Produto prod) {
        //fazer editar
        return "editar";
    }

    public String listar() {
        this.produto = new Produto();
        return "listar";
    }

    public void limpar() {
        this.produto = new Produto();
    }
}
