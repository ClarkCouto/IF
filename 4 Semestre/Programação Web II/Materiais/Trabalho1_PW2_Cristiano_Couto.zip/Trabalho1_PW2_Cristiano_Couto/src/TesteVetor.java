

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class TesteVetor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("3.4 A classe Arrays possui vários métodos de classe para manipular vetores. Faça um programa "
				+ "que preenche e ordena um vetor. \nPor fim, pesquise se um determinado número está dentro do vetor, "
				+ "exibindo uma mensagem para o usuário.");

		System.out.println("\nCriando vetor...");
		ArrayList<Integer> lista = new ArrayList<>();
		
		Scanner entrada = new Scanner(System.in);
		int num = -1;
		
		System.out.println("\nPreenchendo o vetor...");
	    for(int i = 0; i < 20; i++){
	       lista.add((int)(Math.random() *100));          
	    }
	    
		System.out.print("\nVetor preenchido: " + lista);
		
		System.out.println("\n\nOrdenando o vetor...");
		Collections.sort(lista);
		
		System.out.print("\nVetor ordenado: " + lista + "\n");
		
		do{
			try{
				System.out.print("\nDigite um número ou 777 para sair: ");
				num = entrada.nextInt();
				if(num != 777){
					if(lista.contains(num))
						System.out.print("\tO número " + num + " está na lista!");
					else
						System.out.print("\tO número " + num + " NÃO está na lista!");
				}
			}
			catch(Exception ex){
				System.out.println("\nErro! Digite somente números!");
				entrada.nextLine();
			}
			
		}
		while(num != 777);
		System.out.println("Programa encerrado!");
		entrada.close();
	}

}
