

import java.util.Scanner;

public class TesteMath {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("3.3 A classe Math possui vários métodos de classe com várias funcionalidades diferentes. Faça "
				+ "um programa que lê um número \ncom casas decimais e utiliza os 3 métodos usados para arredondar números. "
				+ "Explique com suas palavras a diferença existente entre \ncada um desses métodos.");
		
		Scanner entrada = new Scanner(System.in);
		double num = 1;
		do{
			if(num != 0){
				try{
					System.out.print("\nDigite um número ou 0 para encerrar: ");
					num = entrada.nextDouble();
					System.out.println("\nMath.floor, este método pega o número com decimal digitado (" + num + ") "
							+ "DECREMENTA a parte inteira até o próximo número inteiro \nabaixo dele e zera a parte "
							+ "decimal = " + Math.floor(num));
					System.out.println("\nMath.ceil, este método pega o número com decimal digitado (" + num + ") e o "
							+ "INCREMENTA a parte inteira até o próximo número inteiro \nacima dele e zera a parte "
							+ "decimal = " + Math.ceil(num));
					System.out.println("\nMath.round, este método pega o número com decimal digitado (" + num + ") e o "
							+ "INCREMENTA até o número inteiro acima dele, ou DECREMENTA \naté o número inteiro abaixo "
							+ "o que estiver mais próximo dele e exclui a parte decimal = " + Math.round(num));
				}
				catch(Exception ex){
					System.out.println("\nErro! Digite somente números!");
					entrada.nextLine();
				}
			}
		}
		while(num != 0);
		System.out.println("Programa encerrado!");
		entrada.close();
	}

}
