package br.edu.ifrs.poa.pw2.formas.doislados;

import br.edu.ifrs.poa.pw2.formas.Figura;
import br.edu.ifrs.poa.pw2.util.Cor;

public final class Quadrado  extends Figura{
	private double lado;

	public Quadrado(){
		super();
	}
	
	public Quadrado(double lado) {
		super();
		this.lado = lado;
	}
	
	public Quadrado(double lado, Cor cor) {
		super(cor);
		this.lado = lado;
	}
	
	public double getLado(){
		return lado;
	}
	
	public void setLado(double lado){
		this.lado = lado;
	}
	
	public double calculaArea(){
		return lado * lado;
	}

	@Override
	public String toString(){
		String cor = getCor() != null ? getCor().toString() : "Não informada!";
		return "Quadrado\nLado = " + lado + "\nÁrea = " + calculaArea() + "\nCor = " + cor;
	}
}
