package br.edu.ifrs.poa.pw2.formas.treslados;

import br.edu.ifrs.poa.pw2.formas.Figura;
import br.edu.ifrs.poa.pw2.util.Cor;

public class TrianguloEquilatero extends Figura{
	private double lado;
	
	public TrianguloEquilatero(){
		super();
	}
	
	public TrianguloEquilatero(double lado) {
		super();
		this.lado = lado;
	}
	
	public TrianguloEquilatero(double lado, Cor cor) {
		super(cor);
		this.lado = lado;
	}
	
	public double getLado(){
		return lado;
	}
	
	public void setLado(double lado){
		this.lado = lado;
	}
	
	public double calculaArea(){
		return (lado * Math.sqrt(Math.pow(lado, 2) - Math.pow(lado/2, 2)))/2;
	}

	@Override
	public String toString(){
		String cor = getCor() != null ? getCor().toString() : "Não informada!";
		return "Triângulo Equilátero\nLado = " + lado + "\nÁrea = " + calculaArea() + "\nCor = " + cor;
	}
}
