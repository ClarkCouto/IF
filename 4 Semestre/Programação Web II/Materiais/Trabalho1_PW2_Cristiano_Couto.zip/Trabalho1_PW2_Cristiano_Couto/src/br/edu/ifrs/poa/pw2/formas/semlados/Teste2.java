package br.edu.ifrs.poa.pw2.formas.semlados;

import br.edu.ifrs.poa.pw2.formas.Figura;
import br.edu.ifrs.poa.pw2.util.Cor;

public class Teste2 {
//	public static void main(String args[]){
//		Figura obj = new Figura(); 
//		System.out.println(obj.getContador()); 
//		System.out.println(Figura.getContador());
//	}
	
	public static void main(String args[]){ 
		Circulo obj = new Circulo(); 
		obj.cor = new Cor(255, 255, 255); 
		obj.contador = 0;
		obj.raio = 3.0; 
		System.out.println(obj.PI); 
		System.out.println(Circulo.PI);
	}
}
