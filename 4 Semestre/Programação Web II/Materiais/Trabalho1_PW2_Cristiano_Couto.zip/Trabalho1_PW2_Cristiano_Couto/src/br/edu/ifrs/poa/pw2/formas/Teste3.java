package br.edu.ifrs.poa.pw2.formas;

import br.edu.ifrs.poa.pw2.util.Cor;

public class Teste3 {
	public static void main(String args[]){
		Figura obj = new Figura();
		obj.cor = new Cor(0,0,0);
		obj.contador = 0; 
		System.out.println(obj.getContador()); 
		System.out.println(Figura.getContador());
	}
}
