package classes;
import java.io.Serializable;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import javax.persistence.Entity;
import javax.persistence.*;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Veiculo implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    
    @Enumerated(EnumType.ORDINAL)
    private Situacao estado;
    
    @Temporal(TemporalType.DATE)
    private Calendar dataLiberacao;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Situacao getEstado() {
        return estado;
    }

    public void setEstado(Situacao estado) {
        this.estado = estado;
    }

    public Calendar getDataLiberacao() {
        return dataLiberacao;
    }

    public void setDataLiberacao(Calendar dataLiberacao) {
        this.dataLiberacao = dataLiberacao;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Veiculo)) {
            return false;
        }
        Veiculo other = (Veiculo) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        String aux = "";
        if(dataLiberacao != null){
            java.text.SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
	    aux = sdf.format(dataLiberacao.getTime());
        }
            
        return "Veiculo{" + "id=" + id + ", estado=" + estado + ", dataLiberacao=" + aux + '}';
    }


    
}
