package classes;

public enum Situacao {
    DISPONIVEL("Disponível"),
    ALUGADO("Alugado");
    private String descricao;
    private Situacao(String descricao) {
        this.descricao = descricao;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    } 
}
