package classes;

import java.util.LinkedList;

/**
 *
 * @author Marcos Taborda (SSI 2017/01)
 */
public class Automovel {
    private int anoFabricacao;
    private int anoModelo;
    private double preco;
    private double quilometragem;
    private String montadora;
    private boolean usado;
    private String placa;
    
    public Automovel(){}
    public Automovel(int anoFabricacao, int anoModelo, double preco, double quilometragem,  String placa) {
        this.anoFabricacao = anoFabricacao;
        this.anoModelo = anoModelo;
        this.preco = preco;
        this.quilometragem = quilometragem;
        this.placa = placa;
    }


    public int getAnoFabricacao() {
        return anoFabricacao;
    }

    public void setAnoFabricacao(int anoFabricacao) {
        this.anoFabricacao = anoFabricacao;
    }

    public int getAnoModelo() {
        return anoModelo;
    }

    public void setAnoModelo(int anoModelo) {
        this.anoModelo = anoModelo;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public double getQuilometragem() {
        return quilometragem;
    }

    public void setQuilometragem(double quilometragem) {
        this.quilometragem = quilometragem;
    }

    public String getMontadora() {
        return montadora;
    }

    public void setMontadora(String montadora) {
        this.montadora = montadora;
    }

    public boolean isUsado() {
        return usado;
    }

    public void setUsado(boolean usado) {
        this.usado = usado;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }
    
    public LinkedList<String> getMontadoras(){
        LinkedList<String> montadoras = new LinkedList<>();
        montadoras.add("VW");
        montadoras.add("BMW");
        montadoras.add("FORD");
        montadoras.add("RENAULT");
        System.out.println("Adicionou!!!");
        return montadoras;
    }
}
