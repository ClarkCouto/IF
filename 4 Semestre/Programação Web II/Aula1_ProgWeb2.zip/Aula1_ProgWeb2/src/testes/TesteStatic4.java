package testes;

import clientes.Externa;

public class TesteStatic4 {
	    public static void main(String[] args) {
	        Externa.Interna interna = new Externa.Interna();
	        interna.imprime();
	    }
	}

