package testes;

public class TesteFinal3{
	 public static void main(String args[]) { 
        Cliente c = new Cliente();
        System.out.println(c.MENOR_VALOR_DIVIDA);
        System.out.println(Cliente.MAIOR_VALOR_DIVIDA);
   }
}
