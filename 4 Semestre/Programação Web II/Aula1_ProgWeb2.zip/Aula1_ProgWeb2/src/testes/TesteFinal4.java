/*****************************************************************************
 * Fonte: http://www.devmedia.com.br/modificadores-de-acesso-do-java/27065
 *****************************************************************************/
package testes;

import javax.swing.JButton;

public final class TesteFinal4 {
	protected final String nome;
	protected final int idade;
	//n�o poder� haver nenhuma outra instancia��o desse objeto na classe
	protected final JButton botao = new JButton("rotulo do botao");
	protected final int[] vetor;

	//Os atributos finais que n�o foram inicializados em sua declara��o devem ser inicializados no m�todo construtor
    //Se houver qualquer tentativa de uma nova atribui��o de valores (tipos primitivos) ou reinstancia��o
	//(objetos ou vetores) de atributos finais em qualquer outra parte do c�digo, � gerado um erro de compila��o.
	public TesteFinal4() {
		idade = 20;
		nome = "UTFPR-CP";
		vetor = new int[100];
	}

	//Os atributos finais que n�o foram inicializados em sua declara��o devem ser inicializados no m�todo construtor
	public TesteFinal4(int id, String nm, int tamanho) {
		idade = id;
		nome = nm;
		vetor = new int[tamanho];
	}
	//modificador FINAL no par�metro do m�todo. Neste caso, a posi��o recebida n�o poder� ser 
	//alterada dentro do escopo do m�todo.
	public final void imprime(final int posicao) {
		System.out.println(vetor[posicao]);
	}

	public final void inicializa() {
		for (int w = 0; w < vetor.length; w++) {
			vetor[w] = w * 9;
		}
		//� poss�vel alterar os valores dos objetos, mesmo que eles sejam declarados como atributos finais. 
		//A instru��o botao.setText(�novo rotulo do botao�) 
		//causa a altera��o do r�tulo do objeto e, consequentemente, do valor armazenado por ele.
		botao.setText("novo rotulo do botao");
	}
}