package testes;

public class TesteStatic2 {
	public static void main(String[] args) {
		Cliente c1 = new Cliente();
		Cliente c2 = new Cliente();
		System.out.println(c1.contador); 
		System.out.println(c2.contador); 
	}
}
