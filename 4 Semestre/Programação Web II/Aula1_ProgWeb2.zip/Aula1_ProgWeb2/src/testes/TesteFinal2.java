package testes;

public class TesteFinal2 {
		public static void main(String args[]) { 
	         Cpf c = new Cpf();
	         //declarar na classe Cpf o m�todo valida como final
	         if(c.valida())
	        	System.out.println("Cpf � v�lido");
	    }
	}
