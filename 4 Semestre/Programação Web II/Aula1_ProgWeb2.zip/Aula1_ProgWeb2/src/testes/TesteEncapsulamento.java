package testes;

public class TesteEncapsulamento {
	public static void main(String args[]) { 
        Cliente c = new Cliente();
        //analise as linha abaixo
        //comente os erros que ocorrem, justificando seus coment�rios
        c.nome = "Fulano";
        c.endereco = "Rua X, 10";
        c.telefone = "33224455";
        c.situacao = Situacao.ATIVO;
        System.out.println(c.MENOR_VALOR_DIVIDA);
        System.out.println(Cliente.MAIOR_VALOR_DIVIDA);
   }
}
