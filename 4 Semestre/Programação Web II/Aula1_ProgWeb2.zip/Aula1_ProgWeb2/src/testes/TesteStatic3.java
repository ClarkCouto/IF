package testes;

public class TesteStatic3 {
	public static void main(String[] args) {
		Cliente c1 = new Cliente();
		Cliente c2 = new Cliente();
		int cont1 = c1.getContador();
		System.out.println(cont1);
		// ou:
		int cont2 = Cliente.getContador();
		System.out.println(cont2);
	}
}