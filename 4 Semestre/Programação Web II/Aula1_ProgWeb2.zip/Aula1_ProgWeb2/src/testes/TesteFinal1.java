package testes;

public class TesteFinal1{
	 public static void main(String args[]) { 
	    Documento d = new Documento();
	    if(d.valida())
             System.out.println("Documento v�lido");
	 }
}
