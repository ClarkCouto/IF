package documentos;

//declarar classe como final
public class Documento{
    //atributos
	 public final boolean valida() { return true;}
}
