package documentos;

public class Cpf{
    private long numero; 
    private int digito; 

    public boolean valida() { 
            // corpo m�todo
            return true;
     }
    //declarar get/set
}

