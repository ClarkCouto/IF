package clientes;

public interface Situacao {
   public int ATIVO = 1;
}
