
package clientes;

public class Cliente {
	private String nome;
	//declarar atributos abaixo usando o diagrama do slide
	//endereco
	//telefone
	//situacao
	
	public final double MENOR_VALOR_DIVIDA = 0.0;       
	public static final double MAIOR_VALOR_DIVIDA = 5000.0; 

}
