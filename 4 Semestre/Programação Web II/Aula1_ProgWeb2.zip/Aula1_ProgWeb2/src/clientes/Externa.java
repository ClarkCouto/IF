package clientes;

public class Externa {
    public static class Interna {
       public void imprime() {
            System.out.println("m�todo da classe aninhada est�tica");
        }
    }
}
