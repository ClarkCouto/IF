package contas;

public class ContaEspecial {

}
