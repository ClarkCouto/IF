package contas;

public class Conta {
	private double saldo;
	private int numero;
	
	//gerar construtores
	
	//fazer get/set
}
