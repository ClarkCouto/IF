/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

/**
 *
 * @author CristianoSilva
 */
@Entity
public class Area implements Serializable{
    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(nullable=false, unique=true)
    private Long idArea;
    
    @Column(nullable=false, length=50)
    private String nome;
    
    @Column(nullable=false)
    private Boolean ativo;
    
    @OneToMany(targetEntity = Coordenador.class, fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private Collection<Coordenador> coordenadores;

    public Area() {
    }

    public Area(String nome, Boolean ativo) {
        this.nome = nome;
        this.ativo = ativo;
    }

    public Long getIdArea() {
        return idArea;
    }

    public void setIdArea(Long idArea) {
        this.idArea = idArea;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(Boolean ativo) {
        this.ativo = ativo;
    }

    public Collection<Coordenador> getCoordenadores() {
        return coordenadores;
    }

    public void setCoordenadores(Collection<Coordenador> coordenadores) {
        this.coordenadores = coordenadores;
    }
    
}
