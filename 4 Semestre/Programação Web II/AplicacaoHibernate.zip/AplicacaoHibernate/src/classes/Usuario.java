/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author CristianoSilva
 */
@Entity
@DiscriminatorValue(value="usuario")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
public class Usuario extends Pessoa implements Serializable{
    private static final Long serialVersionUID = 1L;
    
    @Column(nullable=false)
    private String senha;
    
    @Column(nullable=true)
    @Temporal(TemporalType.TIMESTAMP)
    private Date ultimoAcesso;

    public Usuario() {
    }

    public Usuario(String senha, Date ultimoAcesso, Long idPessoa, String nome, Sexo sexo, Long cpf, String email, String telefoneFixo, String telefoneCelular, Instituicao instituicao, Boolean ativo) {
        super(idPessoa, nome, sexo, cpf, email, telefoneFixo, telefoneCelular, instituicao, ativo);
        this.senha = senha;
        this.ultimoAcesso = ultimoAcesso;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public Date getUltimoAcesso() {
        return ultimoAcesso;
    }

    public void setUltimoAcesso(Date ultimoAcesso) {
        this.ultimoAcesso = ultimoAcesso;
    }

}
