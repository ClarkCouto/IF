/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

/**
 *
 * @author CristianoSilva
 */
@Entity
//@DiscriminatorColumn(name = "tipo")
@DiscriminatorValue(value="cagppi")
public class Cagppi extends Usuario implements Serializable{
    private static final Long serialVersionUID = 1L;

    public Cagppi() {
    }

    public Cagppi(String senha, Date ultimoAcesso, Long idPessoa, String nome, Sexo sexo, Long cpf, String email, String telefoneFixo, String telefoneCelular, Instituicao instituicao, Boolean ativo) {
        super(senha, ultimoAcesso, idPessoa, nome, sexo, cpf, email, telefoneFixo, telefoneCelular, instituicao, ativo);
    }
    
}
