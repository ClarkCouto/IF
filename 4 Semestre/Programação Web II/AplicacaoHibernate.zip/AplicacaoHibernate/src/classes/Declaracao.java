/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author CristianoSilva
 */
@Entity
public class Declaracao implements Serializable {
    private static final Long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(nullable=false, unique=true)
    private Long idDeclaracao;
    
    @Column(nullable=false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataEmissao;
    
    @Column(nullable=false)
    private Boolean ativo;
    
    @ManyToOne
    //@JoinColumn(insertable=false, updatable=false)
    private Pessoa destinatario;
    
    @ManyToOne
    //@JoinColumn(insertable=false, updatable=false)
    private Coordenador responsavel;
    
    @ManyToOne
    //@JoinColumn(insertable=false, updatable=false)
//    @JoinColumn(nullable=false, insertable=false, updatable=false)
    private Projeto projeto;
    
    @ManyToOne
    private TextoBaseDeclaracao textoBaseDeclaracao;

    public Declaracao() {
    }

    public Declaracao(Long idDeclaracao, Date dataEmissao, Boolean ativo, Coordenador responsavel, Projeto projeto, TextoBaseDeclaracao textoBaseDeclaracao) {
        this.idDeclaracao = idDeclaracao;
        this.dataEmissao = dataEmissao;
        this.ativo = ativo;
        this.responsavel = responsavel;
        this.textoBaseDeclaracao = textoBaseDeclaracao;
        this.projeto = projeto;
    }

    public Long getIdDeclaracao() {
        return idDeclaracao;
    }

    public void setIdDeclaracao(Long idDeclaracao) {
        this.idDeclaracao = idDeclaracao;
    }

    public Date getDataEmissao() {
        return dataEmissao;
    }

    public void setDataEmissao(Date dataEmissao) {
        this.dataEmissao = dataEmissao;
    }

    public Boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(Boolean ativo) {
        this.ativo = ativo;
    }

    public Pessoa getDestinatario() {
        return destinatario;
    }

    public void setDestinatario(Pessoa destinatario) {
        this.destinatario = destinatario;
    }

    public Coordenador getResponsavel() {
        return responsavel;
    }

    public void setResponsavel(Coordenador responsavel) {
        this.responsavel = responsavel;
    }

    public Projeto getProjeto() {
        return projeto;
    }

    public void setProjeto(Projeto projeto) {
        this.projeto = projeto;
    }

    public TextoBaseDeclaracao getTextoBaseDeclaracao() {
        return textoBaseDeclaracao;
    }

    public void setTextoBaseDeclaracao(TextoBaseDeclaracao textoBaseDeclaracao) {
        this.textoBaseDeclaracao = textoBaseDeclaracao;
    }
    
}
