/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.io.Serializable;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

/**
 *
 * @author CristianoSilva
 */
@Entity
public class GrupoDePesquisa implements Serializable{
    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(nullable=false, unique=true)
    private Long idGrupoPesquisa;
    
    @Column(nullable=false)
    private String nome;
    
    @Column(nullable=false)
    private Boolean ativo;
    
    @ManyToOne
    @JoinColumn(insertable=false, updatable=false)
    //@JoinColumn(name = "idCoordenador", insertable=false, updatable=false)
    private Coordenador coordenador;

    public GrupoDePesquisa() {
    }

    public GrupoDePesquisa(String nome, Boolean ativo, Coordenador coordenador) {
        this.nome = nome;
        this.ativo = ativo;
        this.coordenador = coordenador;
    }

    public GrupoDePesquisa(Long idGrupoPesquisa, String nome, Boolean ativo, Coordenador coordenador) {
        this.idGrupoPesquisa = idGrupoPesquisa;
        this.nome = nome;
        this.ativo = ativo;
        this.coordenador = coordenador;
    }

    public Long getIdGrupoPesquisa() {
        return idGrupoPesquisa;
    }

    public void setIdGrupoPesquisa(Long idGrupoPesquisa) {
        this.idGrupoPesquisa = idGrupoPesquisa;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(Boolean ativo) {
        this.ativo = ativo;
    }

    public Coordenador getCoordenador() {
        return coordenador;
    }

    public void setCoordenador(Coordenador coordenador) {
        this.coordenador = coordenador;
    }
    
}
