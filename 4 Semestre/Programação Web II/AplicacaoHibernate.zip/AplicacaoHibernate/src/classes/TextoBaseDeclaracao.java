/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author CristianoSilva
 */
@Entity
public class TextoBaseDeclaracao implements Serializable{
    private static final Long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(nullable=false, unique=true)
    private Integer idTextoBaseDeclaracao;

    @Column(nullable=false)
    private String identificador;
    
    @Column(nullable=false)
    private String texto;
    
    @Column(nullable=false)
    private Boolean ativo;
    
    @Column(nullable=false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataCadastro;
    
    @Column(nullable=true)
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataDesativacao;

    public TextoBaseDeclaracao() {
    }

    public TextoBaseDeclaracao(Integer idTextoBaseDeclaracao, String identificador, String texto, Boolean ativo, Date dataCadastro, Date dataDesativacao) {
        this.idTextoBaseDeclaracao = idTextoBaseDeclaracao;
        this.identificador = identificador;
        this.texto = texto;
        this.ativo = ativo;
        this.dataCadastro = dataCadastro;
        this.dataDesativacao = dataDesativacao;
    }

    public Integer getIdTextoBaseDeclaracao() {
        return idTextoBaseDeclaracao;
    }

    public void setIdTextoBaseDeclaracao(Integer idTextoBaseDeclaracao) {
        this.idTextoBaseDeclaracao = idTextoBaseDeclaracao;
    }

    public String getIdentificador() {
        return identificador;
    }

    public void setIdentificador(String identificador) {
        this.identificador = identificador;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    public Boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(Boolean ativo) {
        this.ativo = ativo;
    }

    public Date getDataCadastro() {
        return dataCadastro;
    }

    public void setDataCadastro(Date dataCadastro) {
        this.dataCadastro = dataCadastro;
    }

    public Date getDataDesativacao() {
        return dataDesativacao;
    }

    public void setDataDesativacao(Date dataDesativacao) {
        this.dataDesativacao = dataDesativacao;
    }
    
}
