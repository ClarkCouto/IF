/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author CristianoSilva
 */
@Entity
public class Documento implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(nullable=false, unique=true)
    private Long idDocumento;
    
    @Column(nullable=false)
    private Boolean entregue;
    
    @Column(nullable=false)
    private Boolean ativo;
    
    @Column(nullable=true)
    private String anexo;
    
    @Column
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataEntregue;
    
    @ManyToOne
//    @JoinColumn(name="idDocumento")
    private TipoDocumento tipoDocumento;
    
    @ManyToOne
//    @JoinColumn(name="idDocumento")
    private Projeto projeto;
    
    @ManyToOne
//    @JoinColumn(name="idDocumento")
    private DataLimiteEntrega dataLimiteEntrega;

    public Documento() {
    }

    public Documento(Boolean entregue, Boolean ativo, String anexo, Date dataEntregue) {
        this.entregue = entregue;
        this.ativo = ativo;
        this.anexo = anexo;
        this.dataEntregue = dataEntregue;
    }

    public Documento(Boolean entregue, Boolean ativo, String anexo, TipoDocumento tipoDocumento, Projeto projeto, DataLimiteEntrega dataLimiteEntrega, Date dataEntregue) {
        this.entregue = entregue;
        this.ativo = ativo;
        this.anexo = anexo;
        this.tipoDocumento = tipoDocumento;
        this.projeto = projeto;
        this.dataLimiteEntrega = dataLimiteEntrega;
        this.dataEntregue = dataEntregue;
    }

    public Long getIdDocumento() {
        return idDocumento;
    }

    public void setIdDocumento(Long idDocumento) {
        this.idDocumento = idDocumento;
    }

    public Boolean isEntregue() {
        return entregue;
    }

    public void setEntregue(Boolean entregue) {
        this.entregue = entregue;
    }

    public Boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(Boolean ativo) {
        this.ativo = ativo;
    }

    public String getAnexo() {
        return anexo;
    }

    public void setAnexo(String anexo) {
        this.anexo = anexo;
    }

    public Date getDataEntregue() {
        return dataEntregue;
    }

    public void setDataEntregue(Date dataEntregue) {
        this.dataEntregue = dataEntregue;
    }

    public TipoDocumento getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(TipoDocumento tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public Projeto getProjeto() {
        return projeto;
    }

    public void setProjeto(Projeto projeto) {
        this.projeto = projeto;
    }

    public DataLimiteEntrega getDataLimiteEntrega() {
        return dataLimiteEntrega;
    }

    public void setDataLimiteEntrega(DataLimiteEntrega dataLimiteEntrega) {
        this.dataLimiteEntrega = dataLimiteEntrega;
    }
   
}
