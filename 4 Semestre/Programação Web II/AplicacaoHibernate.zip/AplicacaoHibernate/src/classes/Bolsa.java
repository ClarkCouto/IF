/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

/**
 *
 * @author CristianoSilva
 */
@Entity
public class Bolsa implements Serializable{
    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(nullable=false, unique=true)
    private Integer idBolsa;
    
    @Column(nullable=false, length=100)
    private String nome;
    
    @Column(nullable=false)
    private Boolean ativo;
    
    @ManyToOne(optional=false)
    //@JoinColumn(name="idEdital")
//    @JoinColumn(name="idEdital", nullable=false, insertable=false, updatable=false)
    private Edital edital;
    
    @OneToMany(mappedBy = "bolsa", targetEntity=Aluno.class, fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    //@JoinColumn(name="idBolsa")
    private Collection<Aluno> alunos;

    public Bolsa() {
    }

    public Bolsa(Integer idBolsa, String nome, Boolean ativo, Edital edital) {
        this.idBolsa = idBolsa;
        this.nome = nome;
        this.ativo = ativo;
        this.edital = edital;
    }

    public Integer getIdBolsa() {
        return idBolsa;
    }

    public void setIdBolsa(Integer idBolsa) {
        this.idBolsa = idBolsa;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(Boolean ativo) {
        this.ativo = ativo;
    }

    public Edital getEdital() {
        return edital;
    }

    public void setEdital(Edital edital) {
        this.edital = edital;
    }

    public Collection<Aluno> getAlunos() {
        return alunos;
    }

    public void setAlunos(Collection<Aluno> alunos) {
        this.alunos = alunos;
    }

}
