/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

/**
 *
 * @author CristianoSilva
 */
@Entity
public class Instituicao implements Serializable{
    private static final Long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(nullable=false, unique=true)
    private Integer idInstituicao;
    
    @Column(nullable=false)
    private String nome;
    
    @Column(nullable=false)
    private Boolean ativo;
    
    @OneToMany(targetEntity = Curso.class, fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private Collection<Curso> Cursos;
    
    @OneToMany(targetEntity = Pessoa.class, fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private Collection<Pessoa> pessoas;

    public Instituicao() {
    }

    public Instituicao(String nome, Boolean ativo) {
        this.nome = nome;
        this.ativo = ativo;
    }

//    public Instituicao(Integer idInstituicao, String nome, Boolean ativo) {
//        this.idInstituicao = idInstituicao;
//        this.nome = nome;
//        this.ativo = ativo;
//    }

    public Integer getIdInstituicao() {
        return idInstituicao;
    }

    public void setIdInstituicao(Integer idInstituicao) {
        this.idInstituicao = idInstituicao;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(Boolean ativo) {
        this.ativo = ativo;
    }

    public Collection<Pessoa> getPessoas() {
        return pessoas;
    }

    public void setPessoas(Collection<Pessoa> pessoas) {
        this.pessoas = pessoas;
    }

    public Collection<Curso> getCursos() {
        return Cursos;
    }

    public void setCursos(Collection<Curso> Cursos) {
        this.Cursos = Cursos;
    }

}
