/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

/**
 *
 * @author CristianoSilva
 */
@Entity
public class TipoDocumento implements Serializable{
    private static final Long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(nullable=false, unique=true)
    private Integer idTipoDocumento;
    
    @Column(nullable=false)
    private String nome;
    
    @Column(nullable=false)
    private Boolean ativo;
    
    @OneToMany
    private Collection<Documento> documentos;

    public TipoDocumento() {
    }

    public TipoDocumento(String nome, Boolean ativo) {
        this.nome = nome;
        this.ativo = ativo;
    }

    public TipoDocumento(Integer idTipoDocumento, String nome, Boolean ativo) {
        this.idTipoDocumento = idTipoDocumento;
        this.nome = nome;
        this.ativo = ativo;
    }

    public int getIdTipoDocumento() {
        return idTipoDocumento;
    }

    public void setIdTipoDocumento(Integer idTipoDocumento) {
        this.idTipoDocumento = idTipoDocumento;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(Boolean ativo) {
        this.ativo = ativo;
    }

    public Collection<Documento> getDocumentos() {
        return documentos;
    }

    public void setDocumentos(Collection<Documento> documentos) {
        this.documentos = documentos;
    }
}
