/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

/**
 *
 * @author CristianoSilva
 */
@Entity
@DiscriminatorValue(value="aluno")
public class Aluno extends Pessoa implements Serializable{
    private static final Long serialVersionUID = 1L;
    
    @Column(nullable=false)
    private Boolean bolsista;
    
    @ManyToOne
    @JoinColumn(name = "idCurso")
    private Curso curso;
    
    @ManyToOne
    @JoinColumn(name = "idBolsa")
    private Bolsa bolsa;
    
    @ManyToOne
    @JoinColumn(name = "idProjeto", insertable=false, updatable=false)
    private Projeto projeto;

    public Aluno() {
    }

//    public Aluno(Boolean bolsista, Curso curso, Bolsa bolsa, Long idPessoa, String nome, Sexo sexo, Long cpf, String email, String telefoneFixo, String telefoneCelular, Instituicao instituicao, Boolean ativo) {
//        super(idPessoa, nome, sexo, cpf, email, telefoneFixo, telefoneCelular, instituicao, ativo);
//        this.bolsista = bolsista;
//        this.curso = curso;
//        this.bolsa = bolsa;
//    }

    public Aluno(Boolean bolsista, Curso curso, Bolsa bolsa, Projeto projeto, Long idPessoa, String nome, Sexo sexo, Long cpf, String email, String telefoneFixo, String telefoneCelular, Instituicao instituicao, Boolean ativo) {
        super(idPessoa, nome, sexo, cpf, email, telefoneFixo, telefoneCelular, instituicao, ativo);
        this.bolsista = bolsista;
        this.curso = curso;
        this.bolsa = bolsa;
        this.projeto = projeto;
    }

    public Boolean isBolsista() {
        return bolsista;
    }

    public void setBolsista(Boolean bolsista) {
        this.bolsista = bolsista;
    }

    public Curso getCurso() {
        return curso;
    }

    public void setCurso(Curso curso) {
        this.curso = curso;
    }

    public Bolsa getBolsa() {
        return bolsa;
    }

    public void setBolsa(Bolsa bolsa) {
        this.bolsa = bolsa;
    }

    public Projeto getProjeto() {
        return projeto;
    }

    public void setProjeto(Projeto projeto) {
        this.projeto = projeto;
    }
    
}
