/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

/**
 *
 * @author CristianoSilva
 */
@Entity
public class Projeto implements Serializable{
    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(nullable=false, unique=true)
    private Long idProjeto;
    
    @Column(nullable=false)
    private String titulo;
    
    @Column(nullable=false)
    private String periodo;
    
    @Column(nullable=false)
    private Integer ano;
    
    @Column(nullable=false)
    private Boolean aipct;
    
    @Column(nullable=false)
    private Boolean ativo;
    
    @ManyToOne
    //@JoinColumn(name="idProjeto", nullable=false)
    private Coordenador coordenador;
   
    @ManyToOne
    @JoinColumn(name="idProjeto", nullable=false, insertable=false, updatable=false)
    private Edital edital;
    
    @OneToMany(targetEntity = Aluno.class, fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(name="idProjeto")
    private Collection<Aluno> alunos;
    
    @OneToMany(targetEntity = Colaborador.class, fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(name="idProjeto")
    private Collection<Colaborador> colaboradores;
    
    @OneToMany(targetEntity = Declaracao.class, fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(name="idProjeto")
    private Collection<Declaracao> declaracoes;
    
    @OneToMany(targetEntity = Documento.class, fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(name="idProjeto")
    private Collection<Documento> documentos;

    public Projeto() {
    }

    public Projeto(Long idProjeto, String titulo, String periodo, Integer ano, Boolean aipct, Boolean ativo, Edital edital, Coordenador coordenador) {
        this.idProjeto = idProjeto;
        this.titulo = titulo;
        this.periodo = periodo;
        this.ano = ano;
        this.aipct = aipct;
        this.ativo = ativo;
        this.edital = edital;
        this.coordenador = coordenador;
    }

    public Long getIdProjeto() {
        return idProjeto;
    }

    public void setIdProjeto(Long idProjeto) {
        this.idProjeto = idProjeto;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getPeriodo() {
        return periodo;
    }

    public void setPeriodo(String periodo) {
        this.periodo = periodo;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public Boolean isAipct() {
        return aipct;
    }

    public void setAipct(Boolean aipct) {
        this.aipct = aipct;
    }

    public Boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(Boolean ativo) {
        this.ativo = ativo;
    }

    public Edital getEdital() {
        return edital;
    }

    public void setEdital(Edital edital) {
        this.edital = edital;
    }

    public Coordenador getCoordenador() {
        return coordenador;
    }

    public void setCoordenador(Coordenador coordenador) {
        this.coordenador = coordenador;
    }

    public Collection<Aluno> getAlunos() {
        return alunos;
    }

    public void setAlunos(Collection<Aluno> alunos) {
        this.alunos = alunos;
    }

    public Collection<Colaborador> getColaboradores() {
        return colaboradores;
    }

    public void setColaboradores(Collection<Colaborador> colaboradores) {
        this.colaboradores = colaboradores;
    }

    public Collection<Declaracao> getDeclaracoes() {
        return declaracoes;
    }

    public void setDeclaracoes(Collection<Declaracao> declaracoes) {
        this.declaracoes = declaracoes;
    }

    public Collection<Documento> getDocumentos() {
        return documentos;
    }

    public void setDocumentos(Collection<Documento> documentos) {
        this.documentos = documentos;
    }
        
}
