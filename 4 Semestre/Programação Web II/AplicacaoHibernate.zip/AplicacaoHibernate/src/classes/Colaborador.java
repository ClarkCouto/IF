/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

/**
 *
 * @author CristianoSilva
 */
@Entity
public class Colaborador implements Serializable{
    private static final Long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(nullable=false, unique=true)
    private Long idColaborador;
    
    @Column(nullable=false)
    private String nome;
    
    @Column(nullable=false)
    private Boolean ativo;
    
    @ManyToOne
    private Area area;
    
    @OneToMany(targetEntity=Declaracao.class, fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    //@JoinColumn(name="idColaborador")
    private Collection<Declaracao> Declaracoes;
    
    @ManyToOne
    @JoinColumn(name = "idProjeto", insertable=false, updatable=false)
    private Projeto projeto;

    public Colaborador() {
    }

    public Colaborador(Long idColaborador, String nome, Boolean ativo, Area area) {
        this.idColaborador = idColaborador;
        this.nome = nome;
        this.ativo = ativo;
        this.area = area;
    }

//    public Colaborador(String nome, Boolean ativo, Projeto projeto) {
//        this.nome = nome;
//        this.ativo = ativo;
//        this.projeto = projeto;
//    }

//    public Colaborador(Long idColaborador, String nome, Boolean ativo, Projeto projeto) {
//        this.idColaborador = idColaborador;
//        this.nome = nome;
//        this.ativo = ativo;
//        this.projeto = projeto;
//    }

    public Long getIdColaborador() {
        return idColaborador;
    }

    public void setIdColaborador(Long idColaborador) {
        this.idColaborador = idColaborador;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(Boolean ativo) {
        this.ativo = ativo;
    }

    public Area getArea() {
        return area;
    }

    public void setArea(Area area) {
        this.area = area;
    }

    public Collection<Declaracao> getDeclaracoes() {
        return Declaracoes;
    }

    public void setDeclaracoes(Collection<Declaracao> Declaracoes) {
        this.Declaracoes = Declaracoes;
    }

    public Projeto getProjeto() {
        return projeto;
    }

    public void setProjeto(Projeto projeto) {
        this.projeto = projeto;
    }
    
}
