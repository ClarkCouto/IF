/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

/**
 *
 * @author CristianoSilva
 */
@Entity
@DiscriminatorValue(value="coordenador")
public class Coordenador extends Usuario implements Serializable{
    private static final Long serialVersionUID = 1L;
    
    @Column(nullable=false)
    private String siape;
    
    @ManyToOne
    //@JoinColumn(insertable=false, updatable=false)
    private Projeto projeto;
    
    @ManyToOne
    private Area area;
    
//    @OneToMany(targetEntity = Declaracao.class, fetch = FetchType.LAZY, cascade = CascadeType.ALL)
//    private Collection<Declaracao> declaracoes;
    
//    @OneToMany(targetEntity = GrupoDePesquisa.class, fetch = FetchType.LAZY, cascade = CascadeType.ALL)
//    private Collection<GrupoDePesquisa> gruposDePesquisa;

    public Coordenador() {
    }

    public Coordenador(String siape, Projeto projeto, Area area, String senha, Date ultimoAcesso, Long idPessoa, String nome, Sexo sexo, Long cpf, String email, String telefoneFixo, String telefoneCelular, Instituicao instituicao, Boolean ativo) {
        super(senha, ultimoAcesso, idPessoa, nome, sexo, cpf, email, telefoneFixo, telefoneCelular, instituicao, ativo);
        this.siape = siape;
        this.projeto = projeto;
        this.area = area;
    }
    
    public String getSiape() {
        return siape;
    }

    public void setSiape(String siape) {
        this.siape = siape;
    }

    public Projeto getProjeto() {
        return projeto;
    }

    public void setProjeto(Projeto projeto) {
        this.projeto = projeto;
    }

    public Area getArea() {
        return area;
    }

    public void setArea(Area area) {
        this.area = area;
    }

//    public Collection<Declaracao> getDeclaracoes() {
//        return declaracoes;
//    }
//
//    public void setDeclaracoes(Collection<Declaracao> declaracoes) {
//        this.declaracoes = declaracoes;
//    }

//    public Collection<GrupoDePesquisa> getGruposDePesquisa() {
//        return gruposDePesquisa;
//    }
//
//    public void setGruposDePesquisa(Collection<GrupoDePesquisa> gruposDePesquisa) {
//        this.gruposDePesquisa = gruposDePesquisa;
//    }
}
