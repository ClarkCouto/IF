/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.CascadeType;
import static javax.persistence.CascadeType.ALL;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

/**
 *
 * @author CristianoSilva
 */
@Entity
public class Edital implements Serializable{
    private static final Long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(nullable=false, unique=true)
    private Long idEdital;
    
    @Column(nullable=false, length=100)
    private String titulo;
    
    @Column(nullable=false, length=50)
    private String numero;
    
    @Column(nullable=false, length=50)
    private String origem;
    
    @Column(nullable=true)
    private String pdf;
    
    @Column(nullable=false)
    private Boolean ativo;
    
    @OneToOne
    //@JoinColumn(name = "idEdital")
    private Agenda agenda;
    
    @OneToMany(targetEntity=Bolsa.class, fetch = FetchType.LAZY, cascade = CascadeType.ALL)
//    @JoinColumn(name="idEdital")
    private Collection<Bolsa> bolsas;
    
    @OneToMany(targetEntity=Projeto.class, fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    //@JoinColumn(name="idEdital")
    private Collection<Projeto> projetos;
    
    public Edital() {
    }

    public Edital(Long idEdital, String titulo, String numero, String origem, Agenda agenda, String pdf, Boolean ativo) {
        this.idEdital = idEdital;
        this.titulo = titulo;
        this.numero = numero;
        this.origem = origem;
        this.agenda = agenda;
        this.pdf = pdf;
        this.ativo = ativo;
    }

    public Long getIdEdital() {
        return idEdital;
    }

    public void setIdEdital(Long idEdital) {
        this.idEdital = idEdital;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getOrigem() {
        return origem;
    }

    public void setOrigem(String origem) {
        this.origem = origem;
    }

    public String getPdf() {
        return pdf;
    }

    public void setPdf(String pdf) {
        this.pdf = pdf;
    }

    public Boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(Boolean ativo) {
        this.ativo = ativo;
    }

    public Agenda getAgenda() {
        return agenda;
    }

    public void setAgenda(Agenda agenda) {
        this.agenda = agenda;
    }

    public Collection<Bolsa> getBolsas() {
        return bolsas;
    }

    public void setBolsas(Collection<Bolsa> bolsas) {
        this.bolsas = bolsas;
    }

    public Collection<Projeto> getProjetos() {
        return projetos;
    }

    public void setProjetos(Collection<Projeto> projetos) {
        this.projetos = projetos;
    }

}
