/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

/**
 *
 * @author CristianoSilva
 */
@Entity
public class Agenda implements Serializable{
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(nullable=false, unique=true)
    private Long idAgenda;
    
    @Column(nullable=false)
    private Boolean ativo;
    
    @OneToOne
    @JoinColumn(nullable=false, name = "idEdital")
    private Edital edital;
    
    @OneToMany(targetEntity = DataLimiteEntrega.class, fetch = FetchType.LAZY, cascade = CascadeType.ALL)
//    @JoinColumn(nullable=false, name = "idAgenda")
    private Collection<DataLimiteEntrega> dataLimiteEntregas;

    public Agenda() {
    }

    public Agenda(long idAgenda, boolean ativo, Edital edital) {
        this.idAgenda = idAgenda;
        this.ativo = ativo;
        this.edital = edital;
    }

    public Long getIdAgenda() {
        return idAgenda;
    }

    public void setIdAgenda(Long idAgenda) {
        this.idAgenda = idAgenda;
    }

    public Boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(Boolean ativo) {
        this.ativo = ativo;
    }

    public Edital getEdital() {
        return edital;
    }

    public void setEdital(Edital edital) {
        this.edital = edital;
    }

    public Collection<DataLimiteEntrega> getDataLimiteEntregas() {
        return dataLimiteEntregas;
    }

    public void setDataLimiteEntregas(Collection<DataLimiteEntrega> dataLimiteEntregas) {
        this.dataLimiteEntregas = dataLimiteEntregas;
    }
    
    
}
