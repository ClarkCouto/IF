/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

/**
 *
 * @author CristianoSilva
 */
@Entity
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
@DiscriminatorColumn(name = "tipo")
public class Pessoa implements Serializable{
    private static final Long serialVersionUID = 1L;
    
    public static enum Sexo {
        Masculino, Feminino
    }
    
    @Id
    @GeneratedValue(strategy = GenerationType.TABLE)
    @Column(nullable=false, unique=true)
    private Long idPessoa;
    
    @Column(nullable=false, columnDefinition = "text", length = 50)
    private String nome;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable=false)
    private Sexo sexo;
    
    @Column(nullable=false, unique=true)
    private Long cpf; 
    
    @Column(nullable=false, columnDefinition = "text", length = 50)
    private String email;
    
    @Column(nullable=false, columnDefinition = "text", length = 10)
    private String telefoneFixo;
    
    @Column(nullable=false, columnDefinition = "text", length = 11)
    private String telefoneCelular;
    
    @Column(nullable=false)
    private Boolean ativo;
    
    @ManyToOne
    //@JoinColumn(name = "idInstituicao")
    private Instituicao instituicao;
    
    @OneToMany(targetEntity = Declaracao.class, fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private Collection<Declaracao> declaracoes;

    public Pessoa() {
    }

    public Pessoa(Long idPessoa, String nome, Sexo sexo, Long cpf, String email, String telefoneFixo, String telefoneCelular, Instituicao instituicao, Boolean ativo) {
        this.idPessoa = idPessoa;
        this.nome = nome;
        this.sexo = sexo;
        this.cpf = cpf;
        this.email = email;
        this.telefoneFixo = telefoneFixo;
        this.telefoneCelular = telefoneCelular;
        this.instituicao = instituicao;
        this.ativo = ativo;
    }

    public Long getIdPessoa() {
        return idPessoa;
    }

    public void setIdPessoa(Long idPessoa) {
        this.idPessoa = idPessoa;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Sexo getSexo() {
        return sexo;
    }

    public void setSexo(Sexo sexo) {
        this.sexo = sexo;
    }

    public Long getCpf() {
        return cpf;
    }

    public void setCpf(Long cpf) {
        this.cpf = cpf;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefoneFixo() {
        return telefoneFixo;
    }

    public void setTelefoneFixo(String telefoneFixo) {
        this.telefoneFixo = telefoneFixo;
    }

    public String getTelefoneCelular() {
        return telefoneCelular;
    }

    public void setTelefoneCelular(String telefoneCelular) {
        this.telefoneCelular = telefoneCelular;
    }

    public Instituicao getInstituicao() {
        return instituicao;
    }

    public void setInstituicao(Instituicao instituicao) {
        this.instituicao = instituicao;
    }

    public Boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(Boolean ativo) {
        this.ativo = ativo;
    }

    public Collection<Declaracao> getDeclaracoes() {
        return declaracoes;
    }

    public void setDeclaracoes(Collection<Declaracao> declaracoes) {
        this.declaracoes = declaracoes;
    }

}
