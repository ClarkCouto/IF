/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testes;

import classes.Agenda;
import classes.Aluno;
import classes.Area;
import classes.Bolsa;
import classes.Cagppi;
import classes.Colaborador;
import classes.Coordenador;
import classes.Curso;
import classes.DataLimiteEntrega;
import classes.Declaracao;
import classes.Documento;
import classes.Edital;
import classes.GrupoDePesquisa;
import classes.Instituicao;
import classes.Pessoa;
import classes.Projeto;
import classes.SetorDePesquisa;
import classes.TextoBaseDeclaracao;
import classes.TipoDocumento;
import dao.JPAUtil;
import java.util.Date;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

/**
 *
 * @author 0729159
 */
public class Teste {
    public static void main(String[] args) {
//        EntityManagerFactory emf = Persistence.createEntityManagerFactory("AplicacaoHibernatePU");
//        EntityManager em = emf.createEntityManager();
//        em.close();
//        emf.close();
        
//            tx.begin();
//            Usuario usuario = new Usuario("ident02", "Fulano");
//            em.persist(usuario);
//            em.close();
//            //usuário não está mais no contexto de persistência
//            //as alterações não refletem mais no banco de dados
//            usuario.setIdentificador("ident03");//não atualiza o banco
//
//            //criou novo contexto de persistência
//            EntityManager em2 = JPAUtil.getEntityManager();
//
//            //o merge() faz com que 'usuario' volte para um novo 
//            //contexto de persistência e como o valor de seu 
//            // atributo 'identificador' foi modificado, esta alteração é
//            // refletida no banco.
//            //O identificador foi alterado de "ident02" para "ident03" no banco.
//            em2.merge(usuario);
//
//            tx.commit();
//            System.out.println("Usuário excluído com"
//                    + " sucesso! ID = " + usuario.getId());
            
        EntityManager em = null;
        EntityTransaction tx = null;
try{
        em = JPAUtil.getEntityManager();
        tx = null;
}
catch(Exception e){
    System.out.println("Erro: :" + e.getMessage());
    e.printStackTrace();
}
        try {
            System.out.println("Criar transação!");
            tx = em.getTransaction();
            
            
            //================================
            //================================
            //========= Cria Edital ==========
            //================================
            //================================
            System.out.println("Criar Edital!");
            Edital edital = new Edital();
            edital.setTitulo("titulo");
            edital.setNumero("numero");
            edital.setOrigem("origem");
            edital.setAtivo(Boolean.TRUE);
            
            //Pesiste o Edital
            System.out.println("Iniciar transação!");
            tx.begin();
            System.out.println("Persistir Edital!");
            em.persist(edital);
            System.out.println("Comitar Edital!");
            tx.commit();
            
            //Busca o Edital que foi cadastrado
            System.out.println("Iniciar transação!");
            tx.begin();
            System.out.println("Encontrar Edital!");
            edital = em.find(Edital.class, 1L);
            System.out.println("Comitar transação!");
            tx.commit();
            
            
            //================================
            //================================
            //========== Cria Bolsa ==========
            //================================
            //================================
            System.out.println("Criar Bolsa!");
            Bolsa bolsa = new Bolsa();
            bolsa.setNome("nome");
            bolsa.setAtivo(Boolean.TRUE);
            bolsa.setEdital(edital);

            //Pesiste a Bolsa
            System.out.println("Iniciar transação!");
            tx.begin();
            System.out.println("Persistir 1 Bolsa!");
            em.persist(bolsa);
            System.out.println("Comitar transação!");
            tx.commit();
            
            System.out.println("Iniciar Loop Bolsa!");
            int i;
            
            for(i = 0; i < 5; i++){
                System.out.println("Iniciar transação!");
                tx.begin();
                System.out.println("Persistir Bolsa " + i + "!"); 
                bolsa = new Bolsa();
                bolsa.setNome("nome " + i);
                bolsa.setAtivo(Boolean.TRUE);
                bolsa.setEdital(edital);
                em.persist(bolsa);
                System.out.println("Comitar transação!");
                tx.commit();
            }
            
            //Busca a Bolsa que foi cadastrada
            System.out.println("Iniciar transação!");
            tx.begin();
            System.out.println("Encontrar Bolsa!");
            bolsa = em.find(Bolsa.class, 1);
            System.out.println("Comitar transação!");
            tx.commit();
            
            
            //================================
            //================================
            //========= Cria Agenda ==========
            //================================
            //================================
            Agenda agenda = new Agenda();
            agenda.setAtivo(Boolean.TRUE);
            agenda.setEdital(edital);
            
            //Pesiste a Agenda
            System.out.println("Iniciar transação!");
            tx.begin();
            System.out.println("Persistir Agenda!");
            em.persist(agenda);
            System.out.println("Comitar Agenda!");
            tx.commit();
            
            //Busca a Agenda que foi cadastrada
            System.out.println("Iniciar transação!");
            tx.begin();
            System.out.println("Encontrar Agenda!");
            agenda = em.find(Agenda.class, 1L);
            System.out.println("Comitar transação!");
            tx.commit();
           
            
            //================================
            //================================
            //==== Cria DataLimiteEntrega ====
            //================================
            //================================
            DataLimiteEntrega dataLimite = new DataLimiteEntrega();
            dataLimite.setDescricao("descricao");
            dataLimite.setAgenda(agenda);
            dataLimite.setAtivo(Boolean.TRUE);
            dataLimite.setObrigatorio(Boolean.FALSE);
            dataLimite.setDataLimite(new Date());
            
            //Pesiste a DataLimiteEntrega
            System.out.println("Iniciar transação!");
            tx.begin();
            System.out.println("Persistir DataLimiteEntrega!");
            em.persist(dataLimite);
            System.out.println("Comitar DataLimiteEntrega!");
            tx.commit();
            
            System.out.println("Iniciar Loop DataLimiteEntrega!");
            
            for(i = 0; i < 5; i++){
                System.out.println("Iniciar transação!");
                tx.begin();
                System.out.println("Persistir DataLimiteEntrega " + i + "!"); 
                dataLimite = new DataLimiteEntrega();
                dataLimite.setDescricao("descricao " + i);
                dataLimite.setAgenda(agenda);
                dataLimite.setAtivo(Boolean.TRUE);
                dataLimite.setObrigatorio(Boolean.FALSE);
                dataLimite.setDataLimite(new Date());
                em.persist(dataLimite);
                System.out.println("Comitar transação!");
                tx.commit();
            }
            
            //Busca a DataLimiteEntrega que foi cadastrada
            System.out.println("Iniciar transação!");
            tx.begin();
            System.out.println("Encontrar DataLimiteEntrega!");
            dataLimite = em.find(DataLimiteEntrega.class, 1L);
            System.out.println("Comitar transação!");
            tx.commit();
            
            
            //================================
            //================================
            //====== Cria Instituicao ========
            //================================
            //================================
            Instituicao instituicao = new Instituicao();
            instituicao.setAtivo(Boolean.TRUE);
            instituicao.setNome("nome");
            
            //Pesiste a Instituicao
            System.out.println("Iniciar transação!");
            tx.begin();
            System.out.println("Persistir Instituicao!");
            em.persist(instituicao);
            System.out.println("Comitar Instituicao!");
            tx.commit();
            
            //Busca a Instituicao que foi cadastrada
            System.out.println("Iniciar transação!");
            tx.begin();
            System.out.println("Encontrar Instituicao!");
            instituicao = em.find(Instituicao.class, 1);
            System.out.println("Comitar transação!");
            tx.commit();
            
            
            //================================
            //================================
            //========== Cria Area ===========
            //================================
            //================================
            Area area = new Area();
            area.setAtivo(Boolean.TRUE);
            area.setNome("nome");
            
            //Pesiste a Agenda
            System.out.println("Iniciar transação!");
            tx.begin();
            System.out.println("Persistir Area!");
            em.persist(area);
            System.out.println("Comitar Area!");
            tx.commit();
            
            //Busca a Agenda que foi cadastrada
            System.out.println("Iniciar transação!");
            tx.begin();
            System.out.println("Encontrar Area!");
            area = em.find(Area.class, 1L);
            System.out.println("Comitar transação!");
            tx.commit();
            
            
            //================================
            //================================
            //===== Cria SetorDePesquisa =====
            //================================
            //================================
            SetorDePesquisa setorDePesquisa = new SetorDePesquisa();
            setorDePesquisa.setAtivo(Boolean.TRUE);
            setorDePesquisa.setNome("nome");
            setorDePesquisa.setEmail("email");
            setorDePesquisa.setTelefoneFixo("fixo");
            setorDePesquisa.setTelefoneCelular("celular");
            setorDePesquisa.setCpf(12345678910L);
            setorDePesquisa.setAtivo(Boolean.TRUE);
            setorDePesquisa.setSenha("senha");
            setorDePesquisa.setSexo(Pessoa.Sexo.Feminino);
            
            //Pesiste a SetorDePesquisa
            System.out.println("Iniciar transação!");
            tx.begin();
            System.out.println("Persistir SetorDePesquisa!");
            em.persist(setorDePesquisa);
            System.out.println("Comitar SetorDePesquisa!");
            tx.commit();
            
            //Busca o SetorDePesquisa que foi cadastrado
            System.out.println("Iniciar transação!");
            tx.begin();
            System.out.println("Encontrar SetorDePesquisa!");
            setorDePesquisa = em.find(SetorDePesquisa.class, 1L);
            System.out.println("Comitar transação!");
            tx.commit();
            
            
            //================================
            //================================
            //========= Cria Cagppi ==========
            //================================
            //================================
            Cagppi cagppi = new Cagppi();
            cagppi.setAtivo(Boolean.TRUE);
            cagppi.setNome("nome");
            cagppi.setEmail("email");
            cagppi.setTelefoneFixo("fixo");
            cagppi.setTelefoneCelular("celular");
            cagppi.setCpf(12345678910L);
            cagppi.setAtivo(Boolean.TRUE);
            cagppi.setSenha("senha");
            cagppi.setSexo(Pessoa.Sexo.Masculino);
            
            //Pesiste a Cagppi
            System.out.println("Iniciar transação!");
            tx.begin();
            System.out.println("Persistir Cagppi!");
            em.persist(cagppi);
            System.out.println("Comitar Cagppi!");
            tx.commit();
            
            //Busca o Cagppi que foi cadastrado
            System.out.println("Iniciar transação!");
            tx.begin();
            System.out.println("Encontrar Cagppi!");
            cagppi = em.find(Cagppi.class, 1L);
            System.out.println("Comitar transação!");
            tx.commit();
            
            
            //================================
            //================================
            //======= Cria Coordenador =======
            //================================
            //================================
            Coordenador coordenador = new Coordenador();
            coordenador.setAtivo(Boolean.TRUE);
            coordenador.setNome("nome");
            coordenador.setEmail("email");
            coordenador.setTelefoneFixo("fixo");
            coordenador.setTelefoneCelular("celular");
            coordenador.setCpf(12345678910L);
            coordenador.setAtivo(Boolean.TRUE);
            coordenador.setSenha("senha");
            coordenador.setSexo(Pessoa.Sexo.Masculino);
            coordenador.setSiape("siape");
            coordenador.setArea(area);
            
            //Pesiste a Coordenador
            System.out.println("Iniciar transação!");
            tx.begin();
            System.out.println("Persistir Coordenador!");
            em.persist(coordenador);
            System.out.println("Comitar Coordenador!");
            tx.commit();
            
            //Busca o Projeto que foi cadastrado
            System.out.println("Iniciar transação!");
            tx.begin();
            System.out.println("Encontrar Coordenador!");
            coordenador = em.find(Coordenador.class, 1L);
            System.out.println("Comitar transação!");
            tx.commit();
            
            
            //================================
            //================================
            //==== Cria Grupo de Pesquisa ====
            //================================
            //================================
            GrupoDePesquisa gruposDePesquisa = new GrupoDePesquisa();
            gruposDePesquisa.setAtivo(Boolean.TRUE);
            gruposDePesquisa.setNome("nome");
            gruposDePesquisa.setCoordenador(coordenador);
            
            //Pesiste o GrupoDePesquisa
            System.out.println("Iniciar transação!");
            tx.begin();
            System.out.println("Persistir GrupoDePesquisa!");
            em.persist(gruposDePesquisa);
            System.out.println("Comitar GrupoDePesquisa!");
            tx.commit();
            
            //Busca o GrupoDePesquisa que foi cadastrado
            System.out.println("Iniciar transação!");
            tx.begin();
            System.out.println("Encontrar GrupoDePesquisa!");
            gruposDePesquisa = em.find(GrupoDePesquisa.class, 1L);
            System.out.println("Comitar transação!");
            tx.commit();
            
            
            //================================
            //================================
            //========= Cria Projeto =========
            //================================
            //================================
            Projeto projeto = new Projeto();
            projeto.setAtivo(Boolean.TRUE);
            projeto.setTitulo("titulo");
            projeto.setPeriodo("periodo");
            projeto.setAno(2017);
            projeto.setAipct(Boolean.TRUE);
            projeto.setAtivo(Boolean.TRUE);
            projeto.setEdital(edital);
            projeto.setCoordenador(coordenador);
            
            //Pesiste a Projeto
            System.out.println("Iniciar transação!");
            tx.begin();
            System.out.println("Persistir Projeto!");
            em.persist(projeto);
            System.out.println("Comitar Projeto!");
            tx.commit();
            
            //Busca o Projeto que foi cadastrado
            System.out.println("Iniciar transação!");
            tx.begin();
            System.out.println("Encontrar Projeto!");
            projeto = em.find(Projeto.class, 1L);
            System.out.println("Comitar transação!");
            tx.commit();
            
            
            //================================
            //================================
            //======= Cria Colaborador =======
            //================================
            //================================
            Colaborador colaborador = new Colaborador();
            colaborador.setNome("nome");
            colaborador.setAtivo(Boolean.TRUE);
            colaborador.setProjeto(projeto);
            
            //Pesiste o Colaborador
            System.out.println("Iniciar transação!");
            tx.begin();
            System.out.println("Persistir Colaborador!");
            em.persist(colaborador);
            System.out.println("Comitar Colaborador!");
            tx.commit();
            
            //Busca o Colaborador que foi cadastrada
            System.out.println("Iniciar transação!");
            tx.begin();
            System.out.println("Encontrar Colaborador!");
            colaborador = em.find(Colaborador.class, 1L);
            System.out.println("Comitar transação!");
            tx.commit();
            
            
            //================================
            //================================
            //========== Cria Curso ==========
            //================================
            //================================
            Curso curso = new Curso();
            curso.setNome("nome");
            curso.setAtivo(Boolean.TRUE);
            curso.setInstituicao(instituicao);
            
            //Pesiste o Curso
            System.out.println("Iniciar transação!");
            tx.begin();
            System.out.println("Persistir Curso!");
            em.persist(curso);
            System.out.println("Comitar Curso!");
            tx.commit();
            
            //Busca o Curso que foi cadastrada
            System.out.println("Iniciar transação!");
            tx.begin();
            System.out.println("Encontrar Curso!");
            curso = em.find(Curso.class, 1);
            System.out.println("Comitar transação!");
            tx.commit();
            
            
            //================================
            //================================
            //========== Cria Aluno ==========
            //================================
            //================================
            Aluno aluno = new Aluno();
            aluno.setAtivo(Boolean.TRUE);
            aluno.setNome("nome");
            aluno.setEmail("email");
            aluno.setTelefoneFixo("fixo");
            aluno.setTelefoneCelular("celular");
            aluno.setCpf(12345678910L);
            aluno.setAtivo(Boolean.TRUE);
            aluno.setSexo(Pessoa.Sexo.Masculino);
            aluno.setBolsista(Boolean.TRUE);
            aluno.setBolsa(bolsa);
            aluno.setCurso(curso);
            aluno.setProjeto(projeto);
            
            //Pesiste o Aluno
            System.out.println("Iniciar transação!");
            tx.begin();
            System.out.println("Persistir Aluno!");
            em.persist(aluno);
            System.out.println("Comitar Aluno!");
            tx.commit();
            
            //Busca o Aluno que foi cadastrado
            System.out.println("Iniciar transação!");
            tx.begin();
            System.out.println("Encontrar Aluno!");
            aluno = em.find(Aluno.class, 1L);
            System.out.println("Comitar transação!");
            tx.commit();
            
            System.out.println("Iniciar Loop Aluno!");
            
            for(i = 0; i < 5; i++){
                System.out.println("Iniciar transação!");
                tx.begin();
                System.out.println("Persistir Aluno " + i + "!"); 
                aluno = new Aluno();
                aluno.setNome("nome " + i);
                aluno.setEmail("email " + i);
                aluno.setTelefoneFixo("fixo " + i);
                aluno.setTelefoneCelular("celular " + i);
                aluno.setCpf(Long.parseLong(i+""));
                aluno.setAtivo(Boolean.TRUE);
                aluno.setSexo(Pessoa.Sexo.Masculino);
                aluno.setBolsista(Boolean.TRUE);
                aluno.setBolsa(bolsa);
                aluno.setCurso(curso);
                aluno.setProjeto(projeto);
                em.persist(aluno);
                System.out.println("Comitar transação!");
                tx.commit();
            }
            
           
            //================================
            //================================
            //====== Cria TipoDocumento ======
            //================================
            //================================
            TipoDocumento tipoDocumento = new TipoDocumento();
            tipoDocumento.setAtivo(Boolean.TRUE);
            tipoDocumento.setNome("nome");
            
            //Pesiste a TipoDocumento
            System.out.println("Iniciar transação!");
            tx.begin();
            System.out.println("Persistir TipoDocumento!");
            em.persist(agenda);
            System.out.println("Comitar TipoDocumento!");
            tx.commit();
            
            //Busca a TipoDocumento que foi cadastrado
            System.out.println("Iniciar transação!");
            tx.begin();
            System.out.println("Encontrar TipoDocumento!");
            tipoDocumento = em.find(TipoDocumento.class, 1);
            System.out.println("Comitar transação!");
            tx.commit();
            
            
            //================================
            //================================
            //======== Cria Documento ========
            //================================
            //================================
            Documento documento = new Documento();
            documento.setEntregue(Boolean.TRUE);
            documento.setAnexo("anexo");
            documento.setAtivo(Boolean.TRUE);
            documento.setDataEntregue(new Date());
            documento.setDataLimiteEntrega(dataLimite);
            documento.setTipoDocumento(tipoDocumento);
            
            //Pesiste a Documento
            System.out.println("Iniciar transação!");
            tx.begin();
            System.out.println("Persistir Documento!");
            em.persist(documento);
            System.out.println("Comitar Documento!");
            tx.commit();
            
            System.out.println("Iniciar Loop Documento!");
            
            for(i = 0; i < 5; i++){
                System.out.println("Iniciar transação!");
                tx.begin();
                System.out.println("Persistir Documento " + i + "!"); 
                documento = new Documento();
                documento.setEntregue(Boolean.FALSE);
                documento.setAtivo(Boolean.TRUE);
                //documento.setAnexo("anexo");
                //documento.setDataEntregue(new Date());
                documento.setDataLimiteEntrega(dataLimite);
                documento.setTipoDocumento(tipoDocumento);
                em.persist(documento);
                System.out.println("Comitar transação!");
                tx.commit();
            }
            
            //Busca a Agenda que foi cadastrada
            System.out.println("Iniciar transação!");
            tx.begin();
            System.out.println("Encontrar Agenda!");
            agenda = em.find(Agenda.class, 1L);
            System.out.println("Comitar transação!");
            tx.commit();
           
            //================================
            //================================
            //=== Cria TextoBaseDeclaracao ===
            //================================
            //================================
            TextoBaseDeclaracao textoBaseDeclaracao = new TextoBaseDeclaracao();
            textoBaseDeclaracao.setAtivo(Boolean.TRUE);
            textoBaseDeclaracao.setIdentificador("identificador");
            textoBaseDeclaracao.setTexto("texto");
            textoBaseDeclaracao.setDataCadastro(new Date());
            
            //Pesiste a TextoBaseDeclaracao
            System.out.println("Iniciar transação!");
            tx.begin();
            System.out.println("Persistir TextoBaseDeclaracao!");
            em.persist(textoBaseDeclaracao);
            System.out.println("Comitar TextoBaseDeclaracao!");
            tx.commit();
            
            //Busca o TextoBaseDeclaracao que foi cadastrado
            System.out.println("Iniciar transação!");
            tx.begin();
            System.out.println("Encontrar TextoBaseDeclaracao!");
            textoBaseDeclaracao = em.find(TextoBaseDeclaracao.class, 1);
            System.out.println("Comitar transação!");
            tx.commit();
            
            
            //================================
            //================================
            //======== Cria Declaracao =======
            //================================
            //================================
            Declaracao declaracao = new Declaracao();
            declaracao.setAtivo(Boolean.TRUE);
            declaracao.setDataEmissao(new Date());
            declaracao.setProjeto(projeto);
            declaracao.setTextoBaseDeclaracao(textoBaseDeclaracao);
            declaracao.setResponsavel(coordenador);
            declaracao.setDestinatario(aluno);
            
            //Pesiste a Declaracao
            System.out.println("Iniciar transação!");
            tx.begin();
            System.out.println("Persistir Declaracao!");
            em.persist(declaracao);
            System.out.println("Comitar Declaracao!");
            tx.commit();
            
            System.out.println("Iniciar Loop Declaracao!");
            
            for(i = 0; i < 5; i++){
                System.out.println("Iniciar transação!");
                tx.begin();
                System.out.println("Persistir Declaracao " + i + "!"); 
                declaracao = new Declaracao();
                declaracao.setAtivo(Boolean.TRUE);
                declaracao.setDataEmissao(new Date());
                declaracao.setProjeto(projeto);
                declaracao.setTextoBaseDeclaracao(textoBaseDeclaracao);
                declaracao.setResponsavel(coordenador);
                em.persist(declaracao);
                System.out.println("Comitar transação!");
                tx.commit();
            }
            
            System.out.println("Finalizou todas transações!");
        } catch (RuntimeException e) {
            
            if (tx != null && tx.isActive()) {
                e.printStackTrace();
                System.out.println("Voltou na ação!");
                tx.rollback();
            }
        }
    }
}
